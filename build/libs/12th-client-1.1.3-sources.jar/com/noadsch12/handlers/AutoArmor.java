/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.handlers;

import com.noadsch12.modules.impl.combat.AutoArmorModule; // <-- import your module
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_9334;

public class AutoArmor {

    private static long lastEquipTime = 0;

    public static void tick() {
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null || mc.field_1761 == null) return;

        // ---------------------------------------
        // DELAY HANDLING
        // ---------------------------------------
        if (AutoArmorModule.delayEnabled) {
            long now = System.currentTimeMillis();
            if (now - lastEquipTime < AutoArmorModule.delay) return;
        }

        boolean equipped = false;

        // Slot IDs: 5 (Head), 6 (Chest), 7 (Legs), 8 (Feet)
        equipped |= checkAndEquip(player, 5, class_1304.field_6169);
        equipped |= checkAndEquip(player, 6, class_1304.field_6174);
        equipped |= checkAndEquip(player, 7, class_1304.field_6172);
        equipped |= checkAndEquip(player, 8, class_1304.field_6166);

        if (equipped) {
            lastEquipTime = System.currentTimeMillis();
        }
    }

    private static boolean checkAndEquip(class_746 player, int handlerSlot, class_1304 targetSlot) {
        class_1799 currentArmor = player.field_7498.method_7611(handlerSlot).method_7677();

        // Only equip if empty
        if (!currentArmor.method_7960()) return false;

        int bestSlot = findBestArmorInInventory(player, targetSlot);
        if (bestSlot != -1) {
            int syncId = player.field_7498.field_7763;
            class_310.method_1551().field_1761.method_2906(
                    syncId,
                    bestSlot,
                    0,
                    class_1713.field_7794,
                    player
            );
            return true;
        }

        return false;
    }

    private static int findBestArmorInInventory(class_746 player, class_1304 targetSlot) {
        List<Integer> candidates = new ArrayList<>();

        // Main inventory slots 9 to 44
        for (int i = 9; i < 45; i++) {
            class_1799 stack = player.field_7498.method_7611(i).method_7677();

            var equippable = stack.method_58694(class_9334.field_54196);
            if (equippable != null && equippable.comp_3174() == targetSlot) {
                candidates.add(i);
            }
        }

        if (candidates.isEmpty()) return -1;

        Comparator<Integer> comparator = Comparator.comparingInt(slot ->
                player.field_7498.method_7611(slot).method_7677()
                        .method_58695(class_9334.field_49629, 0)
        );

        // ---------------------------------------
        // WEAKEST FIRST OPTION
        // ---------------------------------------
        if (AutoArmorModule.weakestFirst) {
            // highest damage first (lowest durability)
            return candidates.stream().max(comparator).orElse(-1);
        } else {
            // lowest damage first (best durability)
            return candidates.stream().min(comparator).orElse(-1);
        }
    }
}
