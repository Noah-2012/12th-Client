/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.handlers;

import com.noadsch12.modules.impl.combat.AimbotModule;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_268;
import net.minecraft.class_310;

public class PlayerAimbotHandler {

    public static void updateAimbot(class_310 client) {

        if (client.field_1724 == null || client.field_1687 == null) return;

        // require mouse click
        if (AimbotModule.requireClick && !client.field_1690.field_1886.method_1434())
            return;

        double range = AimbotModule.range;
        double fov = AimbotModule.fov;

        List<class_1657> players = client.field_1687.method_8390(
                class_1657.class,
                client.field_1724.method_5829().method_1014(range),
                entity -> {

                    if (!entity.method_5805()) return false;
                    if (entity == client.field_1724) return false;
                    if (!client.field_1724.method_6057(entity)) return false;

                    if (AimbotModule.ignoreInvisible && entity.method_5767())
                        return false;

                    if (AimbotModule.ignoreTeammates && isTeammate(client.field_1724, entity))
                        return false;

                    // FOV check
                    if (!isInFov(client, entity, fov))
                        return false;

                    return true;
                }
        );

        if (players.isEmpty()) return;

        class_1657 target;

        // target mode
        if (AimbotModule.targetMode == 1) {
            target = players.stream()
                    .min(Comparator.comparingDouble(class_1657::method_6032))
                    .orElse(null);
        } else {
            target = players.stream()
                    .min(Comparator.comparingDouble(p -> p.method_5739(client.field_1724)))
                    .orElse(null);
        }

        facePlayer(client, target);
    }

    private static boolean isTeammate(class_1657 self, class_1657 other) {
        class_268 t1 = self.method_5781();
        class_268 t2 = other.method_5781();
        return t1 != null && t1 == t2;
    }

    private static boolean isInFov(class_310 client, class_1657 target, double fov) {

        class_243 eyes = client.field_1724.method_33571();
        class_243 look = client.field_1724.method_5828(1.0f).method_1029();
        class_243 dir = target.method_33571().method_1020(eyes).method_1029();

        double angle = Math.toDegrees(Math.acos(look.method_1026(dir)));
        return angle <= (fov / 2.0);
    }

    private static void facePlayer(class_310 client, class_1657 target) {

        class_243 targetPos = target.method_33571();
        class_243 playerPos = client.field_1724.method_33571();

        double diffX = targetPos.field_1352 - playerPos.field_1352;
        double diffY = targetPos.field_1351 - playerPos.field_1351;
        double diffZ = targetPos.field_1350 - playerPos.field_1350;

        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);

        float targetYaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90F;
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diffY, diffXZ));

        float smooth = (float) (AimbotModule.smoothness / 20.0);

        float newYaw = lerp(client.field_1724.method_36454(), targetYaw, smooth);
        float newPitch = lerp(client.field_1724.method_36455(), targetPitch, smooth);

        client.field_1724.method_36456(newYaw);
        client.field_1724.method_36457(newPitch);
    }

    private static float lerp(float from, float to, float speed) {
        return from + (to - from) * speed;
    }
}
