/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.handlers;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class AutoTool {

    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;

        // Only switch if the player is actually holding down the "Attack/Mine" button
        if (!mc.field_1690.field_1886.method_1434()) return;

        class_239 hit = mc.field_1765;
        if (hit == null) return;

        if (hit.method_17783() == class_239.class_240.field_1332) {
            handleBlockMining(mc, ((class_3965) hit));
        } else if (hit.method_17783() == class_239.class_240.field_1331) {
            handleEntityAttack(mc, ((class_3966) hit).method_17782());
        }
    }

    private static void handleBlockMining(class_310 mc, class_3965 hit) {
        class_2680 state = mc.field_1687.method_8320(hit.method_17777());
        if (state.method_26215()) return;

        int bestSlot = -1;
        float bestSpeed = mc.field_1724.method_6047().method_7924(state);

        // Scan the hotbar first (0-8) for the best speed
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            float speed = stack.method_7924(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = i;
            }
        }

        if (bestSlot != -1) {
            mc.field_1724.method_31548().method_61496(bestSlot);
        }
    }

    private static void handleEntityAttack(class_310 mc, class_1297 target) {
        if (!(target instanceof class_1309)) return;

        int bestSlot = -1;
        // Get base damage of current hand
        double bestDamage = mc.field_1724.method_6047().method_7919();

        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            double damage = stack.method_7919();
            if (damage > bestDamage) {
                bestDamage = damage;
                bestSlot = i;
            }
        }

        if (bestSlot != -1) {
            mc.field_1724.method_31548().method_61496(bestSlot);
        }
    }
}