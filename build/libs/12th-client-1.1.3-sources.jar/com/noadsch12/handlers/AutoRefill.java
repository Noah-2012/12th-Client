/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.handlers;

import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class AutoRefill {

    // Store the last known item in each of the 9 hotbar slots
    private static final class_1792[] lastHotbarState = new class_1792[9];

    public static void tick() {
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null || mc.field_1761 == null) return;

        // Loop through hotbar slots (0-8)
        for (int i = 0; i < 9; i++) {
            class_1799 currentStack = player.method_31548().method_5438(i);
            class_1792 currentItem = currentStack.method_7909();

            // If the slot is now empty, but used to have an item
            if (currentStack.method_7960() && lastHotbarState[i] != null && lastHotbarState[i] != class_1802.field_8162) {
                refillSlot(player, i, lastHotbarState[i]);
            }

            // Update the "memory" for the next tick
            lastHotbarState[i] = currentItem;
        }
    }

    private static void refillSlot(class_746 player, int hotbarSlot, class_1792 itemToTarget) {
        // Search main inventory (slots 9 to 35)
        // Note: PlayerInventory indices 9-35 match the ScreenHandler indices 9-35
        for (int i = 9; i < 36; i++) {
            class_1799 stack = player.method_31548().method_5438(i);

            if (stack.method_7909() == itemToTarget) {
                int syncId = player.field_7498.field_7763;
                class_310 mc = class_310.method_1551();

                // Step 1: Click the item in the main inventory
                mc.field_1761.method_2906(syncId, i, 0, class_1713.field_7790, player);

                // Step 2: Click the empty hotbar slot (Hotbar slots in handler are 36-44)
                int handlerHotbarSlot = hotbarSlot + 36;
                mc.field_1761.method_2906(syncId, handlerHotbarSlot, 0, class_1713.field_7790, player);

                // Done refilling for this slot
                return;
            }
        }
    }
}