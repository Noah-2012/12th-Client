/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.render.items;

import net.minecraft.class_124;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_2561;

public class ItemLabelManager {

    /**
     * Updates the custom name of an ItemEntity to show its name and count.
     * Call this during the ItemEntity's tick or upon spawning.
     */
    public static void updateItemLabel(class_1542 itemEntity, boolean clear) {
        class_1799 stack = itemEntity.method_6983();

        if (stack.method_7960()) {
            return;
        }

        // Create the text: "64x Diamond" or "1x Iron Sword"
        class_2561 label = class_2561.method_43470(stack.method_7947() + "x ")
                    .method_10852(stack.method_7964())
                    .method_27692(class_124.field_1054);

        // Apply the name to the entity
        itemEntity.method_5665(label);
        // Ensure the name is always visible (like a name tag)
        itemEntity.method_5880(clear);
    }
}