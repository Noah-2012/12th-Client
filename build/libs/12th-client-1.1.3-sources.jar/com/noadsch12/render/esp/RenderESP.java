/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.render.esp;

import com.noadsch12.modules.ModuleManager;
import com.noadsch12.render.RenderUtils;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientBlockEntityEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.block.*;
import net.minecraft.class_1657;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2363;
import net.minecraft.class_2377;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_638;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class RenderESP {

    // --- Block cache ---
    private static final Map<class_2338, float[]> cachedBlocks = new ConcurrentHashMap<>();
    private static class_1923 lastChunkPos = null;

    // --- Player cache ---
    private static final Map<UUID, class_243> cachedPlayers = new ConcurrentHashMap<>();

    private static boolean initialized = false;

    public static void init() {
        if (initialized) return;

        ClientBlockEntityEvents.BLOCK_ENTITY_LOAD.register(
                (class_2586 be, class_638 world) -> updateSingleBlock(be.method_11016(), be.method_11010()));

        ClientBlockEntityEvents.BLOCK_ENTITY_UNLOAD.register(
                (class_2586 be, class_638 world) -> cachedBlocks.remove(be.method_11016()));

        WorldRenderEvents.AFTER_ENTITIES.register(RenderESP::render);

        initialized = true;
    }

    // -------------------------------------------------------------------------
    // Core render
    // -------------------------------------------------------------------------
    private static void render(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) return;
        if (!ModuleManager.getInstance().getModule("Storage ESP").isEnabled()
                && !ModuleManager.getInstance().getModule("Player ESP").isEnabled()) return;

        class_4597 consumers = context.consumers();
        if (consumers == null) return;

        class_4587 matrices = context.matrices();
        class_4184 camera        = context.gameRenderer().method_19418();
        class_243 cameraPos      = camera.method_71156();
        class_243 tracerOrigin   = RenderUtils.getTracerOrigin(camera);

        RenderUtils.beginLines(2.0f, true);

        class_4588 lineBuf = consumers.method_73477(RenderUtils.LINES_NO_DEPTH);

        // --- Storage ESP ---
        if (ModuleManager.getInstance().getModule("Storage ESP").isEnabled()) {
            class_1923 currentChunk = new class_1923(client.field_1724.method_24515());
            if (!currentChunk.equals(lastChunkPos)) {
                lastChunkPos = currentChunk;
                scanChunk(client, currentChunk);
            }

            final double MAX_DIST_SQ = 150.0 * 150.0;
            cachedBlocks.forEach((pos, rgb) -> {
                if (pos.method_19770(cameraPos) <= MAX_DIST_SQ) {
                    RenderUtils.drawBlockBox(matrices, lineBuf, cameraPos, pos, rgb, true);
                    drawTracer(matrices, lineBuf, cameraPos,
                            pos.method_46558(), tracerOrigin,
                            rgb[0], rgb[1], rgb[2]);
                }
            });
        }

        // --- Player ESP ---
        if (ModuleManager.getInstance().getModule("Player ESP").isEnabled()) {
            updatePlayerCache(client);
            cachedPlayers.forEach((uuid, eyePos) -> {
                RenderUtils.drawPlayerBox(matrices, lineBuf, cameraPos, eyePos,
                        1f, 0f, 0f, 1f, false);
                drawTracer(matrices, lineBuf, cameraPos,
                        eyePos, tracerOrigin,
                        1f, 0f, 0f);
            });
        }

        RenderUtils.endLines();
    }

    // -------------------------------------------------------------------------
    // Tracer line — ESP-specific (origin → target from the camera's view dir)
    // -------------------------------------------------------------------------
    private static void drawTracer(class_4587 matrices, class_4588 buf,
                                   class_243 camera, class_243 target, class_243 origin,
                                   float r, float g, float b) {
        matrices.method_22903();
        // Both points expressed in camera-relative space — no translate needed
        // because emitLine works directly with the model matrix at identity offset
        org.joml.Matrix4f model = matrices.method_23760().method_23761();

        float ox = (float)(origin.field_1352 - camera.field_1352);
        float oy = (float)(origin.field_1351 - camera.field_1351);
        float oz = (float)(origin.field_1350 - camera.field_1350);
        float tx = (float)(target.field_1352 - camera.field_1352);
        float ty = (float)(target.field_1351 - camera.field_1351);
        float tz = (float)(target.field_1350 - camera.field_1350);

        RenderUtils.emitLine(buf, model, ox, oy, oz, tx, ty, tz, r, g, b, 1f);
        matrices.method_22909();
    }

    // -------------------------------------------------------------------------
    // Block scanning / caching
    // -------------------------------------------------------------------------
    private static void scanChunk(class_310 client, class_1923 chunkPos) {
        if (client.field_1687 == null) return;
        class_2338 start = chunkPos.method_8323();
        int minY = client.field_1687.method_31607();
        int maxY = minY + client.field_1687.method_31605();
        for (int x = 0; x < 16; x++)
            for (int z = 0; z < 16; z++)
                for (int y = minY; y < maxY; y++) {
                    class_2338 look = start.method_10069(x, y, z);
                    updateSingleBlock(look, client.field_1687.method_8320(look));
                }
    }

    private static void updateSingleBlock(class_2338 pos, class_2680 state) {
        class_2248 b = state.method_26204();
        float[] rgb = null;

        if      (b == class_2246.field_10034)                  rgb = RenderUtils.COLOR_CHEST;
        else if (b == class_2246.field_10380)          rgb = RenderUtils.COLOR_TRAPPED;
        else if (b == class_2246.field_16328)                 rgb = RenderUtils.COLOR_CHEST;
        else if (b == class_2246.field_10443)            rgb = RenderUtils.COLOR_ENDER_CHEST;
        else if (b instanceof class_2480)       rgb = RenderUtils.COLOR_CHEST;
        else if (b instanceof class_2363
                || b instanceof class_2315
                || b instanceof class_2377
                || b == class_2246.field_10228)              rgb = RenderUtils.COLOR_MACHINE;

        if (rgb != null) cachedBlocks.put(pos, rgb);
        else             cachedBlocks.remove(pos);
    }

    // -------------------------------------------------------------------------
    // Player cache
    // -------------------------------------------------------------------------
    private static void updatePlayerCache(class_310 client) {
        cachedPlayers.clear();
        assert client.field_1687 != null;
        for (class_1657 player : client.field_1687.method_18456()) {
            if (player == client.field_1724) continue;
            cachedPlayers.put(player.method_5667(), player.method_5836(1f));
        }
    }
}