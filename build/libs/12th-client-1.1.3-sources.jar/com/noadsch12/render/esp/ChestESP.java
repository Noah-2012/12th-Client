/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.render.esp;

import com.noadsch12.modules.ModuleManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientBlockEntityEvents;
import net.minecraft.block.*;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2363;
import net.minecraft.class_2377;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Deprecated
public class ChestESP {

    // Persistent storage: Blocks are only removed if broken/unloaded
    private static final Map<class_2338, Integer> cachedBlocks = new ConcurrentHashMap<>();
    private static class_1923 lastChunkPos = null;
    private static boolean initialized = false;

    public static void init() {
        if (initialized) return;

        // Adds blocks to cache when they load into the world
        ClientBlockEntityEvents.BLOCK_ENTITY_LOAD.register((class_2586 blockEntity, class_638 world) -> updateSingleBlock(blockEntity.method_11016(), blockEntity.method_11010()));

        // Removes blocks ONLY when they are actually removed/unloaded
        ClientBlockEntityEvents.BLOCK_ENTITY_UNLOAD.register((class_2586 blockEntity, class_638 world) -> cachedBlocks.remove(blockEntity.method_11016()));

        initialized = true;
    }

    public static void render(class_332 context) {
        if (!ModuleManager.getInstance().getModule("StorageESP").isEnabled()) return;
        init();
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || client.field_1690.field_1842) return;

        // Detect if player moved to a new chunk
        class_1923 currentChunk = new class_1923(client.field_1724.method_24515());
        if (!currentChunk.equals(lastChunkPos)) {
            lastChunkPos = currentChunk;
            // Only scan the current chunk you just entered to fill in gaps
            scanChunk(client, currentChunk);
        }

        renderAll(context, client);
    }

    private static void renderAll(class_332 context, class_310 client) {
        int sw = client.method_22683().method_4486();
        int sh = client.method_22683().method_4502();
        float fov = (float) client.field_1690.method_41808().method_41753();
        Matrix4f projMat = client.field_1773.method_22973(fov);
        class_4184 camera = client.field_1773.method_19418();
        class_243 camPos = camera.method_19326();
        Matrix4f viewMat = new Matrix4f().rotation(camera.method_23767().conjugate());

        // Add distance culling to reduce lag - only render blocks within 150 blocks
        final double MAX_DISTANCE = 150.0;

        cachedBlocks.forEach((pos, color) -> {
            double dist = Math.sqrt(pos.method_19770(camPos));
            if (dist <= MAX_DISTANCE) {
                renderTarget(context, pos, camPos, projMat, viewMat, sw, sh, color);
            }
        });
    }

    private static void scanChunk(class_310 client, class_1923 chunkPos) {
        if (client.field_1687 == null) return;

        class_2338 start = chunkPos.method_8323();

        // Use getBottomY and getHeight to define the loop range without using Heightmaps
        int minY = client.field_1687.method_31607();
        int maxY = minY + client.field_1687.method_31605();

        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                for (int y = minY; y < maxY; y++) {
                    // We use the temporary BlockPos.Mutable to reduce object creation lag
                    class_2338 look = start.method_10069(x, y, z);
                    updateSingleBlock(look, client.field_1687.method_8320(look));
                }
            }
        }
    }

    private static void updateSingleBlock(class_2338 pos, class_2680 state) {
        class_2248 b = state.method_26204();
        int color = -1;

        if (b == class_2246.field_10034) color = pack(255, 160, 0);
        else if (b == class_2246.field_10380) color = pack(255, 0, 0);
        else if (b == class_2246.field_16328) color = pack(255, 160, 0);
        else if (b == class_2246.field_10443) color = pack(120, 0, 255);
        else if (b instanceof class_2480) color = pack(255, 160, 0);
        else if (b instanceof class_2363 || b instanceof class_2315 ||
                b instanceof class_2377 || b == class_2246.field_10228) {
            color = pack(140, 140, 140);
        }

        if (color != -1) {
            cachedBlocks.put(pos, color);
        }
    }

    private static void renderTarget(class_332 context, class_2338 blockPos,
                                     class_243 camPos, Matrix4f proj, Matrix4f view, int sw, int sh, int color) {

        // Define the 8 corners of the block bounding box
        float minX = blockPos.method_10263();
        float minY = blockPos.method_10264();
        float minZ = blockPos.method_10260();
        float maxX = minX + 1.0f;
        float maxY = minY + 1.0f;
        float maxZ = minZ + 1.0f;

        // Calculate all 8 corners in world space relative to camera
        Vector3f[] corners = new Vector3f[8];
        corners[0] = new Vector3f((float)(minX - camPos.field_1352), (float)(minY - camPos.field_1351), (float)(minZ - camPos.field_1350));
        corners[1] = new Vector3f((float)(maxX - camPos.field_1352), (float)(minY - camPos.field_1351), (float)(minZ - camPos.field_1350));
        corners[2] = new Vector3f((float)(maxX - camPos.field_1352), (float)(minY - camPos.field_1351), (float)(maxZ - camPos.field_1350));
        corners[3] = new Vector3f((float)(minX - camPos.field_1352), (float)(minY - camPos.field_1351), (float)(maxZ - camPos.field_1350));
        corners[4] = new Vector3f((float)(minX - camPos.field_1352), (float)(maxY - camPos.field_1351), (float)(minZ - camPos.field_1350));
        corners[5] = new Vector3f((float)(maxX - camPos.field_1352), (float)(maxY - camPos.field_1351), (float)(minZ - camPos.field_1350));
        corners[6] = new Vector3f((float)(maxX - camPos.field_1352), (float)(maxY - camPos.field_1351), (float)(maxZ - camPos.field_1350));
        corners[7] = new Vector3f((float)(minX - camPos.field_1352), (float)(maxY - camPos.field_1351), (float)(maxZ - camPos.field_1350));

        // Project all corners to screen space
        Vector4f[] screenCorners = new Vector4f[8];
        boolean allBehind = true;

        for (int i = 0; i < 8; i++) {
            Vector4f pos = new Vector4f(corners[i].x, corners[i].y, corners[i].z, 1.0f);
            pos.mul(view).mul(proj);
            screenCorners[i] = pos;

            if (pos.w > 0) {
                allBehind = false;
            }
        }

        // Don't render if all corners are behind the camera
        if (allBehind) return;

        // Convert to screen coordinates
        float[][] screenPos = new float[8][2];
        for (int i = 0; i < 8; i++) {
            if (screenCorners[i].w > 0) {
                screenPos[i][0] = ((screenCorners[i].x / screenCorners[i].w) + 1.0f) * sw / 2.0f;
                screenPos[i][1] = (1.0f - (screenCorners[i].y / screenCorners[i].w)) * sh / 2.0f;
            } else {
                screenPos[i][0] = screenCorners[i].x > 0 ? sw * 2 : -sw;
                screenPos[i][1] = screenCorners[i].y > 0 ? -sh : sh * 2;
            }
        }

        // Draw all 12 edges of the cube
        // Bottom face
        drawLine(context, screenPos[0][0], screenPos[0][1], screenPos[1][0], screenPos[1][1], color);
        drawLine(context, screenPos[1][0], screenPos[1][1], screenPos[2][0], screenPos[2][1], color);
        drawLine(context, screenPos[2][0], screenPos[2][1], screenPos[3][0], screenPos[3][1], color);
        drawLine(context, screenPos[3][0], screenPos[3][1], screenPos[0][0], screenPos[0][1], color);

        // Top face
        drawLine(context, screenPos[4][0], screenPos[4][1], screenPos[5][0], screenPos[5][1], color);
        drawLine(context, screenPos[5][0], screenPos[5][1], screenPos[6][0], screenPos[6][1], color);
        drawLine(context, screenPos[6][0], screenPos[6][1], screenPos[7][0], screenPos[7][1], color);
        drawLine(context, screenPos[7][0], screenPos[7][1], screenPos[4][0], screenPos[4][1], color);

        // Vertical edges
        drawLine(context, screenPos[0][0], screenPos[0][1], screenPos[4][0], screenPos[4][1], color);
        drawLine(context, screenPos[1][0], screenPos[1][1], screenPos[5][0], screenPos[5][1], color);
        drawLine(context, screenPos[2][0], screenPos[2][1], screenPos[6][0], screenPos[6][1], color);
        drawLine(context, screenPos[3][0], screenPos[3][1], screenPos[7][0], screenPos[7][1], color);

        // Draw tracer from center of screen to center of box
        class_243 blockCenter = blockPos.method_46558();
        Vector4f centerPos = new Vector4f(
                (float)(blockCenter.field_1352 - camPos.field_1352),
                (float)(blockCenter.field_1351 - camPos.field_1351),
                (float)(blockCenter.field_1350 - camPos.field_1350),
                1.0f
        );
        centerPos.mul(view).mul(proj);

        if (centerPos.w > 0) {
            float centerX = ((centerPos.x / centerPos.w) + 1.0f) * sw / 2.0f;
            float centerY = (1.0f - (centerPos.y / centerPos.w)) * sh / 2.0f;
            drawLine(context, sw / 2f, sh / 2f, centerX, centerY, color);
        }
    }

    private static void drawLine(class_332 context, float x1, float y1, float x2, float y2, int color) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        float length = (float) Math.sqrt(dx * dx + dy * dy);

        // Don't draw extremely long lines (likely wrapping around screen)
        if (length > 2000) return;


        var stack = context.method_51448();
        stack.pushMatrix();
        stack.translate(x1, y1);
        stack.rotate((float) Math.atan2(dy, dx));
        context.method_25294(0, 0, (int) length, 1, color);
        stack.popMatrix();
    }

    private static int pack(int r, int g, int b) {
        return (255 << 24) | (r << 16) | (g << 8) | b;
    }
}