/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.render.esp;

import com.noadsch12.modules.ModuleManager;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4184;

@Deprecated
public class PlayerESP {

    private static final Map<UUID, class_243> cachedPlayers = new ConcurrentHashMap<>();
    private static boolean initialized = false;

    public static void init() {
        if (initialized) return;
        initialized = true;
    }

    public static void render(class_332 context) {
        if (!ModuleManager.getInstance().getModule("PlayerESP").isEnabled()) return;
        init();

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || client.field_1690.field_1842) return;

        updatePlayerCache(client);
        renderAll(context, client);
    }

    private static void updatePlayerCache(class_310 client) {
        cachedPlayers.clear();

        for (class_1657 player : client.field_1687.method_18456()) {
            if (player == client.field_1724) continue; // Don't render yourself

            // IMPORTANT: Use eye position, not feet
            cachedPlayers.put(player.method_5667(), player.method_5836(1.0F));
        }
    }

    private static void renderAll(class_332 context, class_310 client) {
        int sw = client.method_22683().method_4486();
        int sh = client.method_22683().method_4502();
        float fov = (float) client.field_1690.method_41808().method_41753();
        Matrix4f projMat = client.field_1773.method_22973(fov);
        class_4184 camera = client.field_1773.method_19418();
        class_243 camPos = camera.method_19326();
        Matrix4f viewMat = new Matrix4f().rotation(camera.method_23767().conjugate());

        cachedPlayers.forEach((uuid, pos) -> {
            int color = pack(255, 0, 0, 255); // Red for players
            renderTarget(context, client, pos, camPos, projMat, viewMat, sw, sh, color);
        });
    }

    private static void renderTarget(class_332 context, class_310 client, class_243 target,
                                     class_243 camPos, Matrix4f proj, Matrix4f view, int sw, int sh, int color) {
        float dx = (float) (target.field_1352 - camPos.field_1352);
        float dy = (float) (target.field_1351 - camPos.field_1351);
        float dz = (float) (target.field_1350 - camPos.field_1350);

        Vector4f pos = new Vector4f(dx, dy, dz, 1.0f);
        pos.mul(view).mul(proj);

        if (pos.w <= 0) return;

        float screenX = ((pos.x / pos.w) + 1.0f) * sw / 2.0f;
        float screenY = (1.0f - (pos.y / pos.w)) * sh / 2.0f;

        drawTracer(context, sw / 2f, sh / 2f, screenX, screenY, color);

        var stack = context.method_51448();
        stack.pushMatrix();
        stack.translate(screenX, screenY);

        double dist = target.method_1022(camPos);
        int s = (int) class_3532.method_15350(40.0 / (dist * 0.4), 3, 20);

        context.method_25294(-s, -s, s, -s + 1, color);
        context.method_25294(-s, s - 1, s, s, color);
        context.method_25294(-s, -s + 1, -s + 1, s - 1, color);
        context.method_25294(s - 1, -s + 1, s, s - 1, color);

        stack.popMatrix();
    }

    private static void drawTracer(class_332 context, float x1, float y1, float x2, float y2, int color) {
        float dx = x2 - x1, dy = y2 - y1;
        var stack = context.method_51448();
        stack.pushMatrix();
        stack.translate(x1, y1);
        stack.rotate((float) Math.atan2(dy, dx));
        context.method_25294(0, 0, (int) Math.sqrt(dx * dx + dy * dy), 1, color);
        stack.popMatrix();
    }

    private static int pack(int r, int g, int b, int a) {
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
