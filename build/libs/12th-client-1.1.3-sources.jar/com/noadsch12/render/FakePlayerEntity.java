/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

/*
 * Aoba Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package com.noadsch12.render;

import net.minecraft.class_310;
import net.minecraft.class_742;
import net.minecraft.class_746;

public class FakePlayerEntity extends class_742 {

    public FakePlayerEntity() {
        super(class_310.method_1551().field_1687, class_310.method_1551().field_1724.method_7334());
        class_746 player = class_310.method_1551().field_1724;

        float tickDelta = class_310.method_1551().method_61966().method_60637(false);
        method_23327(player.method_73189().field_1352, player.method_73189().field_1351, player.method_73189().field_1350);
        method_5710(player.method_5705(tickDelta), player.method_5695(tickDelta));
        // this.inventory = player.getInventory();
    }

    public void despawn() {
        method_5650(class_5529.field_26999);
    }
}