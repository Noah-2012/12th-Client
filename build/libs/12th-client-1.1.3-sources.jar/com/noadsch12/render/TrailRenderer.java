package com.noadsch12.render;

import com.noadsch12.ui.ClientSettingsScreen;
import org.joml.Matrix4f;
import java.util.*;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

public class TrailRenderer {
    private static final Map<UUID, List<class_243>> trails = new HashMap<>();
    private static final int MAX_POINTS = 30;

    public static void addPoint(UUID id, class_243 pos) {
        trails.computeIfAbsent(id, k -> new ArrayList<>()).add(pos);
        if (trails.get(id).size() > MAX_POINTS) {
            trails.get(id).remove(0);
        }
    }

    // Notice we changed the parameters to match your working EntityESP.render()
    public static void render(class_4184 camera, class_4597 vertexConsumers, Matrix4f positionMatrix) {

        class_243 cameraPos = camera.method_19326();

        // We create a new MatrixStack and apply the positionMatrix just like your ESP
        class_4587 matrices = new class_4587();
        matrices.method_34425(positionMatrix);

        // We get the lines buffer - this handles the Shader and Culling for us!
        class_4588 lines = vertexConsumers.method_73477(class_1921.method_23594());
        Matrix4f matrix = matrices.method_23760().method_23761();

        for (List<class_243> points : trails.values()) {
            System.out.println("Rendering trail with " + points.size() + " points"); // DEBUG
            for (int i = 0; i < points.size() - 1; i++) {
                class_243 start = points.get(i);
                class_243 end = points.get(i + 1);

                // Draw the line using the same helper logic as your ESP
                //drawLine(lines, matrix, start, end, cameraPos, 1f, 0f, 0f);
                float x1 = (float)(start.field_1352 - cameraPos.field_1352);
                float y1 = (float)(start.field_1351 - cameraPos.field_1351);
                float z1 = (float)(start.field_1350 - cameraPos.field_1350);
                float x2 = (float)(end.field_1352 - cameraPos.field_1352);
                float y2 = (float)(end.field_1351 - cameraPos.field_1351);
                float z2 = (float)(end.field_1350 - cameraPos.field_1350);

                if (ClientSettingsScreen.trailColorIndex == 0) {
                    lines.method_22918(positionMatrix, x1, y1, z1).method_1336(255, 0, 0, 255).method_22914(0, 1, 0);
                    lines.method_22918(positionMatrix, x2, y2, z2).method_1336(255, 0, 0, 255).method_22914(0, 1, 0);
                } else if (ClientSettingsScreen.trailColorIndex == 1) {
                    lines.method_22918(positionMatrix, x1, y1, z1).method_1336(0, 0, 255, 255).method_22914(0, 1, 0);
                    lines.method_22918(positionMatrix, x2, y2, z2).method_1336(0, 0, 255, 255).method_22914(0, 1, 0);
                } else if (ClientSettingsScreen.trailColorIndex == 2) {
                    lines.method_22918(positionMatrix, x1, y1, z1).method_1336(0, 255, 0, 255).method_22914(0, 1, 0);
                    lines.method_22918(positionMatrix, x2, y2, z2).method_1336(0, 255, 0, 255).method_22914(0, 1, 0);
                } else if (ClientSettingsScreen.trailColorIndex == 3) {
                    lines.method_22918(positionMatrix, x1, y1, z1).method_1336(255, 255, 255, 255).method_22914(0, 1, 0);
                    lines.method_22918(positionMatrix, x2, y2, z2).method_1336(255, 255, 255, 255).method_22914(0, 1, 0);
                } else if (ClientSettingsScreen.trailColorIndex == 4) {
                    lines.method_22918(positionMatrix, x1, y1, z1).method_1336(0, 0, 0, 255).method_22914(0, 1, 0);
                    lines.method_22918(positionMatrix, x2, y2, z2).method_1336(0, 0, 0, 255).method_22914(0, 1, 0);
                }
            }
        }

        // Like your ESP, we let the provider handle drawing
        if (vertexConsumers instanceof class_4597.class_4598 immediate) {
            immediate.method_22994(class_1921.method_23594());
        }
    }
}