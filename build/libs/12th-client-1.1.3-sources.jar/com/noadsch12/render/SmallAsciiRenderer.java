/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.render;

import net.minecraft.class_11719;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class SmallAsciiRenderer {

    // Identifier for the monospace font
    private static final class_2960 MONO_ID = class_2960.method_60655("minecraft", "uniform");

    public static void drawAsciiArt(class_332 context, class_327 renderer, String[] lines, float x, float y, float scale, int color) {
        var matrices = context.method_51448();

        matrices.pushMatrix(); // As requested

        // Positioning and Scaling
        matrices.translate(x, y);
        matrices.scale(scale, scale);

        // Applying the specific StyleSpriteSource.Font syntax you provided
        class_2583 monoStyle = class_2583.field_24360.method_27704(new class_11719.class_11721(MONO_ID));

        float lineOffset = 0;
        float lineSpacing = 9.0f; // Tighter spacing for ASCII

        for (String line : lines) {

            class_2561 formattedLine = class_2561.method_43470(line).method_10862(monoStyle);

            context.method_51439(renderer, formattedLine, 0, (int)lineOffset, color, false);
            lineOffset += lineSpacing;
        }

        matrices.popMatrix(); // As requested
    }
}