/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.render.fx;

import com.noadsch12.modules.impl.render.TrailSettings;
import org.joml.Matrix4f;
import java.util.*;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

public class TrailRenderer {
    private static final Map<UUID, List<class_243>> trails = new HashMap<>();
    private static final int MAX_POINTS = 30;

    public static void addPoint(UUID id, class_243 pos) {
        trails.computeIfAbsent(id, k -> new ArrayList<>()).add(pos);
        if (trails.get(id).size() > MAX_POINTS) {
            trails.get(id).removeFirst();
        }
    }

    // Notice we changed the parameters to match your working EntityESP.render()
    public static void render(class_4184 camera, class_4597 vertexConsumers, Matrix4f positionMatrix) {

        class_243 cameraPos = camera.method_19326();

        // We create a new MatrixStack and apply the positionMatrix just like your ESP
        class_4587 matrices = new class_4587();
        matrices.method_34425(positionMatrix);

        // We get the lines buffer - this handles the Shader and Culling for us!
        class_4588 lines = vertexConsumers.method_73477(class_1921.method_23594());

        for (List<class_243> points : trails.values()) {
            for (int i = 0; i < points.size() - 1; i++) {
                class_243 start = points.get(i);
                class_243 end = points.get(i + 1);

                // Draw the line using the same helper logic as your ESP
                //drawLine(lines, matrix, start, end, cameraPos, 1f, 0f, 0f);
                float x1 = (float)(start.field_1352 - cameraPos.field_1352);
                float y1 = (float)(start.field_1351 - cameraPos.field_1351);
                float z1 = (float)(start.field_1350 - cameraPos.field_1350);
                float x2 = (float)(end.field_1352 - cameraPos.field_1352);
                float y2 = (float)(end.field_1351 - cameraPos.field_1351);
                float z2 = (float)(end.field_1350 - cameraPos.field_1350);

                int[] rgb = TrailSettings.getCurrentColorRGB();
                lines.method_22918(positionMatrix, x1, y1, z1).method_1336(rgb[0], rgb[1], rgb[2], 255).method_22914(0, 1, 0);
                lines.method_22918(positionMatrix, x2, y2, z2).method_1336(rgb[0], rgb[1], rgb[2], 255).method_22914(0, 1, 0);
            }
        }

        if (vertexConsumers instanceof class_4597.class_4598 immediate) {
            immediate.method_22994(class_1921.method_23594());
        }
    }
}