/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 */

package com.noadsch12.render.fx;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.noadsch12.TwelfthClient;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_10789;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1541;
import net.minecraft.class_1548;
import net.minecraft.class_1701;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_290;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4969;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;

public class ExplosiveScanner {

    private static final float TNT_RADIUS = 4.0f;
    private static final float CREEPER_RADIUS = 3.0f;
    private static final float CRYSTAL_RADIUS = 6.0f;
    private static final float ANCHOR_RADIUS = 5.0f;
    private static final float MINECART_TNT_RADIUS = 4.0f;

    private static final class_1921 OVERLAY_LINES = class_1921.method_24049(
            "explosive_lines",
            1536,
            false,
            true,
            RenderPipeline.builder()
                    .withVertexShader("core/rendertype_lines")
                    .withFragmentShader("core/rendertype_lines")
                    .withVertexFormat(class_290.field_29337, VertexFormat.class_5596.field_27377)
                    .withUniform("DynamicTransforms", class_10789.field_60031)
                    .withUniform("Fog", class_10789.field_60031)
                    .withUniform("Globals", class_10789.field_60031)
                    .withUniform("Projection", class_10789.field_60031)
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withCull(false)
                    .withBlend(BlendFunction.TRANSLUCENT)
                    .withLocation(TwelfthClient.identifier("esp_lines"))
                    .build(),
            class_1921.class_4688.method_23598()
                    .method_23617(false)
    );

    public static void init() {
        // BEFORE_DEBUG_RENDER is the modern way to draw custom world-space lines
        WorldRenderEvents.BEFORE_DEBUG_RENDER.register(ExplosiveScanner::render);
    }

    private static void render(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || client.field_1724 == null) return;

        class_4587 matrices = context.matrices();
        class_4597 consumers = context.consumers();
        if (consumers == null) return;

        class_4588 buffer = consumers.method_73477(OVERLAY_LINES);

        // 1. Scan for Explosive Entities
        for (class_1297 entity : client.field_1687.method_18112()) {
            float radius = 0;
            if (entity instanceof class_1541) {
                radius = TNT_RADIUS;
            } else if (entity instanceof class_1548 creeper && creeper.method_7007() > 0) {
                radius = CREEPER_RADIUS;
            } else if (entity instanceof class_1511) {
                radius = CRYSTAL_RADIUS;
            } else if (entity instanceof class_1701) {
                radius = MINECART_TNT_RADIUS;
            }

            if (radius > 0) {
                drawDangerZone(context, matrices, buffer, entity.method_73189(), radius, client.field_1724.method_73189());
            }
        }

        // 2. Scan for Respawn Anchors (Checking a 16-block radius around player)
        class_2338 playerBlockPos = client.field_1724.method_24515();
        for (class_2338 pos : class_2338.method_10097(playerBlockPos.method_10069(-16, -8, -16), playerBlockPos.method_10069(16, 8, 16))) {
            var state = client.field_1687.method_8320(pos);
            if (state.method_27852(class_2246.field_23152)) {
                // Anchors only explode in the Overworld if they have at least 1 charge
                int charges = state.method_11654(class_4969.field_23153);
                if (charges > 0 && !client.field_1687.method_8597().comp_649()) {
                    drawDangerZone(context, matrices, buffer, pos.method_46558(), ANCHOR_RADIUS, client.field_1724.method_73189());
                }
            }
        }
    }

    private static void drawDangerZone(WorldRenderContext context, class_4587 matrices, class_4588 buffer, class_243 source, float radius, class_243 playerPos) {
        matrices.method_22903();

        class_243 camera = context.gameRenderer().method_19418().method_19326();
        double x = source.field_1352 - camera.field_1352;
        double y = source.field_1351 - camera.field_1351;
        double z = source.field_1350 - camera.field_1350;

        matrices.method_22904(x, y, z);

        float r = 0, g = 1, b = 0;
        if (playerPos.method_1022(source) <= radius) {
            r = 1.0f; g = 0.0f;
        }

        Matrix4f model = matrices.method_23760().method_23761();
        int segments = 64;
        float height = 2.0f; // Height of the cylinder

        for (int i = 0; i < segments; i++) {
            double angle = i * Math.PI * 2 / segments;
            double nextAngle = (i + 1) * Math.PI * 2 / segments;

            float x1 = (float) (Math.cos(angle) * radius);
            float z1 = (float) (Math.sin(angle) * radius);
            float x2 = (float) (Math.cos(nextAngle) * radius);
            float z2 = (float) (Math.sin(nextAngle) * radius);

            // 1. Draw Bottom Ring
            buffer.method_22918(model, x1, 0.05f, z1).method_22915(r, g, b, 1.0f).method_22914(0, 1, 0);
            buffer.method_22918(model, x2, 0.05f, z2).method_22915(r, g, b, 1.0f).method_22914(0, 1, 0);

            // 2. Draw Top Ring (at 'height' meters up)
            buffer.method_22918(model, x1, height, z1).method_22915(r, g, b, 1.0f).method_22914(0, 1, 0);
            buffer.method_22918(model, x2, height, z2).method_22915(r, g, b, 1.0f).method_22914(0, 1, 0);

            // 3. Draw Vertical Pillars (every 8th segment to avoid clutter)
            if (i % 8 == 0) {
                buffer.method_22918(model, x1, 0.05f, z1).method_22915(r, g, b, 1.0f).method_22914(0, 1, 0);
                buffer.method_22918(model, x1, height, z1).method_22915(r, g, b, 1.0f).method_22914(0, 1, 0);
            }
        }

        matrices.method_22909();
    }
}