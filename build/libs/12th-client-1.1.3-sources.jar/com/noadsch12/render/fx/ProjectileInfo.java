/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.render.fx;

import net.minecraft.class_1657;
import net.minecraft.class_1744;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1779;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1823;
import net.minecraft.class_1835;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4537;
import net.minecraft.class_9239;
import net.minecraft.class_9278;
import net.minecraft.class_9334;

public class ProjectileInfo {

    public double gravity;
    public double drag;
    public class_243 initialVelocity;
    public boolean isReadyToShoot;
    public class_243 offset;
    public class_243 position;
    public boolean hasWaterCollision;

    public ProjectileInfo(double gravity, double drag, class_243 initialVelocity, boolean isReadyToShoot, class_243 offset, class_243 position, boolean hasWaterCollision) {
        this.gravity = gravity;
        this.drag = drag;
        this.initialVelocity = initialVelocity;
        this.isReadyToShoot = isReadyToShoot;
        this.offset = offset;
        this.position = position;
        this.hasWaterCollision = hasWaterCollision;
    }

    static public ProjectileInfo getItemsInfo(class_1792 item, class_1657 player) {
        double gravity = 0.05;
        double drag = 0.99;
        if (item instanceof class_1753) {

            int useTicks = player.method_6048();
            float pull = class_1753.method_7722(useTicks);

            class_243 vel = player.method_5828(1.0F).method_1021(3.0 * pull);
            class_243 offset = new class_243(0.2, -0.06, 0.2);

            return new ProjectileInfo(gravity, drag, vel, pull > 0, offset, null, false);

        } else if (item instanceof class_1764) {

            class_243 vel = player.method_5828(1.0F).method_1021(3.15);
            class_243 offset = new class_243(0, -0.06, 0.03);

            class_9278 chargedProjectilesComponent = player.method_6047().method_58694(class_9334.field_49649);

            for (class_1799 projectile : chargedProjectilesComponent.method_57437()) {
                if (projectile.method_31574(class_1802.field_8639)) {
                    vel = player.method_5828(1.0F).method_1021(1.6F);
                    gravity = 0;
                } else if (projectile.method_7909() instanceof class_1744) {

                }
            }

            return new ProjectileInfo(gravity, drag, vel, class_1764.method_7781(player.method_6047()), offset, null, false);

        } else if (item instanceof class_1835) {

            int useTicks = player.method_6048();

            class_243 vel = player.method_5828(1.0F).method_1021(class_1835.field_30928);
            class_243 offset = new class_243(0.2, 0.1, 0.2);

            return new ProjectileInfo(gravity, drag, vel, useTicks >= class_1835.field_30926, offset, null, false);

        } else if (item instanceof class_1823 || item instanceof class_1771 || item instanceof class_1776) {

            gravity = 0.03;

            class_243 vel = player.method_5828(1.0F).method_1021(1.5F);
            class_243 offset = new class_243(0.2, -0.06, 0.2);

            return new ProjectileInfo(gravity, drag, vel, true, offset, null, false);

        } else if (item instanceof class_9239) {

            gravity = 0;
            drag = 1.0;

            class_243 vel = player.method_5828(1.0F).method_1021(1.0);
            class_243 offset = new class_243(0.2, -0.06, 0.2);

            return new ProjectileInfo(gravity, drag, vel, true, offset, null, false);

        } else if (item instanceof class_4537) {

            class_243 dir = player.method_5828(1.0F).method_1031(0, 0.1, 0);
            dir = dir.method_1029();

            class_243 vel = dir.method_1021(0.5);
            class_243 offset = new class_243(0.2, -0.06, 0.2);

            return new ProjectileInfo(gravity, drag, vel, true, offset, null, false);

        }  else if (item instanceof class_1779) {

            gravity = 0.07;
            drag = 0.99;

            class_243 dir = player.method_5828(1.0F).method_1031(0, 0.1, 0);
            dir = dir.method_1029();

            class_243 vel = dir.method_1021(0.7);
            class_243 offset = new class_243(0.2, -0.06, 0.2);

            return new ProjectileInfo(gravity, drag, vel, true, offset, null, false);

        }  else if (item instanceof class_1787 && player.field_7513 == null) {

            float f = player.method_36455();
            float g = player.method_36454();
            float h = class_3532.method_15362(-g * (float) (Math.PI / 180.0) - (float) Math.PI);
            float i = class_3532.method_15374(-g * (float) (Math.PI / 180.0) - (float) Math.PI);
            float j = -class_3532.method_15362(-f * (float) (Math.PI / 180.0));
            float k = class_3532.method_15374(-f * (float) (Math.PI / 180.0));
            class_243 pos = new class_243(player.method_23317() - i * 0.3,player.method_23320(),player.method_23321() - h * 0.3);
            class_243 vec3d = new class_243(-i, class_3532.method_15363(-(k / j), -5.0F, 5.0F), -h);
            double m = vec3d.method_1033();
            vec3d = vec3d.method_18805(
                    0.6 / m + 0.5,
                    0.6 / m + 0.5,
                    0.6 / m + 0.5
            );
            class_243 vel = vec3d;

            gravity = 0.03;
            drag = 0.92;

            class_243 offset = new class_243(0.16, -0.06, 0.2);

            return new ProjectileInfo(gravity, drag, vel, true, offset, pos, true);

        }

        return new ProjectileInfo(0.0, 0.0, new class_243(0.0, 0.0, 0.0), false, new class_243(0.0, 0.0, 0.0), null, false);
    }
}