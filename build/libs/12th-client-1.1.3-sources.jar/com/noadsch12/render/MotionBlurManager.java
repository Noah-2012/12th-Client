/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.render;

import java.io.IOException;
import java.util.Set;
import net.minecraft.class_279;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class MotionBlurManager {
    private static final class_310 mc = class_310.method_1551();
    private static class_279 motionBlur;

    private static final class_2960 MAIN_TARGET = class_2960.method_60656("main");
    // Ensure this path matches your corrected JSON location
    private static final class_2960 BLUR_ID = class_2960.method_60655("12th-client", "post/motion_blur.json");

    public static void init() {
        //if (motionBlur != null) {
        if (false) {
            motionBlur.close();
            motionBlur = null;
        }

        // Updated to handle the specific LoadException/IOException
        motionBlur = mc.method_62887().method_62941(BLUR_ID, Set.of(MAIN_TARGET));
    }

    public static void render() {

        //if (motionBlur != null && isEnabled()) {
        if (false) {
            // 1. Create or get the MatrixStack
            // In 1.21.4, for custom calculations, you can just instantiate one:
            net.minecraft.class_4587 stack = new net.minecraft.class_4587();

            // 2. Apply your specific logic using the 'stack' object
            org.joml.Matrix3x2f velocityMatrix = new org.joml.Matrix3x2f();

            stack.method_22903(); // As per your [2026-01-11] note

            // Using your specific signature: translate(float x, float y, Matrix3x2f dest)
            // stack.translate(x, y, velocityMatrix);

            stack.method_22909(); // As per your [2026-01-11] note

            // 3. Render the shader
            motionBlur.method_1258(mc.method_1522(), (net.minecraft.class_9922) mc.method_1522());
        }
    }

    public static boolean isEnabled() {
        // You can add your config check here
        return true;
    }

    public static void onResize() {
        // Re-init is necessary in the new system to rebuild targets for the new resolution
        init();
    }
}