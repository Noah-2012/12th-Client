package com.noadsch12.render;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.joml.Matrix4f;

public class EntityESP {

    private static boolean enabled = true;

    public static void setEnabled(boolean enabled) {
        EntityESP.enabled = enabled;
    }

    public static boolean isEnabled() {
        return enabled;
    }

    public static void render(class_4184 camera, class_4597 vertexConsumers, Matrix4f positionMatrix) {
        if (!enabled) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        class_243 cameraPos = camera.method_19326();
        int simulationDistance = mc.field_1690.method_42510().method_41753() * 16;

        class_4587 matrices = new class_4587();
        matrices.method_34425(positionMatrix);

        class_4588 lines = vertexConsumers.method_73477(class_1921.method_23594());
        Matrix4f matrix = matrices.method_23760().method_23761();

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity == mc.field_1724) continue;
            if (entity.method_5858(mc.field_1724) > simulationDistance * simulationDistance) continue;

            class_238 box = entity.method_5829();
            float[] color = getEntityColor(entity);

            drawBox(lines, matrix, box, cameraPos, color[0], color[1], color[2]);
        }

        if (vertexConsumers instanceof class_4597.class_4598 immediate) {
            immediate.method_22994(class_1921.method_23594());
        }
    }

    private static void drawBox(class_4588 buffer, Matrix4f matrix, class_238 box, class_243 cam, float r, float g, float b) {
        float x1 = (float)(box.field_1323 - cam.field_1352);
        float y1 = (float)(box.field_1322 - cam.field_1351);
        float z1 = (float)(box.field_1321 - cam.field_1350);
        float x2 = (float)(box.field_1320 - cam.field_1352);
        float y2 = (float)(box.field_1325 - cam.field_1351);
        float z2 = (float)(box.field_1324 - cam.field_1350);

        // Bottom
        line(buffer, matrix, x1, y1, z1, x2, y1, z1, r, g, b);
        line(buffer, matrix, x2, y1, z1, x2, y1, z2, r, g, b);
        line(buffer, matrix, x2, y1, z2, x1, y1, z2, r, g, b);
        line(buffer, matrix, x1, y1, z2, x1, y1, z1, r, g, b);
        // Top
        line(buffer, matrix, x1, y2, z1, x2, y2, z1, r, g, b);
        line(buffer, matrix, x2, y2, z1, x2, y2, z2, r, g, b);
        line(buffer, matrix, x2, y2, z2, x1, y2, z2, r, g, b);
        line(buffer, matrix, x1, y2, z2, x1, y2, z1, r, g, b);
        // Verticals
        line(buffer, matrix, x1, y1, z1, x1, y2, z1, r, g, b);
        line(buffer, matrix, x2, y1, z1, x2, y2, z1, r, g, b);
        line(buffer, matrix, x2, y1, z2, x2, y2, z2, r, g, b);
        line(buffer, matrix, x1, y1, z2, x1, y2, z2, r, g, b);
    }

    private static void line(class_4588 buffer, Matrix4f matrix, float x1, float y1, float z1, float x2, float y2, float z2, float r, float g, float b) {
        buffer.method_22918(matrix, x1, y1, z1).method_22915(r, g, b, 1f).method_22914(0, 1, 0);
        buffer.method_22918(matrix, x2, y2, z2).method_22915(r, g, b, 1f).method_22914(0, 1, 0);
    }

    private static float[] getEntityColor(class_1297 entity) {
        if (entity instanceof class_1657) {
            return new float[]{1.0f, 0.0f, 0.0f};
        } else if (entity.method_5864().method_5891().method_6136()) {
            return new float[]{0.0f, 1.0f, 0.0f};
        } else {
            return new float[]{1.0f, 1.0f, 0.0f};
        }
    }
}