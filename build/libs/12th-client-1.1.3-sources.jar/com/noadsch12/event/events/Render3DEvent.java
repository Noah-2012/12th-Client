/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

/*
 * Aoba Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package com.noadsch12.event.events;

import java.util.ArrayList;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4604;
import net.minecraft.class_9779;
import com.noadsch12.event.listeners.AbstractListener;
import com.noadsch12.event.listeners.Render3DListener;

public class Render3DEvent extends AbstractEvent {
	class_4587 matrices;
	class_4604 frustum;
	class_9779 renderTickCounter;
	class_4184 camera;

	public class_4587 GetMatrix() {
		return matrices;
	}

	public class_9779 getRenderTickCounter() {
		return renderTickCounter;
	}

	public class_4604 getFrustum() {
		return frustum;
	}

	public class_4184 getCamera() {
		return camera;
	}

	public Render3DEvent(class_4587 matrix4f, class_4604 frustum, class_4184 camera, class_9779 renderTickCounter) {
		matrices = matrix4f;
		this.renderTickCounter = renderTickCounter;
		this.frustum = frustum;
		this.camera = camera;
	}

	@Override
	public void Fire(ArrayList<? extends AbstractListener> listeners) {
		for (AbstractListener listener : listeners) {
			Render3DListener renderListener = (Render3DListener) listener;
			renderListener.onRender(this);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Class<Render3DListener> GetListenerClassType() {
		return Render3DListener.class;
	}
}