/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

/*
 * Aoba Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package com.noadsch12.event.events;

import java.util.ArrayList;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import com.noadsch12.event.listeners.AbstractListener;
import com.noadsch12.event.listeners.Render2DListener;

public class Render2DEvent extends AbstractEvent {
	private final class_332 matrices;
	private final class_9779 renderTickCounter;

	public class_332 getDrawContext() {
		return matrices;
	}

	public class_9779 getRenderTickCounter() {
		return renderTickCounter;
	}

	public Render2DEvent(class_332 context, class_9779 renderTickCounter) {
		matrices = context;
		this.renderTickCounter = renderTickCounter;
	}

	@Override
	public void Fire(ArrayList<? extends AbstractListener> listeners) {
		for (AbstractListener listener : listeners) {
			Render2DListener renderListener = (Render2DListener) listener;
			renderListener.onRender(this);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Class<Render2DListener> GetListenerClassType() {
		return Render2DListener.class;
	}
}
