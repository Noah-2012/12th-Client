/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

/*
 * Aoba Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * Licensed under the GNU General Public License, Version 3 or later.
 * See <http://www.gnu.org/licenses/>.
 */

package com.noadsch12.event.events;

import java.util.ArrayList;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import com.noadsch12.event.listeners.AbstractListener;
import com.noadsch12.event.listeners.BlockStateListener;

public class BlockStateEvent extends AbstractEvent {
	private final class_2338 blockPos;
	private final class_2680 blockState;
	private final class_2680 previousBlockState;

	public BlockStateEvent(class_2338 blockPos, class_2680 state, class_2680 previousState) {
		this.blockPos = blockPos;
		blockState = state;
		previousBlockState = previousState;
	}

	public class_2338 getBlockPos() {
		return blockPos;
	}

	public class_2680 getBlockState() {
		return blockState;
	}

	public class_2680 getPreviousBlockState() {
		return previousBlockState;
	}

	@Override
	public void Fire(ArrayList<? extends AbstractListener> listeners) {
		for (AbstractListener listener : listeners) {
			BlockStateListener blockStateListener = (BlockStateListener) listener;
			blockStateListener.onBlockStateChanged(this);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Class<BlockStateListener> GetListenerClassType() {
		return BlockStateListener.class;
	}
}