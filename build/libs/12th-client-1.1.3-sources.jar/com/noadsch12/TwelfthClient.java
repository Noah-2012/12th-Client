package com.noadsch12;

import com.noadsch12.discord.DiscordRichPresenceManager;
import com.noadsch12.render.EntityCulling;
import com.noadsch12.ui.ClientSettingsScreen;
import com.noadsch12.ui.ModConfigScreen;
import com.noadsch12.util.TwelfthCommand;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TwelfthClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("12thClient");
    private float tickCounter = 1.0f;
    private static final int UPDATE_INTERVAL = 100; // Alle 5 Sekunden (100 Ticks)
    private static class_304 guiKeyBinding;
    public static boolean fastguiopen = false;
    private boolean isMenuAlreadyOpen = false;

    @Override
    public void onInitializeClient() {
        LOGGER.info("12th Client - Client initialized!");
        HotbarHelper.register();
        TwelfthCommand.register();
        EntityCulling.register();

        class_304.class_11900 clientCategory = class_304.class_11900.method_74698(class_2960.method_60654("category.noadsch12.client"));

        guiKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304("key.client.settings_gui", class_3675.class_307.field_1668, GLFW.GLFW_KEY_RIGHT_SHIFT, clientCategory));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {while (guiKeyBinding.method_1436()) if (client.field_1755 == null) {client.method_1507(new ClientSettingsScreen(null));}});

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.method_22683() == null || client.field_1724 == null) return;

            boolean isKeyDown = class_3675.method_15987(client.method_22683(), GLFW.GLFW_KEY_GRAVE_ACCENT);

            if (isKeyDown) {
                // Only open if we haven't ALREADY sent the "open" command
                if (!isMenuAlreadyOpen && client.field_1755 == null) {
                    client.method_1507(new ClientSettingsScreen(null));
                    isMenuAlreadyOpen = true;
                    System.out.println("Menu opened!"); // Debug check in console
                }
            } else {
                // Only close if we are currently in our "Open" state
                if (isMenuAlreadyOpen) {
                    if (client.field_1755 instanceof ClientSettingsScreen) {
                        client.method_1507(null);
                    }
                    isMenuAlreadyOpen = false;
                    System.out.println("Menu closed!"); // Debug check in console
                }
            }

            // Safety: If the user presses ESC manually, reset our state variable
            if (isMenuAlreadyOpen && client.field_1755 == null) {
                isMenuAlreadyOpen = false;
            }
        });

        // Discord RPC initialisieren
        DiscordRichPresenceManager.init();

        // Tick Handler für Updates
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Discord Callbacks jedes Tick verarbeiten (wichtig!)
            DiscordRichPresenceManager.tick();

            // Presence nur alle X Ticks aktualisieren
            tickCounter++;
            if (tickCounter >= UPDATE_INTERVAL) {
                tickCounter = 0;
                DiscordRichPresenceManager.updateForInGame();
            }
        });

        // Shutdown Hook für sauberes Beenden
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            DiscordRichPresenceManager.shutdown();
        });

        // Update bei Client-Start
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            DiscordRichPresenceManager.updatePresence("Client gestartet", "Im Hauptmenü");
        });
    }
}
