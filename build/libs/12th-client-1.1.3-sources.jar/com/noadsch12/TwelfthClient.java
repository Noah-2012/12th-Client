package com.noadsch12;

import com.noadsch12.discord.DiscordRichPresenceManager;
import com.noadsch12.render.EntityCulling;
import com.noadsch12.ui.ClientSettingsScreen;
import com.noadsch12.util.TwelfthCommand;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TwelfthClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("12thClient");
    private int tickCounter = 0;
    private static final int UPDATE_INTERVAL = 100; // Alle 5 Sekunden (100 Ticks)
    private static class_304 guiKeyBinding;

    @Override
    public void onInitializeClient() {
        LOGGER.info("12th Client - Client initialized!");
        HotbarHelper.register();
        TwelfthCommand.register();
        EntityCulling.register();

        class_304.class_11900 clientCategory = class_304.class_11900.method_74698(class_2960.method_60654("category.noadsch12.client"));

        guiKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304("key.client.settings_gui", class_3675.class_307.field_1668, GLFW.GLFW_KEY_RIGHT_SHIFT, clientCategory));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {while (guiKeyBinding.method_1436()) if (client.field_1755 == null) {client.method_1507(new ClientSettingsScreen(null));}});

        // Discord RPC initialisieren
        DiscordRichPresenceManager.init();

        // Tick Handler für Updates
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Discord Callbacks jedes Tick verarbeiten (wichtig!)
            DiscordRichPresenceManager.tick();

            // Presence nur alle X Ticks aktualisieren
            tickCounter++;
            if (tickCounter >= UPDATE_INTERVAL) {
                tickCounter = 0;
                DiscordRichPresenceManager.updateForInGame();
            }
        });

        // Shutdown Hook für sauberes Beenden
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            DiscordRichPresenceManager.shutdown();
        });

        // Update bei Client-Start
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            DiscordRichPresenceManager.updatePresence("Client gestartet", "Im Hauptmenü");
        });
    }
}
