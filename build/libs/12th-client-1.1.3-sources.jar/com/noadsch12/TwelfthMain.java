/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12;

import com.noadsch12.networking.ClientStatusPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_3222;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TwelfthMain implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("12thClient");



    @Override
    public void onInitialize() {
        LOGGER.info("12th Client - Main initialized!");
            // Register the payload
        PayloadTypeRegistry.playC2S().register(ClientStatusPayload.ID, ClientStatusPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(ClientStatusPayload.ID, ClientStatusPayload.CODEC);

            // Notify everyone when a user joins
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ClientStatusPayload joinPacket = new ClientStatusPayload(handler.field_14140.method_5667());
            for (class_3222 player : server.method_3760().method_14571()) {
                ServerPlayNetworking.send(player, joinPacket); // Tell others about me
                ServerPlayNetworking.send(handler.field_14140, new ClientStatusPayload(player.method_5667())); // Tell me about others
            }
        });
    }
}