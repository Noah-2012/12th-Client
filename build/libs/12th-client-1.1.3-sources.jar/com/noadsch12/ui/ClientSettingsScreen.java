package com.noadsch12.ui;

import io.wispforest.owo.ui.core.ParentComponent;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10799;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

class Dot {
    float x, y, vx, vy;
    Dot(int w, int h) {
        x = (float)Math.random() * w;
        y = (float)Math.random() * h;
        vx = ((float)Math.random() - 0.5f) * 0.5f;
        vy = ((float)Math.random() - 0.5f) * 0.5f;
    }
    void update(int w, int h, double mouseX, double mouseY) {
        x += vx; y += vy;

        double dx = x - mouseX;
        double dy = y - mouseY;
        double dist = Math.sqrt(dx*dx + dy*dy);

        if (dist < 40) {
            x += dx * 0.05;
            y += dy * 0.05;
        }

        if (x < 0 || x > w) vx *= -1;
        if (y < 0 || y > h) vy *= -1;
    }
}

public class ClientSettingsScreen extends class_437 {
    private final class_437 parent;
    private final class_2561 title;
    public static boolean ProjectileDingEnabled = true;
    public static boolean jumpToFoodEnabled = true;
    public static boolean EntityCullingEnabled = true;
    public static boolean ProjectileTrailEnabled = true;
    public static boolean AutoTotemEnabled = true;
    public static boolean AutoArmorEnabled = true;
    public static boolean AutoRefillEnabled = true;
    public static boolean AutoToolEnabled = true;
    private static final String[] TRAIL_NAMES = {"Totem", "Explosion", "Hearts", "Line Trail"};
    private static final String[] TRAIL_COLORS = {"Red", "Blue", "Green", "White", "Black"};
    public static int trailIndex = 0;
    public static int trailColorIndex = 0;

    private final List<Dot> dots = new ArrayList<>();

    public ClientSettingsScreen(class_437 parent) {
        super(class_2561.method_43470(""));
        this.parent = parent;
        this.field_22785 = class_2561.method_43470("12th Client Settings");
    }

    @Override
    protected void method_25426() {
        if(dots.isEmpty()) {
            for(int i = 0; i < 90; i++) dots.add(new Dot(this.field_22789, this.field_22790));
        }

        super.method_25426();

        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        int bWidth = 150;
        int bHeight = 20;

        int btcWidth = 150;
        int btcHeight = 10;

        int utilsX = centerX - 250;

        // Jump to Food Toggle Button
        this.method_37063(class_4185.method_46430(
                        class_2561.method_43470("Jump to Food: " + (jumpToFoodEnabled ? "§aON" : "§cOFF")),
                        btn -> {
                            jumpToFoodEnabled = !jumpToFoodEnabled;
                            btn.method_25355(class_2561.method_43470("Jump to Food: " + (jumpToFoodEnabled ? "§aON" : "§cOFF")));
                        }
                )
                .method_46433(utilsX, centerY - 20)
                .method_46437(bWidth, bHeight)
                .method_46431());

        this.method_37063(class_4185.method_46430(
                        class_2561.method_43470("Entity Culling: " + (EntityCullingEnabled ? "§aOn by Default" : "§cOnly by Command")),
                        btn -> {
                            EntityCullingEnabled =! EntityCullingEnabled;
                            btn.method_25355(class_2561.method_43470("Entity Culling: " + (EntityCullingEnabled ? "§aOn by Default" : "§cOnly by Command")));
                        }
                )
                .method_46433(utilsX, centerY + 4)
                .method_46437(bWidth, bHeight)
                .method_46431());

        int cheatsX = centerX + 100;

        this.method_37063(class_4185.method_46430(
                        class_2561.method_43470("Auto Totem: " + (AutoTotemEnabled ? "§aON" : "§cOFF")),
                        btn -> {
                            AutoTotemEnabled =! AutoTotemEnabled;
                            btn.method_25355(class_2561.method_43470("Auto Totem: " + (AutoTotemEnabled ? "§aON" : "§cOFF")));
                        }
                )
                .method_46433(cheatsX, centerY - 20)
                .method_46437(bWidth, bHeight)
                .method_46431());

        this.method_37063(class_4185.method_46430(
                        class_2561.method_43470("Auto Armor: " + (AutoArmorEnabled ? "§aON" : "§cOFF")),
                        btn -> {
                            AutoArmorEnabled =! AutoArmorEnabled;
                            btn.method_25355(class_2561.method_43470("Auto Armor: " + (AutoArmorEnabled ? "§aON" : "§cOFF")));
                        }
                )
                .method_46433(cheatsX, centerY + 4)
                .method_46437(bWidth, bHeight)
                .method_46431());

        this.method_37063(class_4185.method_46430(
                        class_2561.method_43470("Auto Refill: " + (AutoRefillEnabled ? "§aON" : "§cOFF")),
                        btn -> {
                            AutoRefillEnabled =! AutoRefillEnabled;
                            btn.method_25355(class_2561.method_43470("Auto Refill: " + (AutoRefillEnabled ? "§aON" : "§cOFF")));
                        }
                )
                .method_46433(cheatsX, centerY + 28)
                .method_46437(bWidth, bHeight)
                .method_46431());

        this.method_37063(class_4185.method_46430(
                        class_2561.method_43470("Auto Tool: " + (AutoToolEnabled ? "§aON" : "§cOFF")),
                        btn -> {
                            AutoToolEnabled =! AutoToolEnabled;
                            btn.method_25355(class_2561.method_43470("Auto Tool: " + (AutoToolEnabled ? "§aON" : "§cOFF")));
                        }
                )
                .method_46433(cheatsX, centerY + 52)
                .method_46437(bWidth, bHeight)
                .method_46431());

        int renderX = centerX - (bWidth / 2);

        class_4185 trailColorButton = class_4185.method_46430(
                        class_2561.method_43470("Trail Color: " + TRAIL_COLORS[trailColorIndex]),
                        btn -> {
                            trailColorIndex = (trailColorIndex + 1) % TRAIL_COLORS.length;
                            btn.method_25355(class_2561.method_43470("Trail Color: " + TRAIL_COLORS[trailColorIndex]));
                        }
                )
                .method_46433(renderX, centerY + 48)
                .method_46437(btcWidth, btcHeight)
                .method_46431();

        if (trailIndex != 3) {
            trailColorButton.field_22763 = false;
        }
        this.method_37063(trailColorButton);

        class_4185 trailButton = class_4185.method_46430(
                        class_2561.method_43470("Trail Mode: " + TRAIL_NAMES[trailIndex]),
                        btn -> {
                            this.method_37066(trailColorButton);
                            trailIndex = (trailIndex + 1) % TRAIL_NAMES.length;
                            if (trailIndex == 3) {
                                trailColorButton.field_22763 = true;
                            } else {
                                trailColorButton.field_22763 = false;
                            }
                            this.method_37063(trailColorButton);
                            btn.method_25355(class_2561.method_43470("Trail Mode: " + TRAIL_NAMES[trailIndex]));
                        }
                )
                .method_46433(renderX, centerY + 28)
                .method_46437(bWidth, bHeight)
                .method_46431();

        this.method_37063(class_4185.method_46430(
                        class_2561.method_43470("Projectile Ding: " + (ProjectileDingEnabled ? "§aON" : "§cOFF")),
                        btn -> {
                            ProjectileDingEnabled = !ProjectileDingEnabled;
                            btn.method_25355(class_2561.method_43470("Projectile Ding: " + (ProjectileDingEnabled ? "§aON" : "§cOFF")));
                        }
                )
                .method_46433(renderX, centerY - 20)
                .method_46437(bWidth, bHeight)
                .method_46431());

        this.method_37063(class_4185.method_46430(
                        class_2561.method_43470("Projectile Trail: " + (ProjectileTrailEnabled ? "§aON" : "§cOFF")),
                        btn -> {
                            ProjectileTrailEnabled = !ProjectileTrailEnabled;
                            this.method_37066(trailButton);
                            trailButton.field_22763 = ProjectileTrailEnabled;
                            this.method_37063(trailButton);
                            btn.method_25355(class_2561.method_43470("Projectile Trail: " + (ProjectileTrailEnabled ? "§aON" : "§cOFF")));
                        }
                )
                .method_46433(renderX, centerY + 4)
                .method_46437(bWidth, bHeight)
                .method_46431());

        this.method_37063(trailButton);

        this.method_25422();

        // Back Button
        this.method_37063(class_4185.method_46430(
                        class_2561.method_43470("Back"),
                        btn -> this.method_25419()
                )
                .method_46433(centerX - 50, this.field_22790 - 40)
                .method_46437(100, 20)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        if (this.field_22787.field_1687 != null) {
            // --- IN-GAME HUD MODE ---
            // This renders the blurred world background when opened via Keybind
            //context.applyBlur();
            //context.fill(0, 0, this.width, this.height, 0x90101010);
            BlurHandler.executeBlur(context, this.field_22789, this.field_22790, 5.0f);
            super.method_25394(context, mouseX, mouseY, deltaTicks);
        } else {
            // --- MAIN MENU MODE ---
            // Your custom Particle/Dot background logic
            context.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF101010);

            for (Dot dot : dots) {
                dot.update(this.field_22789, this.field_22790, mouseX, mouseY);
                context.method_25294((int)dot.x, (int)dot.y, (int)dot.x + 2, (int)dot.y + 2, 0x55FFFFFF);
            }

            for (int i = 0; i < dots.size(); i++) {
                Dot a = dots.get(i);
                for (int j = i + 1; j < dots.size(); j++) {
                    Dot b = dots.get(j);
                    double dist = Math.sqrt(Math.pow(a.x - b.x, 2) + Math.pow(a.y - b.y, 2));

                    if (dist < 25) {
                        int alpha = (int) ((1.0 - (dist / 50.0)) * 100);
                        int color = (alpha << 24) | 0xFFFFFF;
                        context.method_25294((int)a.x, (int)a.y, (int)b.x, (int)b.y + 1, color);
                    }
                }
            }

            super.method_25394(context, mouseX, mouseY, deltaTicks);
        }

        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;

        // Optional: Titel anzeigen
        context.method_27534(this.field_22793, this.field_22785, centerX, 15, 0xFFFFFFFF);

        context.method_25303(this.field_22793, "Utils", centerX - 180, centerY - 40, 0xFFFFAA00);
        context.method_51427(new class_1799(class_1802.field_8251), centerX - 205, centerY - 45);

        context.method_25300(this.field_22793, "Rendering & Accessories", centerX, centerY - 40, 0xFFFFAA00);
        context.method_51427(new class_1799(class_1802.field_27070), centerX - 6, centerY - 62);

        context.method_25303(this.field_22793, "Utils", centerX + 160, centerY - 40, 0xFFFFAA00);
        context.method_51427(new class_1799(class_1802.field_8077), centerX + 195, centerY - 45);

        int previewX = centerX + 83;
        int previewY = centerY + 30;

        class_1799 previewStack = switch (trailIndex) {
            case 0 -> new class_1799(class_1802.field_8288);
            case 1 -> new class_1799(class_1802.field_8626);
            case 3 -> new class_1799(class_1802.field_8600);
            default -> class_1799.field_8037;
        };

        if (!previewStack.method_7960()) {
            context.method_51427(previewStack, previewX, previewY);
        } else if (trailIndex == 2) {
            context.method_52707(class_10799.field_56883, class_2960.method_60656("hud/heart/full"), previewX, previewY + 2, 11, 11, 0xFFFFFFFF);
        }
    }

    @Override
    public void method_25419() {
        assert this.field_22787 != null;
        this.field_22787.method_1507(this.parent);
    }

    @Override
    public boolean method_25422() {
        return true;
    }
}