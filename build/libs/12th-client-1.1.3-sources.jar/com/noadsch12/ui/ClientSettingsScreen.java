package com.noadsch12.ui;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public class ClientSettingsScreen extends class_437 {
    private final class_437 parent;
    private final class_2561 title;
    public static boolean ChatLoggerEnabled = true;
    public static boolean jumpToFoodEnabled = true;

    public ClientSettingsScreen(class_437 parent) {
        super(class_2561.method_43470(""));
        this.parent = parent;
        this.field_22785 = class_2561.method_43470("12th Client Settings");
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        // Jump to Food Toggle Button
        this.method_37063(class_4185.method_46430(
                        class_2561.method_43470("Jump to Food: " + (jumpToFoodEnabled ? "§aON" : "§cOFF")),
                        btn -> {
                            jumpToFoodEnabled = !jumpToFoodEnabled;
                            btn.method_25355(class_2561.method_43470("Jump to Food: " + (jumpToFoodEnabled ? "§aON" : "§cOFF")));
                        }
                )
                .method_46433(this.field_22789 / 2 - 75, this.field_22790 / 2 - 20)
                .method_46437(150, 20)
                .method_46431());

        this.method_37063(class_4185.method_46430(
                        class_2561.method_43470("Chatlog System: " + (ChatLoggerEnabled ? "§aON" : "§cOFF")),
                        btn -> {
                            ChatLoggerEnabled = !ChatLoggerEnabled;
                            btn.method_25355(class_2561.method_43470("Chatlog System: " + (ChatLoggerEnabled ? "§aON" : "§cOFF")));
                        }
                )
                .method_46433(this.field_22789 / 2 - 75, this.field_22790 / 2 + 4)
                .method_46437(150, 20)
                .method_46431());

        // Back Button
        this.method_37063(class_4185.method_46430(
                        class_2561.method_43470("Back"),
                        btn -> this.method_25419()
                )
                .method_46433(this.field_22789 / 2 - 50, this.field_22790 / 2 + 230)
                .method_46437(100, 20)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        // #000000 → #434343
        context.method_25296(0, 0, this.field_22789, this.field_22790, 0xFF000000, 0xFF434343);
        // Hintergrund rendern (dunkler Standardhintergrund)
        super.method_25394(context, mouseX, mouseY, deltaTicks);

        // Optional: Titel anzeigen
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFFFF);
    }

    @Override
    public void method_25419() {
        this.field_22787.method_1507(this.parent);
    }

    @Override
    public boolean method_25422() {
        return true;
    }
}