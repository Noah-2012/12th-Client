/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.ui.widgets;

import static com.noadsch12.util.BasicGlobals.ARIAL_FONT;

import net.minecraft.class_11719;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;

public class ModernButtonNew extends class_4185 {
    private static final int TEXT_PADDING = 8;
    private static final float CORNER_RADIUS = 8.0f;

    private float hoverProgress = 0.0f;
    private class_2561 customTooltipText;

    private float scrollOffset = 0.0f;
    private float scrollTimer = 0.0f;
    private float tooltipAlpha = 0.0f;
    private boolean scrollDirection = true;
    private static final float SCROLL_SPEED = 20.0f;
    private static final float PAUSE_DURATION = 30.0f;

    private long hoverStartTime = 0L;
    private static final long FADE_DELAY_MS = 175;
    private static final float FADE_SPEED = 0.05f;

    public ModernButtonNew(int x, int y, int width, int height, class_2561 message, class_4241 onPress) {
        super(x, y, width, height, message, onPress, field_40754);
    }

    public ModernButtonNew withTooltip(String text) {
        this.customTooltipText = class_2561.method_30163(text);
        return this;
    }

    @Override
    protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        class_310 client = class_310.method_1551();

        // Update hover animation
        if (this.method_25367()) {
            hoverProgress = Math.min(1.0f, hoverProgress + (delta * 0.1f));
        } else {
            hoverProgress = Math.max(0.0f, hoverProgress - (delta * 0.1f));
        }

        int x = method_46426();
        int y = method_46427();
        int w = field_22758;
        int h = field_22759;

        // Colors with smooth transitions
        int bgAlpha = this.method_25367() ?
                (int)((0.19f + (hoverProgress * 0.06f)) * 255) : (int)(0.08f * 255);
        int borderAlpha = this.method_25367() ? 255 : (int)(0.5f * 255);
        int textColor = this.field_22763 ? (this.method_25367() ? 0xFFFFF500 : 0xFFFFFFFF) : 0xFFA0A0A0;

        int backgroundColor = (bgAlpha << 24) | 0x000000;
        int borderColor = (borderAlpha << 24) | 0xFFFFFF;

        // Draw smooth rounded background
        drawSmoothRoundedRect(context, x, y, w, h, CORNER_RADIUS, backgroundColor);

        // Draw smooth border
        drawSmoothRoundedBorder(context, x, y, w, h, CORNER_RADIUS, borderColor);

        // Slide animation overlay
        if (hoverProgress > 0) {
            int slideWidth = 40;
            int totalDistance = w + slideWidth;
            float slideX = x + w - (hoverProgress * totalDistance);

            int slideAlpha = (int)(hoverProgress * 0.19f * 255);
            drawSmoothGradientSlide(context, (int)slideX, y, slideWidth, h, slideAlpha);
        }

        // Render text
        class_2561 styledMessage = this.method_25369().method_27661().method_10862(
                class_2583.field_24360.method_27704(new class_11719.class_11721(ARIAL_FONT))
        );

        int textWidth = client.field_1772.method_27525(styledMessage);
        int availableWidth = w - (TEXT_PADDING * 2);

        if (textWidth > availableWidth) {
            updateScrolling(delta, textWidth, availableWidth);
            renderScrollingText(context, client, styledMessage, x, y, w, h, textColor, availableWidth);
        } else {
            scrollOffset = 0.0f;
            scrollTimer = 0.0f;
            context.method_27534(
                    client.field_1772,
                    styledMessage,
                    x + w / 2,
                    y + (h - 8) / 2,
                    textColor
            );
        }

        // Tooltip handling
        if (this.method_25405(mouseX, mouseY) && customTooltipText != null) {
            if (hoverStartTime == 0L) {
                hoverStartTime = System.currentTimeMillis();
            }

            long hoverDuration = System.currentTimeMillis() - hoverStartTime;

            if (hoverDuration > FADE_DELAY_MS) {
                tooltipAlpha = Math.min(1.0f, tooltipAlpha + (delta * FADE_SPEED));
                renderCustomTooltip(context, mouseX, mouseY, tooltipAlpha);
            }
        } else {
            hoverStartTime = 0L;
            tooltipAlpha = 0.0f;
        }
    }

    private void drawSmoothRoundedRect(class_332 context, int x, int y, int width, int height,
                                       float radius, int color) {
        int r = (int)radius;

        // Main body rectangles
        context.method_25294(x + r, y, x + width - r, y + height, color);
        context.method_25294(x, y + r, x + r, y + height - r, color);
        context.method_25294(x + width - r, y + r, x + width, y + height - r, color);

        // Draw rounded corners with anti-aliasing effect using multiple layers
        int segments = 16;

        // Top-left corner
        drawFilledCorner(context, x + r, y + r, r, 180, 270, segments, color);

        // Top-right corner
        drawFilledCorner(context, x + width - r, y + r, r, 270, 360, segments, color);

        // Bottom-right corner
        drawFilledCorner(context, x + width - r, y + height - r, r, 0, 90, segments, color);

        // Bottom-left corner
        drawFilledCorner(context, x + r, y + height - r, r, 90, 180, segments, color);
    }

    private void drawFilledCorner(class_332 context, int centerX, int centerY, int radius,
                                  float startAngle, float endAngle, int segments, int color) {
        // Draw the corner as a series of small rectangles approximating a curve
        for (int i = 0; i < segments; i++) {
            float angle1 = (float) Math.toRadians(startAngle + (endAngle - startAngle) * i / segments);
            float angle2 = (float) Math.toRadians(startAngle + (endAngle - startAngle) * (i + 1) / segments);

            int x1 = centerX + (int)(Math.cos(angle1) * radius);
            int y1 = centerY + (int)(Math.sin(angle1) * radius);
            int x2 = centerX + (int)(Math.cos(angle2) * radius);
            int y2 = centerY + (int)(Math.sin(angle2) * radius);

            // Fill triangle from center to edge
            fillTriangle(context, centerX, centerY, x1, y1, x2, y2, color);
        }
    }

    private void fillTriangle(class_332 context, int x1, int y1, int x2, int y2, int x3, int y3, int color) {
        // Find bounding box
        int minX = Math.min(x1, Math.min(x2, x3));
        int maxX = Math.max(x1, Math.max(x2, x3));
        int minY = Math.min(y1, Math.min(y2, y3));
        int maxY = Math.max(y1, Math.max(y2, y3));

        // Fill the triangle by checking each pixel
        for (int y = minY; y <= maxY; y++) {
            for (int x = minX; x <= maxX; x++) {
                if (isPointInTriangle(x, y, x1, y1, x2, y2, x3, y3)) {
                    context.method_25294(x, y, x + 1, y + 1, color);
                }
            }
        }
    }

    private boolean isPointInTriangle(int px, int py, int x1, int y1, int x2, int y2, int x3, int y3) {
        float d1 = sign(px, py, x1, y1, x2, y2);
        float d2 = sign(px, py, x2, y2, x3, y3);
        float d3 = sign(px, py, x3, y3, x1, y1);

        boolean hasNeg = (d1 < 0) || (d2 < 0) || (d3 < 0);
        boolean hasPos = (d1 > 0) || (d2 > 0) || (d3 > 0);

        return !(hasNeg && hasPos);
    }

    private float sign(int p1x, int p1y, int p2x, int p2y, int p3x, int p3y) {
        return (p1x - p3x) * (p2y - p3y) - (p2x - p3x) * (p1y - p3y);
    }

    private void drawSmoothRoundedBorder(class_332 context, int x, int y, int width, int height,
                                         float radius, int color) {
        int r = (int)radius;

        // Draw straight edges
        // Top edge
        context.method_25294(x + r, y, x + width - r, y + 1, color);
        // Bottom edge
        context.method_25294(x + r, y + height - 1, x + width - r, y + height, color);
        // Left edge
        context.method_25294(x, y + r, x + 1, y + height - r, color);
        // Right edge
        context.method_25294(x + width - 1, y + r, x + width, y + height - r, color);

        // Draw rounded corners
        int segments = 16;

        // Top-left corner
        drawCornerBorder(context, x + r, y + r, r, 180, 270, segments, color);

        // Top-right corner
        drawCornerBorder(context, x + width - r, y + r, r, 270, 360, segments, color);

        // Bottom-right corner
        drawCornerBorder(context, x + width - r, y + height - r, r, 0, 90, segments, color);

        // Bottom-left corner
        drawCornerBorder(context, x + r, y + height - r, r, 90, 180, segments, color);
    }

    private void drawCornerBorder(class_332 context, int centerX, int centerY, int radius,
                                  float startAngle, float endAngle, int segments, int color) {
        for (int i = 0; i < segments; i++) {
            float angle1 = (float) Math.toRadians(startAngle + (endAngle - startAngle) * i / segments);
            float angle2 = (float) Math.toRadians(startAngle + (endAngle - startAngle) * (i + 1) / segments);

            int x1 = centerX + (int)(Math.cos(angle1) * radius);
            int y1 = centerY + (int)(Math.sin(angle1) * radius);
            int x2 = centerX + (int)(Math.cos(angle2) * radius);
            int y2 = centerY + (int)(Math.sin(angle2) * radius);

            // Draw line segment
            drawLine(context, x1, y1, x2, y2, color);
        }
    }

    private void drawLine(class_332 context, int x1, int y1, int x2, int y2, int color) {
        int dx = Math.abs(x2 - x1);
        int dy = Math.abs(y2 - y1);
        int sx = x1 < x2 ? 1 : -1;
        int sy = y1 < y2 ? 1 : -1;
        int err = dx - dy;

        while (true) {
            context.method_25294(x1, y1, x1 + 1, y1 + 1, color);

            if (x1 == x2 && y1 == y2) break;

            int e2 = 2 * err;
            if (e2 > -dy) {
                err -= dy;
                x1 += sx;
            }
            if (e2 < dx) {
                err += dx;
                y1 += sy;
            }
        }
    }

    private void drawSmoothGradientSlide(class_332 context, int x, int y, int width, int height, int maxAlpha) {
        // Draw gradient using multiple vertical strips
        int strips = 20;
        for (int i = 0; i < strips; i++) {
            float progress = (float)i / strips;
            int alpha;

            if (progress < 0.5f) {
                // Fade in
                alpha = (int)(maxAlpha * (progress * 2));
            } else {
                // Fade out
                alpha = (int)(maxAlpha * ((1.0f - progress) * 2));
            }

            int stripWidth = width / strips;
            int stripX = x + (i * stripWidth);
            int color = (alpha << 24) | 0xFFFFFF;

            context.method_25294(stripX, y, stripX + stripWidth + 1, y + height, color);
        }
    }

    private void renderCustomTooltip(class_332 context, int mouseX, int mouseY, float alpha) {
        class_310 client = class_310.method_1551();

        String[] lines = customTooltipText.getString().split("\n");
        int padding = 8;
        int lineSpacing = 5;
        int lineHeight = 10;

        class_2583 modernStyle = class_2583.field_24360.method_27704(new class_11719.class_11721(ARIAL_FONT));

        int maxWidth = 0;
        for (String line : lines) {
            int w = client.field_1772.method_27525(class_2561.method_43470(line).method_10862(modernStyle));
            if (w > maxWidth) maxWidth = w;
        }

        int totalWidth = maxWidth + (padding * 2);
        int totalHeight = (lines.length * lineHeight) + ((lines.length - 1) * lineSpacing) + (padding * 2);

        int tx = mouseX + 12;
        int ty = mouseY - 12;
        if (tx + totalWidth > context.method_51421()) tx = mouseX - totalWidth - 12;
        if (ty + totalHeight > context.method_51443()) ty = context.method_51443() - totalHeight;

        // Draw smooth rounded tooltip
        int bgAlpha = (int)(alpha * 0.95f * 255);
        int borderAlpha = (int)(alpha * 0.6f * 255);
        int bgColor = (bgAlpha << 24) | 0x121212;
        int borderColor = (borderAlpha << 24) | 0xFFFFFF;

        drawSmoothRoundedRect(context, tx, ty, totalWidth, totalHeight, 6.0f, bgColor);
        drawSmoothRoundedBorder(context, tx, ty, totalWidth, totalHeight, 6.0f, borderColor);

        // Draw text
        int currentY = ty + padding;
        for (String lineText : lines) {
            class_2561 styledLine = class_2561.method_43470(lineText).method_10862(modernStyle);
            int textColor = ((int)(alpha * 255) << 24) | 0xE0E0E0;

            context.method_51439(
                    client.field_1772,
                    styledLine,
                    tx + padding,
                    currentY,
                    textColor,
                    false
            );
            currentY += lineHeight + lineSpacing;
        }
    }

    private void updateScrolling(float delta, int textWidth, int availableWidth) {
        int maxScroll = textWidth - availableWidth;

        scrollTimer += delta;

        if (scrollTimer < PAUSE_DURATION) {
            return;
        }

        float scrollDelta = (SCROLL_SPEED * delta) / 20.0f;

        if (scrollDirection) {
            scrollOffset += scrollDelta;
            if (scrollOffset >= maxScroll) {
                scrollOffset = maxScroll;
                scrollDirection = false;
                scrollTimer = 0.0f;
            }
        } else {
            scrollOffset -= scrollDelta;
            if (scrollOffset <= 0) {
                scrollOffset = 0;
                scrollDirection = true;
                scrollTimer = 0.0f;
            }
        }
    }

    private void renderScrollingText(class_332 context, class_310 client, class_2561 text,
                                     int x, int y, int w, int h, int color, int availableWidth) {
        context.method_44379(x + TEXT_PADDING, y, x + w - TEXT_PADDING, y + h);

        int textX = x + TEXT_PADDING - (int)scrollOffset;
        int textY = y + (h - 8) / 2;

        context.method_27535(
                client.field_1772,
                text,
                textX,
                textY,
                color
        );

        context.method_44380();
    }
}