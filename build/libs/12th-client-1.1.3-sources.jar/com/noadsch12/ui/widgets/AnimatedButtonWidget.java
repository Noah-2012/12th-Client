/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.ui.widgets;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;

public class AnimatedButtonWidget extends class_4185 {
    private final String baseText;
    private long lastUpdate = System.currentTimeMillis();
    private float colorPhase = 0f;

    public AnimatedButtonWidget(int x, int y, int width, int height,
                                class_2561 message, class_4241 onPress, String baseText) {
        super(x, y, width, height, message, onPress, field_40754);
        this.baseText = baseText;
    }

    @Override
    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        long currentTime = System.currentTimeMillis();
        long elapsed = currentTime - lastUpdate;
        lastUpdate = currentTime;

        colorPhase += elapsed * 0.006f;
        updateColorAnimation();

        super.method_48579(context, mouseX, mouseY, delta);
    }

    private void updateColorAnimation() {
        // Schwarz-Weiß Pulsieren mit Standard-Farbcodes
        float brightness = (float) (Math.sin(colorPhase) * 0.5 + 0.5);
        String afterCode;
        afterCode = "§kniM";

        String colorCode;
        if (brightness < 0.25f) {
            colorCode = "§0§kMin§r§0"; // Black
        } else if (brightness < 0.5f) {
            colorCode = "§8§kMin§r§8"; // Dark Grey
        } else if (brightness < 0.75) {
            colorCode = "§7§kMin§r§7"; // Grey
        } else {
            colorCode = "§f§kMin§r§f"; // White
        }

        this.method_25355(class_2561.method_43470(colorCode + baseText + afterCode));
    }
}