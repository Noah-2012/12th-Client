/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.ui.widgets;

import blue.endless.jankson.annotation.Nullable;
import com.noadsch12.annotations.NotUpdated;
import com.noadsch12.modules.Module;
import net.minecraft.class_11719;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;

import static com.noadsch12.util.BasicGlobals.ARIAL_FONT;

@NotUpdated
public class ModernButton extends class_4185 {
    //private static final Identifier ARIAL_FONT = Identifier.of("12th-client", "arial");
    private static final int TEXT_PADDING = 8;

    private float hoverProgress = 0.0f;

    private class_2561 customTooltipText;
    @Nullable private Module linkedModule;

    private float scrollOffset = 0.0f;
    private float scrollTimer = 0.0f;
    private float tooltipAlpha = 0.0f;
    private boolean scrollDirection = true;
    private static final float SCROLL_SPEED = 20.0f;
    private static final float PAUSE_DURATION = 30.0f;

    private long hoverStartTime = 0L;
    private static final long FADE_DELAY_MS = 175;
    private static final float FADE_SPEED = 0.05f;

    public ModernButton(int x, int y, int width, int height, class_2561 message, class_4241 onPress) {
        super(x, y, width, height, message, onPress, field_40754);
    }

    public ModernButton withTooltip(String text) {
        this.customTooltipText = class_2561.method_30163(text);
        return this;
    }

    public ModernButton withModule(Module module) {
        this.linkedModule = module;
        return this;
    }

    public boolean shouldRenderTooltip(int mouseX, int mouseY) {
        return this.method_25405(mouseX, mouseY) && customTooltipText != null;
    }

    public class_2561 getTooltip() {
        return customTooltipText;
    }

    public float getTooltipAlpha() {
        return tooltipAlpha;
    }

    @Override
    protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        class_310 client = class_310.method_1551();

        // 1. Animations-Logik (Berechnung des Fortschritts)
        // Wenn die Maus drauf ist, steigt der Wert, sonst sinkt er
        if (this.method_25367()) {
            hoverProgress = Math.min(1.0f, hoverProgress + (delta * 0.1f)); // Geschwindigkeit anpassen
        } else {
            hoverProgress = Math.max(0.0f, hoverProgress - (delta * 0.1f));
        }

        int x = method_46426();
        int y = method_46427();
        int w = field_22758;
        int h = field_22759;

        // 2. Farben definieren
        int backgroundColor = this.method_25367() ? 0x30FFFFFF : 0x15000000;
        int borderColor = this.method_25367() ? 0xFFFFFFFF : 0x80707070;
        int textColor = this.field_22763 ? (this.method_25367() ? 0xFFFFF500 : 0xFFFFFFFF) : 0xFFA0A0A0;

        // 3. Hintergrund & Rahmen (wie vorher)
        context.method_25294(x + 2, y, x + w - 2, y + h, backgroundColor);
        context.method_25294(x + 1, y + 1, x + w - 1, y + h - 1, backgroundColor);
        context.method_25294(x, y + 2, x + w, y + h - 2, backgroundColor);
        drawEnhancedRoundedOutline(context, x, y, w, h, borderColor);

        // 4. DIE SLIDE-ANIMATION (Rechts nach Links)
        if (hoverProgress > 0) {
            int slideWidth = 40;
            int totalDistance = w + slideWidth;
            int currentX = x + w - (int)(hoverProgress * totalDistance);

            context.method_44379(x + 1, y + 1, x + w - 1, y + h - 1);
            int slideColor = 0x30FFFFFF;
            context.method_25294(currentX, y, currentX + slideWidth, y + h, slideColor);
            context.method_44380();
        }

        // 5. Text rendern
        class_2561 styledMessage = this.method_25369().method_27661().method_10862(
                class_2583.field_24360.method_27704(new class_11719.class_11721(ARIAL_FONT))
        );

        int textWidth = client.field_1772.method_27525(styledMessage);
        int availableWidth = w - (TEXT_PADDING * 2);

        // Prüfen ob Text zu lang ist
        if (textWidth > availableWidth) {
            // Text ist zu lang -> Scrolling aktivieren
            updateScrolling(delta, textWidth, availableWidth);
            renderScrollingText(context, client, styledMessage, x, y, w, h, textColor, availableWidth);
        } else {
            // Text passt -> normal zentriert rendern
            scrollOffset = 0.0f;
            scrollTimer = 0.0f;
            context.method_27534(
                    client.field_1772,
                    styledMessage,
                    x + w / 2,
                    y + (h - 8) / 2,
                    textColor
            );
        }

        if (this.method_25405(mouseX, mouseY) && customTooltipText != null) {
            // Update timing
            if (hoverStartTime == 0L) {
                hoverStartTime = System.currentTimeMillis();
            }

            // Calculate how long we've been hovering
            long hoverDuration = System.currentTimeMillis() - hoverStartTime;

            if (hoverDuration > FADE_DELAY_MS) {
                // Increase alpha once delay is passed
                tooltipAlpha = Math.min(1.0f, tooltipAlpha + (delta * FADE_SPEED));
                // THIS GETS HANDLED BY THE SCREEN RENDER METHOD
                //renderCustomTooltip(context, mouseX, mouseY, tooltipAlpha);
            }
        } else {
            // Reset when mouse leaves
            hoverStartTime = 0L;
            tooltipAlpha = 0.0f;
        }
    }

    public void renderCustomTooltip(class_332 context, int mouseX, int mouseY, float alpha) {
        class_310 client = class_310.method_1551();

        // 1. Split the text by \n
        String[] lines = customTooltipText.getString().split("\n");
        int padding = 5;
        int lineSpacing = 5;
        int lineHeight = 4;

        class_2583 modernStyle = class_2583.field_24360.method_27704(new class_11719.class_11721(ARIAL_FONT));

        int maxWidth = 0;
        for (String line : lines) {
            // We convert the string to a Text object with the style BEFORE measuring
            int w = client.field_1772.method_27525(class_2561.method_43470(line).method_10862(modernStyle));
            if (w > maxWidth) maxWidth = w;
        }

        int totalWidth = maxWidth + (padding * 2);
        int totalHeight = (lines.length * lineHeight) + ((lines.length - 1) * lineSpacing) + (padding * 2);

        // 3. Positioning
        int tx = mouseX + 12;
        int ty = mouseY - 12;
        if (tx + totalWidth > context.method_51421()) tx = mouseX - totalWidth - 12;
        if (ty + totalHeight > context.method_51443()) ty = context.method_51443() - totalHeight;

        // 4. Color Calculation (ARGB)
        int alphaInt = (int)(alpha * 255);
        int bgColor = (alphaInt << 24) | 0x121212; // Very dark gray
        int borderColor = (alphaInt << 24) | 0xFFFFFF; // White border
        int textColor = (alphaInt << 24) | 0xE0E0E0; // Off-white text

        context.method_51448().pushMatrix();

        context.method_51448().translate(0, 0);

        // 5. Draw Background & Border
        context.method_25294(tx + 1, ty, tx + totalWidth - 1, ty + totalHeight, bgColor);
        drawEnhancedRoundedOutline(context, tx, ty, totalWidth, totalHeight, borderColor);

        // 6. Draw each line
        int currentY = ty + padding - 2;
        for (String lineText : lines) {
            // Apply the Arial font to each line individually
            class_2561 styledLine = class_2561.method_43470(lineText).method_10862(
                    class_2583.field_24360.method_27704(new class_11719.class_11721(ARIAL_FONT))
            );

            context.method_51439(
                    client.field_1772,
                    styledLine,
                    tx + padding,
                    currentY,
                    textColor,
                    false
            );
            currentY += lineHeight + lineSpacing;
        }

        context.method_51448().popMatrix();
    }

    private void updateScrolling(float delta, int textWidth, int availableWidth) {
        int maxScroll = textWidth - availableWidth;

        scrollTimer += delta;

        if (scrollTimer < PAUSE_DURATION) {
            // Pause am Anfang/Ende
            return;
        }

        // Scroll-Animation
        float scrollDelta = (SCROLL_SPEED * delta) / 20.0f; // Normalisiert auf 20 FPS

        if (scrollDirection) {
            // Nach links scrollen
            scrollOffset += scrollDelta;
            if (scrollOffset >= maxScroll) {
                scrollOffset = maxScroll;
                scrollDirection = false;
                scrollTimer = 0.0f; // Pause starten
            }
        } else {
            // Nach rechts scrollen
            scrollOffset -= scrollDelta;
            if (scrollOffset <= 0) {
                scrollOffset = 0;
                scrollDirection = true;
                scrollTimer = 0.0f; // Pause starten
            }
        }
    }

    private void renderScrollingText(class_332 context, class_310 client, class_2561 text,
                                     int x, int y, int w, int h, int color, int availableWidth) {
        // Scissor aktivieren um Text außerhalb des Buttons abzuschneiden
        context.method_44379(x + TEXT_PADDING, y, x + w - TEXT_PADDING, y + h);

        // Text mit Offset zeichnen (linksbündig statt zentriert)
        int textX = x + TEXT_PADDING - (int)scrollOffset;
        int textY = y + (h - 8) / 2;

        context.method_27535(
                client.field_1772,
                text,
                textX,
                textY,
                color
        );

        context.method_44380();
    }

    private void drawEnhancedRoundedOutline(class_332 context, int x, int y, int w, int h, int color) {
        context.method_25294(x + 2, y, x + w - 2, y + 1, color);
        context.method_25294(x + 2, y + h - 1, x + w - 2, y + h, color);
        context.method_25294(x, y + 2, x + 1, y + h - 2, color);
        context.method_25294(x + w - 1, y + 2, x + w, y + h - 2, color);
        context.method_25294(x + 1, y + 1, x + 2, y + 2, color);
        context.method_25294(x + w - 2, y + 1, x + w - 1, y + 2, color);
        context.method_25294(x + 1, y + h - 2, x + 2, y + h - 1, color);
        context.method_25294(x + w - 2, y + h - 2, x + w - 1, y + h - 1, color);
    }

    // Add to ModernButton
    public Module getLinkedModule() {
        return linkedModule;
    }
}