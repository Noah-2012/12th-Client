/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.ui.widgets;

import com.noadsch12.annotations.NotUpdated;
import java.util.function.Consumer;
import net.minecraft.class_11719;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_357;

import static com.noadsch12.BasicGlobals.ARIAL_FONT;

@NotUpdated
public class ModernSlider extends class_357 {
    private static final class_2583 MODERN_STYLE = class_2583.field_24360.method_27704(new class_11719.class_11721(ARIAL_FONT));

    private static final int TEXT_PADDING = 8;
    private float hoverProgress = 0.0f;

    private class_2561 customTooltipText;
    private float tooltipAlpha = 0.0f;
    private long hoverStartTime = 0L;
    private static final long FADE_DELAY_MS = 175;
    private static final float FADE_SPEED = 0.05f;

    private final Consumer<Double> onValueChange;
    private final String prefix;

    public ModernSlider(int x, int y, int width, int height, class_2561 prefix, double value, Consumer<Double> onValueChange) {
        super(x, y, width, height, prefix, value);
        this.prefix = prefix.getString();
        this.onValueChange = onValueChange;
        method_25346();
    }

    public ModernSlider withTooltip(String text) {
        this.customTooltipText = class_2561.method_30163(text);
        return this;
    }

    @Override
    protected void method_25346() {
        // Formats the message to show Prefix: Value%
        int percentage = (int) (this.field_22753 * 100);
        method_25355(class_2561.method_30163(prefix + ": " + percentage + "%"));
    }

    @Override
    protected void method_25344() {
        if (onValueChange != null) {
            onValueChange.accept(this.field_22753);
        }
    }

    @Override
    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        class_310 client = class_310.method_1551();

        // 1. Animation Logic
        if (this.method_25367()) {
            hoverProgress = Math.min(1.0f, hoverProgress + (delta * 0.1f));
        } else {
            hoverProgress = Math.max(0.0f, hoverProgress - (delta * 0.1f));
        }

        int x = method_46426();
        int y = method_46427();
        int w = field_22758;
        int h = field_22759;

        // 2. Colors
        int backgroundColor = 0x15000000;
        int borderColor = this.method_25367() ? 0xFFFFFFFF : 0x80707070;
        int textColor = this.field_22763 ? (this.method_25367() ? 0xFFFFF500 : 0xFFFFFFFF) : 0xFFA0A0A0;
        int handleColor = this.method_25367() ? 0xFFFFF500 : 0xFFFFFFFF;

        // 3. Draw Background & Track
        context.method_25294(x + 2, y, x + w - 2, y + h, backgroundColor);
        context.method_25294(x + 1, y + 1, x + w - 1, y + h - 1, backgroundColor);
        context.method_25294(x, y + 2, x + w, y + h - 2, backgroundColor);

        // Visual "Progress" fill (Subtle accent)
        int progressWidth = (int)(this.field_22753 * (w - 4));
        context.method_25294(x + 2, y + 2, x + 2 + progressWidth, y + h - 2, 0x20FFFFFF);

        drawEnhancedRoundedOutline(context, x, y, w, h, borderColor);

        // 4. Draw Modern Handle (Vertical Bar)
        int handleX = x + 2 + (int) (this.field_22753 * (w - 8));
        context.method_25294(handleX, y + 2, handleX + 4, y + h - 2, handleColor);

        class_2561 styledMessage = this.method_25369().method_27661().method_10862(MODERN_STYLE);

        context.method_27534(
                client.field_1772,
                styledMessage,
                x + w / 2,
                y + (h - 8) / 2,
                textColor
        );

        // 6. Tooltip Logic
        if (this.method_25405(mouseX, mouseY) && customTooltipText != null) {
            if (hoverStartTime == 0L) hoverStartTime = System.currentTimeMillis();
            long hoverDuration = System.currentTimeMillis() - hoverStartTime;

            if (hoverDuration > FADE_DELAY_MS) {
                tooltipAlpha = Math.min(1.0f, tooltipAlpha + (delta * FADE_SPEED));
                renderCustomTooltip(context, mouseX, mouseY, tooltipAlpha);
            }
        } else {
            hoverStartTime = 0L;
            tooltipAlpha = 0.0f;
        }
    }

    private void renderCustomTooltip(class_332 context, int mouseX, int mouseY, float alpha) {
        class_310 client = class_310.method_1551();
        String[] lines = customTooltipText.getString().split("\n");
        int padding = 5;
        int lineSpacing = 5;
        int lineHeight = 4;
        class_2583 modernStyle = class_2583.field_24360.method_27704(new class_11719.class_11721(ARIAL_FONT));

        int maxWidth = 0;
        for (String line : lines) {
            int w = client.field_1772.method_27525(class_2561.method_43470(line).method_10862(modernStyle));
            if (w > maxWidth) maxWidth = w;
        }

        int totalWidth = maxWidth + (padding * 2);
        int totalHeight = (lines.length * lineHeight) + ((lines.length - 1) * lineSpacing) + (padding * 2);

        int tx = mouseX + 12;
        int ty = mouseY - 12;
        if (tx + totalWidth > context.method_51421()) tx = mouseX - totalWidth - 12;
        if (ty + totalHeight > context.method_51443()) ty = context.method_51443() - totalHeight;

        int alphaInt = (int)(alpha * 255);
        int bgColor = (alphaInt << 24) | 0x121212;
        int borderColor = (alphaInt << 24) | 0xFFFFFF;
        int textColor = (alphaInt << 24) | 0xE0E0E0;

        context.method_51448().pushMatrix();
        context.method_51448().translate(0, 0);

        context.method_25294(tx + 1, ty, tx + totalWidth - 1, ty + totalHeight, bgColor);
        drawEnhancedRoundedOutline(context, tx, ty, totalWidth, totalHeight, borderColor);

        int currentY = ty + padding - 2;
        for (String lineText : lines) {
            class_2561 styledLine = class_2561.method_43470(lineText).method_10862(modernStyle);
            context.method_51439(client.field_1772, styledLine, tx + padding, currentY, textColor, false);
            currentY += lineHeight + lineSpacing;
        }

        context.method_51448().popMatrix();
    }

    private void drawEnhancedRoundedOutline(class_332 context, int x, int y, int w, int h, int color) {
        context.method_25294(x + 2, y, x + w - 2, y + 1, color);
        context.method_25294(x + 2, y + h - 1, x + w - 2, y + h, color);
        context.method_25294(x, y + 2, x + 1, y + h - 2, color);
        context.method_25294(x + w - 1, y + 2, x + w, y + h - 2, color);
        context.method_25294(x + 1, y + 1, x + 2, y + 2, color);
        context.method_25294(x + w - 2, y + 1, x + w - 1, y + 2, color);
        context.method_25294(x + 1, y + h - 2, x + 2, y + h - 1, color);
        context.method_25294(x + w - 2, y + h - 2, x + w - 1, y + h - 1, color);
    }
}