package com.noadsch12.ui;

import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class MenuButton {
    private final class_4185 button;
    public MenuButton(String label, int x, int y, int width, int height, class_4185.class_4241 onPress) {
        this.button = class_4185.method_46430(
                        class_2561.method_43470(label),
                        onPress
                )
                .method_46433(x, y)
                .method_46437(width, height)
                .method_46431();
    }

    public void addToScreen(class_437 screen) {
        screen.method_37063(this.button);
    }

    public class_4185 getButton() {
        return this.button;
    }
}