/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.ui.screens;

import com.noadsch12.ui.BlockOutlineSettings;
import com.noadsch12.TwelfthConfig;
import com.noadsch12.ui.BlurHandler;
import com.noadsch12.ui.widgets.ModernButton;
import com.noadsch12.ui.widgets.ModernSlider; // Import the new slider
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class BlockOutlineScreen extends class_437 {
    private final class_437 parent;

    public BlockOutlineScreen(class_437 parent) {
        super(class_2561.method_43470("Outline Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        int bWidth = 160;

        // Toggle Outline
        this.method_37063(new ModernButton(centerX - 80, centerY - 60, bWidth, 20,
                class_2561.method_43470("Custom Outline: " + (BlockOutlineSettings.enabled ? "§aON" : "§cOFF")),
                btn -> {
                    BlockOutlineSettings.enabled = !BlockOutlineSettings.enabled;
                    TwelfthConfig.setValue("outline_enabled", String.valueOf(BlockOutlineSettings.enabled));
                    btn.method_25355(class_2561.method_43470("Custom Outline: " + (BlockOutlineSettings.enabled ? "§aON" : "§cOFF")));
                }));

        // Rainbow Toggle
        this.method_37063(new ModernButton(centerX - 80, centerY - 35, bWidth, 20,
                class_2561.method_43470("Rainbow: " + (BlockOutlineSettings.rainbow ? "§aON" : "§cOFF")),
                btn -> {
                    BlockOutlineSettings.rainbow = !BlockOutlineSettings.rainbow;
                    btn.method_25355(class_2561.method_43470("Rainbow: " + (BlockOutlineSettings.rainbow ? "§aON" : "§cOFF")));
                }));

        // Red Slider
        this.method_37063(new ModernSlider(centerX - 80, centerY - 10, bWidth, 20,
                class_2561.method_43470("Red §c"), BlockOutlineSettings.r,
                val -> BlockOutlineSettings.r = val.floatValue())
                .withTooltip("Adjust the Red component"));

        // Green Slider
        this.method_37063(new ModernSlider(centerX - 80, centerY + 15, bWidth, 20,
                class_2561.method_43470("Green §a"), BlockOutlineSettings.g,
                val -> BlockOutlineSettings.g = val.floatValue())
                .withTooltip("Adjust the Green component"));

        // Blue Slider
        this.method_37063(new ModernSlider(centerX - 80, centerY + 40, bWidth, 20,
                class_2561.method_43470("Blue §9"), BlockOutlineSettings.b,
                val -> BlockOutlineSettings.b = val.floatValue())
                .withTooltip("Adjust the Blue component"));

        // Opacity Slider
        this.method_37063(new ModernSlider(centerX - 80, centerY + 65, bWidth, 20,
                class_2561.method_43470("Opacity §f"), BlockOutlineSettings.a,
                val -> BlockOutlineSettings.a = val.floatValue())
                .withTooltip("Adjust how transparent the outline is"));

        // Back Button
        this.method_37063(new ModernButton(centerX - 50, centerY + 100, 100, 20, class_2561.method_43470("Back"), btn -> this.method_25419()));
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        if (this.field_22787.field_1687 != null) {
            BlurHandler.executeBlur(context, this.field_22789, this.field_22790, 2.0f);
        } else {
            context.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF101010);
        }

        context.method_27534(this.field_22793, class_2561.method_43470("Block Outline Customization"), this.field_22789 / 2, 20, 0xFFFFAA00);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public void method_25419() {
        // Save all settings when the screen is closed to keep config updated
        //TwelfthConfig.setValue("outline_r", String.valueOf(BlockOutlineSettings.r));
        //TwelfthConfig.setValue("outline_g", String.valueOf(BlockOutlineSettings.g));
        //TwelfthConfig.setValue("outline_b", String.valueOf(BlockOutlineSettings.b));
        //TwelfthConfig.setValue("outline_a", String.valueOf(BlockOutlineSettings.a));

        this.field_22787.method_1507(parent);
    }
}