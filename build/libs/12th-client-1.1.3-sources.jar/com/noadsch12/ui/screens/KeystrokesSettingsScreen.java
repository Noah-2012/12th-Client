/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.ui.screens;

import com.noadsch12.render.ui.keystrokes.KeystrokesConfig;
import com.noadsch12.render.ui.keystrokes.KeystrokesRenderer;
import com.noadsch12.ui.widgets.ModernButton;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class KeystrokesSettingsScreen extends class_437 {
    private final class_437 parent;
    private boolean dragging = false;

    public KeystrokesSettingsScreen(class_437 parent) {
        super(class_2561.method_43470("Keystrokes Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int xMid = this.field_22789 / 2;
        int yMid = this.field_22790 / 2;
        int bWidth = 150;
        int bHeight = 20;

        // --- Left Column ---

        // Spacebar Toggle
        this.method_37063(new ModernButton(xMid - 155, yMid - 40, bWidth, bHeight,
                class_2561.method_43470("Spacebar: " + (KeystrokesConfig.showSpace ? "ON" : "OFF")),
                button -> {
                    KeystrokesConfig.showSpace = !KeystrokesConfig.showSpace;
                    button.method_25355(class_2561.method_43470("Spacebar: " + (KeystrokesConfig.showSpace ? "ON" : "OFF")));
                }
        ));

        // Mouse Buttons Toggle (LMB/RMB)
        this.method_37063(new ModernButton(xMid - 155, yMid - 15, bWidth, bHeight,
                class_2561.method_43470("Mouse Buttons: " + (KeystrokesConfig.showMouseButtons ? "ON" : "OFF")),
                button -> {
                    KeystrokesConfig.showMouseButtons = !KeystrokesConfig.showMouseButtons;
                    button.method_25355(class_2561.method_43470("Mouse Buttons: " + (KeystrokesConfig.showMouseButtons ? "ON" : "OFF")));
                }
        ));

        // --- Right Column ---

        // CPS Toggle
        this.method_37063(new ModernButton(xMid + 5, yMid - 40, bWidth, bHeight,
                class_2561.method_43470("CPS Display: " + (KeystrokesConfig.showCPS ? "ON" : "OFF")),
                button -> {
                    KeystrokesConfig.showCPS = !KeystrokesConfig.showCPS;
                    button.method_25355(class_2561.method_43470("CPS Display: " + (KeystrokesConfig.showCPS ? "ON" : "OFF")));
                }
        ));

        // Scale Toggle
        this.method_37063(new ModernButton(xMid + 5, yMid - 15, bWidth, bHeight,
                class_2561.method_43470("HUD Scale: " + String.format("%.1f", KeystrokesConfig.scale)),
                button -> {
                    KeystrokesConfig.scale = (KeystrokesConfig.scale >= 1.5f) ? 0.5f : KeystrokesConfig.scale + 0.1f;
                    button.method_25355(class_2561.method_43470("HUD Scale: " + String.format("%.1f", KeystrokesConfig.scale)));
                }
        ));

        // --- Bottom ---

        // Done Button
        this.method_37063(new ModernButton(xMid - 75, yMid + 25, 150, 20,
                class_2561.method_43470("Done"),
                button -> this.method_25419()
        ));
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        //this.renderBackground(context, mouseX, mouseY, deltaTicks);

        // Render HUD Preview
        KeystrokesRenderer.render(context);

        context.method_25300(this.field_22793, "Keystrokes Settings", this.field_22789 / 2, 20, 0xFFFFFF);
        context.method_25300(this.field_22793, "Right-Click & Drag the HUD to move", this.field_22789 / 2, 35, 0xFFAA00);

        super.method_25394(context, mouseX, mouseY, deltaTicks);
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        if (click.method_74245() == 1 && isHoveringHUD(click.comp_4798(), click.comp_4799())) {
            this.dragging = true;
            return true;
        }
        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        if (click.method_74245() == 1) {
            this.dragging = false;
        }
        return super.method_25406(click);
    }

    @Override
    public boolean method_25403(class_11909 click, double deltaX, double deltaY) {
        if (this.dragging && click.method_74245() == 1) {
            KeystrokesConfig.x += (float) deltaX;
            KeystrokesConfig.y += (float) deltaY;
            return true;
        }
        return super.method_25403(click, deltaX, deltaY);
    }

    private boolean isHoveringHUD(double mx, double my) {
        // Dynamic box size for dragging detection
        float sizeX = 75 * KeystrokesConfig.scale;
        float sizeY = (KeystrokesConfig.showSpace ? 100 : 75) * KeystrokesConfig.scale;
        return mx >= KeystrokesConfig.x && mx <= KeystrokesConfig.x + sizeX &&
                my >= KeystrokesConfig.y && my <= KeystrokesConfig.y + sizeY;
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }
}