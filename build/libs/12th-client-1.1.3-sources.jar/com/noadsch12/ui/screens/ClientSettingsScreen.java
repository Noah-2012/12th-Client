/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.ui.screens;

import com.noadsch12.BasicGlobals;
import com.noadsch12.modules.Category;
import com.noadsch12.modules.Module;
import com.noadsch12.modules.ModuleManager;
import com.noadsch12.modules.impl.misc.ShowKeystrokesModule;
import com.noadsch12.modules.impl.render.ProjectileTrailModule;
import com.noadsch12.modules.impl.render.TrailSettings;
import com.noadsch12.ui.BlurHandler;
import com.noadsch12.ui.widgets.ModernButton;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10799;
import net.minecraft.class_11719;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_437;

class Dot {
    float x, y;
    float vx, vy;
    float shakeX = 0;
    float shakeY = 0;

    Dot(int w, int h) {
        x = (float) Math.random() * w;
        y = (float) Math.random() * h;
        vx = ((float) Math.random() - 0.5f) * 0.5f;
        vy = ((float) Math.random() - 0.5f) * 0.5f;
    }

    void applyShake() {
        shakeX += ((float) Math.random() - 0.5f) * 6.5f;
        shakeY += ((float) Math.random() - 0.5f) * 6.5f;
    }

    void update(int w, int h, double mouseX, double mouseY) {
        x += vx + shakeX;
        y += vy + shakeY;

        shakeX *= 0.85f;
        shakeY *= 0.85f;

        double dx = x - mouseX;
        double dy = y - mouseY;
        double dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 40) {
            x += (float) (dx * 0.05);
            y += (float) (dy * 0.05);
        }

        if (x < 0 || x > w) vx *= -1;
        if (y < 0 || y > h) vy *= -1;
    }
}

public class ClientSettingsScreen extends class_437 {
    private final class_437 parent;
    private final class_2561 title;
    private final class_2583 font = class_2583.field_24360.method_27704(new class_11719.class_11721(BasicGlobals.ARIAL_FONT));
    private final List<Dot> dots = new ArrayList<>();
    private final ModuleManager moduleManager = ModuleManager.getInstance();

    // UI Constants
    private static final int BUTTON_WIDTH = 150;
    private static final int BUTTON_HEIGHT = 20;
    private static final int TRAIL_BUTTON_HEIGHT = 10;
    private static final int BUTTON_SPACING = 24;

    public ClientSettingsScreen(class_437 parent) {
        super(class_2561.method_43470(""));
        this.parent = parent;
        this.field_22785 = class_2561.method_43470("12th Client Settings");
    }

    @Override
    protected void method_25426() {
        if (dots.isEmpty()) {
            for (int i = 0; i < 90; i++) {
                dots.add(new Dot(this.field_22789, this.field_22790));
            }
        }

        super.method_25426();

        int centerX = this.field_22789 / 2;
        int centerY = (this.field_22790 / 2) - 50;

        // Create buttons for each category
        for (Category category : Category.values()) {
            createCategoryButtons(category, centerX, centerY);
        }

        // Special buttons (settings screens, crash test, back)
        createSpecialButtons(centerX, centerY);

        this.method_25422();
    }

    /**
     * Create all buttons for a specific category
     */
    private void createCategoryButtons(Category category, int centerX, int centerY) {
        int columnX = category.getColumnX(centerX, BUTTON_WIDTH);
        int currentY = centerY - 20;

        // Bulk enable/disable buttons
        addBulkButtons(category, columnX, centerY - 38);

        // Get all modules for this category
        List<Module> modules = moduleManager.getModulesByCategory(category);

        for (Module module : modules) {
            ModernButton button = new ModernButton(
                    columnX,
                    currentY,
                    BUTTON_WIDTH,
                    BUTTON_HEIGHT,
                    module.getButtonLabel(),
                    btn -> {
                        module.toggle();
                        btn.method_25355(module.getButtonLabel());

                        // Handle special module logic
                        handleSpecialModuleToggle(module);
                    }
            ).withTooltip(module.getTooltip());

            this.method_37063(button);
            currentY += BUTTON_SPACING;
        }

        // Add category-specific special buttons
        if (category == Category.MISC) {
            addMiscSpecialButtons(columnX, currentY);
        } else if (category == Category.RENDER) {
            addRenderSpecialButtons(columnX, currentY);
        }
    }

    /**
     * Add bulk enable/disable buttons for a category
     */
    private void addBulkButtons(Category category, int x, int y) {
        this.method_37063(new ModernButton(
                x,
                y,
                BUTTON_WIDTH / 2 - 2,
                14,
                class_2561.method_43470("§aEnable All"),
                btn -> {
                    moduleManager.enableCategory(category);
                    refreshUI();
                }
        ));

        this.method_37063(new ModernButton(
                x + BUTTON_WIDTH / 2 + 2,
                y,
                BUTTON_WIDTH / 2 - 2,
                14,
                class_2561.method_43470("§cDisable All"),
                btn -> {
                    moduleManager.disableCategory(category);
                    refreshUI();
                }
        ));
    }

    /**
     * Add special buttons for Misc category
     */
    private void addMiscSpecialButtons(int x, int y) {
        ShowKeystrokesModule keystrokesModule = moduleManager.getModule(ShowKeystrokesModule.class);

        ModernButton keystrokeSettings = new ModernButton(
                x,
                y,
                BUTTON_WIDTH,
                BUTTON_HEIGHT,
                class_2561.method_43470("Open Keystroke Settings"),
                btn -> this.field_22787.method_1507(new KeystrokesSettingsScreen(this))
        );
        keystrokeSettings.field_22763 = keystrokesModule != null && keystrokesModule.isEnabled();
        this.method_37063(keystrokeSettings);

        this.method_37063(new ModernButton(
                x,
                y + BUTTON_SPACING,
                BUTTON_WIDTH,
                BUTTON_HEIGHT,
                class_2561.method_43470("Open Block Outline Settings"),
                btn -> this.field_22787.method_1507(new BlockOutlineScreen(this))
        ));
    }

    /**
     * Add special buttons for Render category (trail settings)
     */
    private void addRenderSpecialButtons(int x, int y) {
        ProjectileTrailModule trailModule = moduleManager.getModule(ProjectileTrailModule.class);
        boolean trailEnabled = trailModule != null && trailModule.isEnabled();

        // Trail color button
        ModernButton trailColorButton = new ModernButton(
                x,
                y + 20,
                BUTTON_WIDTH,
                TRAIL_BUTTON_HEIGHT,
                class_2561.method_43470("Trail Color: " + TrailSettings.getCurrentTrailColor()),
                btn -> {
                    TrailSettings.cycleTrailColorIndex();
                    btn.method_25355(class_2561.method_43470("Trail Color: " + TrailSettings.getCurrentTrailColor()));
                }
        ).withTooltip("Select a color for the trail");
        trailColorButton.field_22763 = trailEnabled && TrailSettings.isLineTrail();
        this.method_37063(trailColorButton);

        // Trail mode button
        ModernButton trailButton = new ModernButton(
                x,
                y,
                BUTTON_WIDTH,
                BUTTON_HEIGHT,
                class_2561.method_43470("Trail Mode: " + TrailSettings.getCurrentTrailName()),
                btn -> {
                    this.method_37066(trailColorButton);
                    TrailSettings.cycleTrailIndex();
                    trailColorButton.field_22763 = trailEnabled && TrailSettings.isLineTrail();
                    this.method_37063(trailColorButton);
                    btn.method_25355(class_2561.method_43470("Trail Mode: " + TrailSettings.getCurrentTrailName()));
                }
        ).withTooltip("Select a trail mode");
        trailButton.field_22763 = trailEnabled;
        this.method_37063(trailButton);
    }

    /**
     * Add special buttons (crash test, back button)
     */
    private void createSpecialButtons(int centerX, int centerY) {
        // Developer crash test button
        this.method_37063(new ModernButton(
                centerX - 50,
                centerY + 297,
                100,
                20,
                class_2561.method_43470("§cCrash Client"),
                btn -> {
                    throw new RuntimeException("12th Client managed Crash - THIS IS NOT A REAL CRASH - ");
                }
        ).withTooltip("Intentionally crashes the client\n(for testing the crash handler)"));

        // Back button (only show when not in-game)
        if (this.field_22787.field_1687 == null) {
            this.method_37063(new ModernButton(
                    centerX - 50,
                    centerY + 273,
                    100,
                    20,
                    class_2561.method_43470("Back"),
                    btn -> this.method_25419()
            ));
        }
    }

    /**
     * Handle special logic when specific modules are toggled
     */
    private void handleSpecialModuleToggle(Module module) {
        // Refresh UI for modules that affect other buttons
        if (module instanceof ShowKeystrokesModule || module instanceof ProjectileTrailModule) {
            refreshUI();
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        if (this.field_22787.field_1687 != null) {
            BlurHandler.executeBlur(context, this.field_22789, this.field_22790, 2.0f);
            super.method_25394(context, mouseX, mouseY, deltaTicks);
        } else {
            renderBackgroundAnimation(context, mouseX, mouseY);
            super.method_25394(context, mouseX, mouseY, deltaTicks);
        }

        renderTitleAndCategoryHeaders(context);
        renderTrailPreview(context);
        renderTooltips(context, mouseX, mouseY);
    }

    /**
     * Render animated dot background (when not in-game)
     */
    private void renderBackgroundAnimation(class_332 context, int mouseX, int mouseY) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF101010);

        // Update and render dots
        for (Dot dot : dots) {
            dot.update(this.field_22789, this.field_22790, mouseX, mouseY);
            context.method_25294((int) dot.x, (int) dot.y, (int) dot.x + 2, (int) dot.y + 2, 0x55FFFFFF);
        }

        // Render connections between nearby dots
        for (int i = 0; i < dots.size(); i++) {
            Dot a = dots.get(i);
            for (int j = i + 1; j < dots.size(); j++) {
                Dot b = dots.get(j);
                double dist = Math.sqrt(Math.pow(a.x - b.x, 2) + Math.pow(a.y - b.y, 2));

                if (dist < 25) {
                    int alpha = (int) ((1.0 - (dist / 50.0)) * 100);
                    int color = (alpha << 24) | 0xFFFFFF;
                    context.method_25294((int) a.x, (int) a.y, (int) b.x, (int) b.y + 1, color);
                }
            }
        }
    }

    /**
     * Render title and category headers with icons
     */
    private void renderTitleAndCategoryHeaders(class_332 context) {
        int centerX = this.field_22789 / 2;
        int centerY = (this.field_22790 / 2) - 62;

        // Main title
        context.method_27534(this.field_22793, this.field_22785, centerX, 15, 0xFFFFFFFF);

        // Category headers
        for (Category category : Category.values()) {
            int columnX = category.getColumnX(centerX, BUTTON_WIDTH);
            int headerY = centerY - 40;

            // Category text
            if (category == Category.RENDER) {
                context.method_27534(
                        this.field_22793,
                        class_2561.method_43470(category.getDisplayName()).method_10862(font),
                        centerX - 10,
                        headerY,
                        category.getColor()
                );
                context.method_51427(new class_1799(category.getIconItem()), centerX - 6, centerY - 62);
            } else {
                context.method_27535(
                        this.field_22793,
                        class_2561.method_43470(category.getDisplayName()).method_10862(font),
                        columnX + 64,
                        headerY,
                        category.getColor()
                );
                context.method_51427(new class_1799(category.getIconItem()), columnX + 39, centerY - 45);
            }
        }
    }

    /**
     * Render trail preview icon
     */
    private void renderTrailPreview(class_332 context) {
        int centerX = this.field_22789 / 2;
        int centerY = (this.field_22790 / 2) - 62;
        int previewX = centerX + 83;
        int previewY = centerY + 78;

        class_1799 previewStack = switch (TrailSettings.getTrailIndex()) {
            case 0 -> new class_1799(class_1802.field_8288);
            case 1 -> new class_1799(class_1802.field_8626);
            case 3 -> new class_1799(class_1802.field_8600);
            default -> class_1799.field_8037;
        };

        if (!previewStack.method_7960()) {
            context.method_51427(previewStack, previewX, previewY);
        } else if (TrailSettings.getTrailIndex() == 2) {
            context.method_52707(
                    class_10799.field_56883,
                    class_2960.method_60656("hud/heart/full"),
                    previewX,
                    previewY + 2,
                    11,
                    11,
                    0xFFFFFFFF
            );
        }
    }

    /**
     * Render custom tooltips for buttons
     */
    private void renderTooltips(class_332 context, int mouseX, int mouseY) {
        for (class_364 element : this.method_25396()) {
            if (element instanceof ModernButton button && button.shouldRenderTooltip(mouseX, mouseY)) {
                button.renderCustomTooltip(context, mouseX, mouseY, button.getTooltipAlpha());
            }
        }
    }

    @Override
    public void method_25419() {
        assert this.field_22787 != null;
        this.field_22787.method_1507(this.parent);
    }

    @Override
    public boolean method_25422() {
        return true;
    }

    private void refreshUI() {
        this.method_41843();
    }

    @Override
    public boolean method_25402(net.minecraft.class_11909 click, boolean doubleClick) {
        if (click.method_74232()) {
            for (Dot dot : dots) {
                dot.applyShake();
            }
            return true;
        }
        return super.method_25402(click, doubleClick);
    }

    /**
     * Legacy compatibility - get module state for other systems
     */
    public static boolean isModuleEnabled(String moduleName) {
        Module module = ModuleManager.getInstance().getModule(moduleName);
        return module != null && module.isEnabled();
    }
}