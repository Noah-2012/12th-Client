/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.ui.screens;

import com.noadsch12.BasicGlobals;
import com.noadsch12.util.GithubReleaseFetcher;
import java.net.URI;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ClientInfoScreen extends class_437 {
    private static final class_2960 INFO_BACKGROUND = class_2960.method_60655("12th-client", "textures/gui/info_bg.png");
    private final class_437 parent;

    // Client Info
    private static final String CLIENT_VERSION = BasicGlobals.CLIENT_VERSION; // Hier deine Version
    private static final String GITHUB_OWNER = "Noah-2012";
    private static final String GITHUB_REPO = "12th-Client";
    private static final String GITHUB_URL = "https://github.com/" + GITHUB_OWNER + "/" + GITHUB_REPO;
    private static final String MC_VERSION = "1.21.10";

    // Update Info
    private String latestVersion = "Checking...";
    private boolean updateAvailable = false;
    private boolean checkingUpdate = true;
    private boolean isDownloading = false;
    private String downloadStatus = "";

    public ClientInfoScreen(class_437 parent) {
        super(class_2561.method_43470("12th Client Info"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        int centerX = this.field_22789 / 2;
        int buttonWidth = 200;
        int buttonHeight = 20;
        int startY = this.field_22790 / 2 + 60;
        int spacing = 25;

        // Download Update Button (nur sichtbar wenn Update verfügbar)
        if (updateAvailable && !checkingUpdate) {
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470(isDownloading ? "Downloading..." : "Download Update"),
                    button -> downloadUpdate()
            ).method_46434(centerX - buttonWidth / 2, startY, buttonWidth, buttonHeight).method_46431());
            startY += spacing;
        }

        // GitHub Button
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Open GitHub"),
                button -> openURL(GITHUB_URL)
        ).method_46434(centerX - buttonWidth / 2, startY, buttonWidth, buttonHeight).method_46431());

        // Discord Button (optional)
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Join Discord"),
                button -> openURL("https://discord.gg/HMAk5rS8Vg")
        ).method_46434(centerX - buttonWidth / 2, startY + spacing, buttonWidth, buttonHeight).method_46431());

        // Close Button
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Close"),
                button -> this.field_22787.method_1507(parent)
        ).method_46434(centerX - buttonWidth / 2, startY + spacing * 2, buttonWidth, buttonHeight).method_46431());

        // Start update check in background
        checkForUpdates();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Background
        //this.renderBackground(context, mouseX, mouseY, delta);
        // ^ makes an error because of super.render at the end of the Function

        // Semi-transparent overlay
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0x88000000);

        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;

        // Main Info Box
        int boxWidth = 400;
        int boxHeight = 280;
        int boxX = centerX - boxWidth / 2;
        int boxY = centerY - boxHeight / 2;

        // Box Background
        context.method_25294(boxX, boxY, boxX + boxWidth, boxY + boxHeight, 0xDD000000);

        // Border (manual drawing)
        context.method_25294(boxX, boxY, boxX + boxWidth, boxY + 2, 0xFF808080); // Top
        context.method_25294(boxX, boxY + boxHeight - 2, boxX + boxWidth, boxY + boxHeight, 0xFF000000); // Bottom
        //context.fill(boxX, boxY, boxX + 2, boxY + boxHeight, 0xFF00FFFF); // Left
        //context.fill(boxX + boxWidth - 2, boxY, boxX + boxWidth, boxY + boxHeight, 0xFF00FFFF); // Right

        context.method_25296(
                boxX, boxY,
                boxX + 2, boxY + boxHeight,
                0xFF808080, 0xFF000000
        );

        context.method_25296(
                boxX + boxWidth - 2, boxY,
                boxX + boxWidth, boxY + boxHeight,
                0xFF808080, 0xFF000000
        );

        // Title
        String title = "12th Client";
        context.method_25300(
                this.field_22793,
                title,
                centerX,
                boxY + 15,
                0xFF00FFFF
        );

        // Info Text
        int textY = boxY + 40;
        int lineHeight = 12;

        drawInfoLine(context, "Current Version:", CLIENT_VERSION, centerX, textY, 0xFFFFFFFF, 0xFFFFFF00);
        textY += lineHeight;

        drawInfoLine(context, "Minecraft Version:", MC_VERSION, centerX, textY, 0xFFFFFFFF, 0xFF00FF00);
        textY += lineHeight;

        drawInfoLine(context, "Latest Version:", latestVersion, centerX, textY, 0xFFFFFFFF,
                updateAvailable ? 0xFFFF0000 : 0xFF00FF00);
        textY += lineHeight + 5;

        // Update Status
        if (checkingUpdate) {
            context.method_25300(
                    this.field_22793,
                    "Checking for updates...",
                    centerX,
                    textY,
                    0xFFFFFFFF
            );
        } else if (updateAvailable) {
            context.method_25300(
                    this.field_22793,
                    "⚠ New version available!",
                    centerX,
                    textY,
                    0xFFFF0000
            );

            // Download Status
            if (isDownloading && !downloadStatus.isEmpty()) {
                textY += lineHeight;
                context.method_25300(
                        this.field_22793,
                        downloadStatus,
                        centerX,
                        textY,
                        0xFFFFFF00
                );
            }
        } else {
            context.method_25300(
                    this.field_22793,
                    "✓ You're up to date!",
                    centerX,
                    textY,
                    0xFF00FF00
            );
        }

        textY += lineHeight + 10;

        // Additional Info
        context.method_25300(
                this.field_22793,
                "§7Created by Noadsch12",
                centerX,
                textY,
                0xFFAAAAAA
        );

        textY += lineHeight;

        context.method_25300(
                this.field_22793,
                "§7Special thanks to SniperShot",
                centerX,
                textY,
                0xFFAAAAAA
        );

        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void drawInfoLine(class_332 context, String label, String value, int centerX, int y, int labelColor, int valueColor) {
        String fullText = label + " " + value;
        int fullWidth = this.field_22793.method_1727(fullText);
        int labelWidth = this.field_22793.method_1727(label);

        int startX = centerX - fullWidth / 2;

        context.method_25303(this.field_22793, label, startX, y, labelColor);
        context.method_25303(this.field_22793, value, startX + labelWidth + this.field_22793.method_1727(" "), y, valueColor);
    }

    private void checkForUpdates() {
        new Thread(() -> {
            try {
                // Hole die neueste Version von GitHub
                String fetchedVersion = GithubReleaseFetcher.getLatestTag(GITHUB_OWNER, GITHUB_REPO);

                if (fetchedVersion != null && !fetchedVersion.isEmpty()) {
                    latestVersion = fetchedVersion;

                    String cleanCurrent = CLIENT_VERSION.replaceFirst("^v", "");
                    String cleanLatest = fetchedVersion.replaceFirst("^v", "");

                    updateAvailable = !cleanCurrent.equals(cleanLatest);
                } else {
                    latestVersion = "Unknown";
                }

                checkingUpdate = false;

            } catch (Exception e) {
                latestVersion = "Error";
                checkingUpdate = false;
                e.printStackTrace();
            }
        }).start();
    }

    private void downloadUpdate() {
        if (isDownloading) return;

        isDownloading = true;
        downloadStatus = "Starting download...";

        new Thread(() -> {
            try {
                String homeDir = System.getProperty("user.home");
                String downloadPath = homeDir + "/Downloads";

                downloadStatus = "Downloading to " + downloadPath + "...";

                boolean success = GithubReleaseFetcher.downloadLatestRelease(
                        GITHUB_OWNER,
                        GITHUB_REPO,
                        downloadPath
                );

                if (success) {
                    downloadStatus = "✓ Download complete! Check your Downloads folder.";
                } else {
                    downloadStatus = "✗ Download failed. Please try again.";
                }

                // Reset nach 5 Sekunden
                Thread.sleep(5000);
                isDownloading = false;
                downloadStatus = "";

            } catch (Exception e) {
                downloadStatus = "✗ Error: " + e.getMessage();
                isDownloading = false;
                e.printStackTrace();
            }
        }).start();
    }

    private void openURL(String url) {
        try {
            class_156.method_668().method_673(new URI(url));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void method_25419() {
        this.field_22787.method_1507(parent);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}