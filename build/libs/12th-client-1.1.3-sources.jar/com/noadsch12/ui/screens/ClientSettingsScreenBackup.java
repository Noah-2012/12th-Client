/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.ui.screens;

import com.noadsch12.BasicGlobals;
import com.noadsch12.TwelfthConfig;
import com.noadsch12.ui.BlurHandler;
import com.noadsch12.ui.widgets.ModernButton;
import com.noadsch12.util.AntiAFK;
import com.noadsch12.util.Stealth;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10799;
import net.minecraft.class_11719;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_437;

class DotBackup {
    float x, y;
    float vx, vy;

    float shakeX = 0;
    float shakeY = 0;

    DotBackup(int w, int h) {
        x = (float) Math.random() * w;
        y = (float) Math.random() * h;
        vx = ((float) Math.random() - 0.5f) * 0.5f;
        vy = ((float) Math.random() - 0.5f) * 0.5f;
    }

    void applyShake() {
        shakeX += ((float) Math.random() - 0.5f) * 6.5f;
        shakeY += ((float) Math.random() - 0.5f) * 6.5f;
    }

    void update(int w, int h, double mouseX, double mouseY) {
        // normale Bewegung
        x += vx + shakeX;
        y += vy + shakeY;

        // Shake langsam abbauen
        shakeX *= 0.85f;
        shakeY *= 0.85f;

        double dx = x - mouseX;
        double dy = y - mouseY;
        double dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 40) {
            x += (float) (dx * 0.05);
            y += (float) (dy * 0.05);
        }

        if (x < 0 || x > w) vx *= -1;
        if (y < 0 || y > h) vy *= -1;
    }
}

public class ClientSettingsScreenBackup extends class_437 {
    private final class_437 parent;
    private final class_2561 title;
    private final class_2583 font = class_2583.field_24360.method_27704(new class_11719.class_11721(BasicGlobals.ARIAL_FONT));
    public static boolean ProjectileDingEnabled = true;
    public static boolean jumpToFoodEnabled = true;
    public static boolean EntityCullingEnabled = true;
    public static boolean ProjectileTrailEnabled = true;
    public static boolean AutoTotemEnabled = true;
    public static boolean AutoArmorEnabled = true;
    public static boolean AutoRefillEnabled = true;
    public static boolean AutoToolEnabled = true;
    public static boolean BetterChatEnabled = true;
    public static boolean ItemDisplayEnabled = true;
    public static boolean BetterScoreboardEnabled = true;
    public static boolean HideTotemAnimEnabled = true;
    public static boolean SeeThroughGuiEnabled = true;
    public static boolean HideExplosionParticlesEnabled = true;
    public static boolean ShowKeystrokeSettingsEnabled = true;
    public static boolean NoDamageTiltEnabled = true;
    public static boolean AimbotEnabled = true;
    public static boolean EntityEspEnabled = true;
    public static boolean ChestESPEnabled = true;
    public static boolean CompassHudEnabled = true;
    public static boolean PlayerESPEnabled = true;
    public static boolean AntiWebEnabled = true;
    public static boolean AntiAFKEnabled = true;
    public static boolean NoSlowEnabled = true;
    public static boolean AntiKnockbackEnabled = true;
    public static boolean CriticalsEnabled = true;
    public static boolean StealthModeEnabled = true;
    public static boolean FullbrightEnabled = true;
    public static boolean AutoClickerEnabled = true;
    public static boolean TriggerBotEnabled = true;
    public static boolean AutoCobWebEnabled = true;

    private static final String[] TRAIL_NAMES = {"Totem", "Explosion", "Hearts", "Line Trail"};
    private static final String[] TRAIL_COLORS = {"§cRed§r", "§9Blue§r", "§aGreen§r", "§fWhite§r", "§0Black§r"};
    public static int trailIndex = 0;
    public static int trailColorIndex = 0;

    private final List<Dot> dots = new ArrayList<>();

    public static void registerVars() {
        ProjectileDingEnabled = true;
        jumpToFoodEnabled = true;
        EntityCullingEnabled = true;
        ProjectileTrailEnabled = true;
        AutoTotemEnabled = true;
        AutoArmorEnabled = true;
        AutoRefillEnabled = true;
        AutoToolEnabled = true;
        BetterChatEnabled = true;
        ItemDisplayEnabled = true;
        BetterScoreboardEnabled = true;
        HideTotemAnimEnabled = true;
        SeeThroughGuiEnabled = true;
        ShowKeystrokeSettingsEnabled = true;
        NoDamageTiltEnabled = true;
        AimbotEnabled = true;
        EntityEspEnabled = true;
        ChestESPEnabled = true;
        CompassHudEnabled = true;
        PlayerESPEnabled = true;
        AntiWebEnabled = true;
        NoSlowEnabled = true;
        AntiKnockbackEnabled = true;
        CriticalsEnabled = true;
        StealthModeEnabled = true;
        FullbrightEnabled = true;
        AutoClickerEnabled = true;
        AntiAFKEnabled = true;
        TriggerBotEnabled = true;
        AutoCobWebEnabled = true;

        trailIndex = 0;
        trailColorIndex = 0;
    }

    public ClientSettingsScreenBackup(class_437 parent) {
        super(class_2561.method_43470(""));
        this.parent = parent;
        this.field_22785 = class_2561.method_43470("12th Client Settings");
    }

    @Override
    protected void method_25426() {
        if(dots.isEmpty()) {
            for(int i = 0; i < 90; i++) dots.add(new Dot(this.field_22789, this.field_22790));
        }

        super.method_25426();

        int centerX = this.field_22789 / 2;
        int centerY = (this.field_22790 / 2) - 50;
        int bWidth = 150;
        int bHeight = 20;

        int btcWidth = 150;
        int btcHeight = 10;

        int playerX = centerX - 424;

        this.method_37063(new ModernButton(playerX, centerY - 38, bWidth / 2 - 2, 14, class_2561.method_43470("§aEnable All"), btn -> {
            jumpToFoodEnabled = EntityCullingEnabled = BetterChatEnabled = ItemDisplayEnabled =
                    BetterScoreboardEnabled = ShowKeystrokeSettingsEnabled = AntiAFKEnabled = true;
            // Save all to config here if needed
            refreshUI();
        }));
        this.method_37063(new ModernButton(playerX + bWidth / 2 + 2, centerY - 38, bWidth / 2 - 2, 14, class_2561.method_43470("§cDisable All"), btn -> {
            jumpToFoodEnabled = EntityCullingEnabled = BetterChatEnabled = ItemDisplayEnabled =
                    BetterScoreboardEnabled = ShowKeystrokeSettingsEnabled = AntiAFKEnabled = false;
            refreshUI();
        }));

        this.method_37063(new ModernButton(playerX, centerY + 4, bWidth, bHeight,
                class_2561.method_43470("Auto Refill: " + (AutoRefillEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    AutoRefillEnabled = !AutoRefillEnabled;
                    TwelfthConfig.setValue("auto_refill_enabled", String.valueOf(AutoRefillEnabled));
                    btn.method_25355(class_2561.method_43470("Auto Refill: " + (AutoRefillEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Automatically refills an item in the hotbar"));

        this.method_37063(new ModernButton(playerX, centerY + 28, bWidth, bHeight,
                class_2561.method_43470("Auto Tool: " + (AutoToolEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    AutoToolEnabled = !AutoToolEnabled;
                    TwelfthConfig.setValue("auto_tool_enabled", String.valueOf(AutoToolEnabled));
                    btn.method_25355(class_2561.method_43470("Auto Tool: " + (AutoToolEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Automatically jumps to the most efficient\ntool when performing an action"));

        this.method_37063(new ModernButton(playerX, centerY - 20, bWidth, bHeight,
                class_2561.method_43470("Anti Knockback: " + (AntiKnockbackEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    AntiKnockbackEnabled = !AntiKnockbackEnabled;
                    TwelfthConfig.setValue("anti_knockback_enabled", String.valueOf(AntiKnockbackEnabled));
                    btn.method_25355(class_2561.method_43470("Anti Knockback: " + (AntiKnockbackEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Removes the knockback by canceling the packet"));

        int MiscX = centerX - 250;

        // Utils Bulk Buttons
        this.method_37063(new ModernButton(MiscX, centerY - 38, bWidth / 2 - 2, 14, class_2561.method_43470("§aEnable All"), btn -> {
            jumpToFoodEnabled = EntityCullingEnabled = BetterChatEnabled = ItemDisplayEnabled =
                    BetterScoreboardEnabled = ShowKeystrokeSettingsEnabled = AntiAFKEnabled = true;
            // Save all to config here if needed
            refreshUI();
        }));
        this.method_37063(new ModernButton(MiscX + bWidth / 2 + 2, centerY - 38, bWidth / 2 - 2, 14, class_2561.method_43470("§cDisable All"), btn -> {
            jumpToFoodEnabled = EntityCullingEnabled = BetterChatEnabled = ItemDisplayEnabled =
                    BetterScoreboardEnabled = ShowKeystrokeSettingsEnabled = AntiAFKEnabled = false;
            refreshUI();
        }));

        this.method_37063(new ModernButton(
                MiscX,
                centerY - 20,
                bWidth,
                bHeight,
                class_2561.method_43470("Jump to Food: " + (jumpToFoodEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    jumpToFoodEnabled = !jumpToFoodEnabled;
                    TwelfthConfig.setValue("jump_to_food_enabled", String.valueOf(jumpToFoodEnabled));
                    btn.method_25355(class_2561.method_43470("Jump to Food: " + (jumpToFoodEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Automatically jumps to next food item in hotbar"));

        this.method_37063(new ModernButton(MiscX, centerY + 4, bWidth, bHeight,
                class_2561.method_43470("Better Chat: " + (BetterChatEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    BetterChatEnabled = !BetterChatEnabled;
                    TwelfthConfig.setValue("better_chat_enabled", String.valueOf(BetterChatEnabled));
                    btn.method_25355(class_2561.method_43470("Better Chat: " + (BetterChatEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Improves the Chat in many ways"));

        this.method_37063(new ModernButton(MiscX, centerY + 52, bWidth, bHeight,
                class_2561.method_43470("Item Display: " + (ItemDisplayEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    ItemDisplayEnabled = !ItemDisplayEnabled;
                    TwelfthConfig.setValue("item_display_enabled", String.valueOf(ItemDisplayEnabled));
                    btn.method_25355(class_2561.method_43470("Item Display: " + (ItemDisplayEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Shows which and how many items are at one point"));

        this.method_37063(new ModernButton(MiscX, centerY + 28, bWidth, bHeight,
                class_2561.method_43470("Better Scoreboard: " + (BetterScoreboardEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    BetterScoreboardEnabled = !BetterScoreboardEnabled;
                    TwelfthConfig.setValue("better_scoreboard_enabled", String.valueOf(BetterScoreboardEnabled));
                    btn.method_25355(class_2561.method_43470("Better Scoreboard: " + (BetterScoreboardEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Improves the Scoreboard with Design and Ordering"));

        ModernButton outline_settings = new ModernButton(MiscX, centerY + 124, bWidth, bHeight,
                class_2561.method_43470("Open Block Outline Settings"),
                btn -> {
                    this.field_22787.method_1507(new BlockOutlineScreen(this));
                    btn.method_25355(class_2561.method_43470("Open Block Outline Settings"));
                });

        ModernButton keystroke_settings = new ModernButton(MiscX, centerY + 100, bWidth, bHeight,
                class_2561.method_43470("Open Keystroke Settings"),
                btn -> {
                    this.field_22787.method_1507(new KeystrokesSettingsScreen(this));
                    btn.method_25355(class_2561.method_43470("Open Keystroke Settings"));
                });

        this.method_37063(new ModernButton(MiscX, centerY + 76, bWidth, bHeight,
                class_2561.method_43470("Show Keystrokes: " + (ShowKeystrokeSettingsEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    ShowKeystrokeSettingsEnabled = !ShowKeystrokeSettingsEnabled;
                    this.method_37066(keystroke_settings);
                    keystroke_settings.field_22763 = ShowKeystrokeSettingsEnabled;
                    this.method_37063(keystroke_settings);
                    TwelfthConfig.setValue("show_keystrokes_enabled", String.valueOf(ShowKeystrokeSettingsEnabled));
                    btn.method_25355(class_2561.method_43470("Show Keystrokes: " + (ShowKeystrokeSettingsEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Shows Keystrokes with Options like CPS, WASD and Mouse buttons"));

        this.method_37063(keystroke_settings);

        this.method_37063(outline_settings);

        this.method_37063(new ModernButton(MiscX, centerY + 148, bWidth, bHeight,
                class_2561.method_43470("Stealth Mode: " + (StealthModeEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    StealthModeEnabled = !StealthModeEnabled;
                    Stealth.setEnabled(StealthModeEnabled);
                    TwelfthConfig.setValue("stealth_enabled", String.valueOf(StealthModeEnabled));
                    btn.method_25355(class_2561.method_43470("Stealth Mode: " + (StealthModeEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Completely hides the Actions you do from the Server"));

        int combatX = centerX + 100;

        // Cheats Bulk Buttons
        this.method_37063(new ModernButton(combatX, centerY - 38, bWidth / 2 - 2, 14, class_2561.method_43470("§aEnable All"), btn -> {
            AutoTotemEnabled = AutoArmorEnabled = AutoRefillEnabled = AutoToolEnabled =
                    NoDamageTiltEnabled = AimbotEnabled = ChestESPEnabled = PlayerESPEnabled =
                            AntiWebEnabled = NoSlowEnabled = AntiKnockbackEnabled = true;
            refreshUI();
        }));
        this.method_37063(new ModernButton(combatX + bWidth / 2 + 2, centerY - 38, bWidth / 2 - 2, 14, class_2561.method_43470("§cDisable All"), btn -> {
            AutoTotemEnabled = AutoArmorEnabled = AutoRefillEnabled = AutoToolEnabled =
                    NoDamageTiltEnabled = AimbotEnabled = ChestESPEnabled = PlayerESPEnabled =
                            AntiWebEnabled = NoSlowEnabled = AntiKnockbackEnabled = false;
            refreshUI();
        }));

        this.method_37063(new ModernButton(combatX, centerY - 20, bWidth, bHeight,
                class_2561.method_43470("Aimbot: " + (AimbotEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    AimbotEnabled= !AimbotEnabled;
                    TwelfthConfig.setValue("aimbot_enabled", String.valueOf(AimbotEnabled));
                    btn.method_25355(class_2561.method_43470("Aimbot: " + (AimbotEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Always moves the crosshair to the nearest Player"));

        this.method_37063(new ModernButton(combatX, centerY + 52, bWidth, bHeight,
                class_2561.method_43470("Criticals: " + (CriticalsEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    CriticalsEnabled = !CriticalsEnabled;
                    TwelfthConfig.setValue("criticals_enabled", String.valueOf(CriticalsEnabled));
                    btn.method_25355(class_2561.method_43470("Criticals: " + (CriticalsEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Manipulates the Server packet so you do Criticals everytime"));

        this.method_37063(new ModernButton(combatX, centerY + 100, bWidth, bHeight,
                class_2561.method_43470("Auto Clicker: " + (AutoClickerEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    AutoClickerEnabled = !AutoClickerEnabled;
                    TwelfthConfig.setValue("auto_clicker_enabled", String.valueOf(AutoClickerEnabled));
                    btn.method_25355(class_2561.method_43470("Auto Clicker: " + (AutoClickerEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Auto clicks the LMB every Tick"));

        this.method_37063(new ModernButton(combatX, centerY + 4, bWidth, bHeight,
                class_2561.method_43470("Entity ESP: " + (EntityEspEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    EntityEspEnabled = !EntityEspEnabled;
                    TwelfthConfig.setValue("entity_esp_enabled", String.valueOf(EntityEspEnabled));
                    btn.method_25355(class_2561.method_43470("Entity ESP: " + (EntityEspEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Makes Lines around Hitboxes from Entities\n(Green: peacefully, Yellow: not peacefully, Red: Player)"));

        this.method_37063(new ModernButton(combatX, centerY + 28, bWidth, bHeight,
                class_2561.method_43470("Auto Totem: " + (AutoTotemEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    AutoTotemEnabled = !AutoTotemEnabled;
                    TwelfthConfig.setValue("auto_totem_enabled", String.valueOf(AutoTotemEnabled));
                    btn.method_25355(class_2561.method_43470("Auto Totem: " + (AutoTotemEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Automatically places the totem in the slot"));

        this.method_37063(new ModernButton(combatX, centerY + 76, bWidth, bHeight,
                class_2561.method_43470("Auto Armor: " + (AutoArmorEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    AutoArmorEnabled = !AutoArmorEnabled;
                    TwelfthConfig.setValue("auto_armor_enabled", String.valueOf(AutoArmorEnabled));
                    btn.method_25355(class_2561.method_43470("Auto Armor: " + (AutoArmorEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Automatically places the armor in the right slots"));

        this.method_37063(new ModernButton(combatX, centerY + 124, bWidth, bHeight,
                class_2561.method_43470("Trigger Bot: " + (TriggerBotEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    TriggerBotEnabled = !TriggerBotEnabled;
                    TwelfthConfig.setValue("trigger_bot_enabled", String.valueOf(TriggerBotEnabled));
                    btn.method_25355(class_2561.method_43470("Trigger Bot: " + (TriggerBotEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Automatically spams LMB when Crosshair over an Entity"));

        this.method_37063(new ModernButton(combatX, centerY + 148, bWidth, bHeight,
                class_2561.method_43470("Auto Cob Web: " + (AutoCobWebEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    AutoCobWebEnabled = !AutoCobWebEnabled;
                    TwelfthConfig.setValue("auto_cobweb_enabled", String.valueOf(AutoCobWebEnabled));
                    btn.method_25355(class_2561.method_43470("Auto Cob Web: " + (AutoCobWebEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Automatically places Cobwebs in and in front of other Players"));

        int movementX = centerX + 274;

        this.method_37063(new ModernButton(movementX, centerY - 38, bWidth / 2 - 2, 14, class_2561.method_43470("§aEnable All"), btn -> {
            AutoTotemEnabled = AutoArmorEnabled = AutoRefillEnabled = AutoToolEnabled =
                    NoDamageTiltEnabled = AimbotEnabled = ChestESPEnabled = PlayerESPEnabled =
                            AntiWebEnabled = NoSlowEnabled = AntiKnockbackEnabled = true;
            refreshUI();
        }));
        this.method_37063(new ModernButton(movementX + bWidth / 2 + 2, centerY - 38, bWidth / 2 - 2, 14, class_2561.method_43470("§cDisable All"), btn -> {
            AutoTotemEnabled = AutoArmorEnabled = AutoRefillEnabled = AutoToolEnabled =
                    NoDamageTiltEnabled = AimbotEnabled = ChestESPEnabled = PlayerESPEnabled =
                            AntiWebEnabled = NoSlowEnabled = AntiKnockbackEnabled = false;
            refreshUI();
        }));

        this.method_37063(new ModernButton(
                movementX,
                centerY - 20,
                bWidth,
                bHeight,
                class_2561.method_43470("Anti Web: " + (AntiWebEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    AntiWebEnabled = !AntiWebEnabled;
                    TwelfthConfig.setValue("anti_web_enabled", String.valueOf(AntiWebEnabled));
                    btn.method_25355(class_2561.method_43470("Anti Web: " + (AntiWebEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Removes the slow down when walking into a Web"));

        this.method_37063(new ModernButton(
                movementX,
                centerY + 4,
                bWidth,
                bHeight,
                class_2561.method_43470("No Slow: " + (NoSlowEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    NoSlowEnabled = !NoSlowEnabled;
                    TwelfthConfig.setValue("no_slow_enabled", String.valueOf(NoSlowEnabled));
                    btn.method_25355(class_2561.method_43470("No Slow: " + (NoSlowEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Removes the slow down when using item like food\nor drawing a bow"));

        this.method_37063(new ModernButton(movementX, centerY + 28, bWidth, bHeight,
                class_2561.method_43470("Anti AFK: " + (AntiAFKEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    AntiAFKEnabled = !AntiAFKEnabled;
                    AntiAFK.enabled = AntiAFKEnabled;
                    TwelfthConfig.setValue("anti_afk_enabled", String.valueOf(AntiAFKEnabled));
                    btn.method_25355(class_2561.method_43470("Anti AFK: " + (AntiAFKEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Lets the Player jump every five Seconds"));

        int renderX = centerX - (bWidth / 2);

        // Rendering Bulk Buttons
        this.method_37063(new ModernButton(renderX, centerY - 38, bWidth / 2 - 2, 14, class_2561.method_43470("§aEnable All"), btn -> {
            HideTotemAnimEnabled = HideExplosionParticlesEnabled = EntityEspEnabled =
                    CompassHudEnabled = ProjectileDingEnabled = ProjectileTrailEnabled = true;
            refreshUI();
        }));
        this.method_37063(new ModernButton(renderX + bWidth / 2 + 2, centerY - 38, bWidth / 2 - 2, 14, class_2561.method_43470("§cDisable All"), btn -> {
            HideTotemAnimEnabled = HideExplosionParticlesEnabled = EntityEspEnabled =
                    CompassHudEnabled = ProjectileDingEnabled = ProjectileTrailEnabled = false;
            refreshUI();
        }));

        this.method_37063(new ModernButton(
                renderX,
                centerY - 20,
                bWidth,
                bHeight,
                class_2561.method_43470("Hide Totem Animation: " + (HideTotemAnimEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    HideTotemAnimEnabled = !HideTotemAnimEnabled;
                    TwelfthConfig.setValue("hide_totem_enabled", String.valueOf(HideTotemAnimEnabled));
                    btn.method_25355(class_2561.method_43470("Hide Totem Animation: " + (HideTotemAnimEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Hides the Totem popping Animation so it does\nnot distract the Player"));

        this.method_37063(new ModernButton(
                renderX,
                centerY + 4,
                bWidth,
                bHeight,
                class_2561.method_43470("Hide Explosion Particles: " + (HideExplosionParticlesEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    HideExplosionParticlesEnabled = !HideExplosionParticlesEnabled;
                    TwelfthConfig.setValue("hide_explosion_enabled", String.valueOf(HideExplosionParticlesEnabled));
                    btn.method_25355(class_2561.method_43470("Hide Explosion Particles: " + (HideExplosionParticlesEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Hides the Explosion Particles so it does\nnot distract the Player"));

        this.method_37063(new ModernButton(renderX, centerY + 52, bWidth, bHeight,
                class_2561.method_43470("No Damage Tilt: " + (NoDamageTiltEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    NoDamageTiltEnabled = !NoDamageTiltEnabled;
                    TwelfthConfig.setValue("no_tilt_enabled", String.valueOf(NoDamageTiltEnabled));
                    btn.method_25355(class_2561.method_43470("No Damage Tilt: " + (NoDamageTiltEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Disables the Camera Tilt when getting damaged"));

        this.method_37063(new ModernButton(renderX, centerY + 76, bWidth, bHeight,
                class_2561.method_43470("Storage ESP: " + (ChestESPEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    ChestESPEnabled= !ChestESPEnabled;
                    TwelfthConfig.setValue("storage_esp_enabled", String.valueOf(ChestESPEnabled));
                    btn.method_25355(class_2561.method_43470("Storage ESP: " + (ChestESPEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Marks every Chest in ESP Radius and uses the CBCS\n(Chunk Block Cache System)"));

        this.method_37063(new ModernButton(renderX, centerY + 100, bWidth, bHeight,
                class_2561.method_43470("Player ESP: " + (PlayerESPEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    PlayerESPEnabled = !PlayerESPEnabled;
                    TwelfthConfig.setValue("player_esp_enabled", String.valueOf(PlayerESPEnabled));
                    btn.method_25355(class_2561.method_43470("Player ESP: " + (PlayerESPEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Marks every Player in ESP Radius and uses the PUCS\n(Player UUID Cache System)"));

        this.method_37063(new ModernButton(renderX, centerY + 124, bWidth, bHeight,
                class_2561.method_43470("Entity Culling: " + (EntityCullingEnabled ? "§aOn by Default" : "§cOnly by Command")),
                btn -> {
                    EntityCullingEnabled = !EntityCullingEnabled;
                    TwelfthConfig.setValue("entity_culling_enabled", String.valueOf(EntityCullingEnabled));
                    btn.method_25355(class_2561.method_43470("Entity Culling: " + (EntityCullingEnabled ? "§aOn by Default" : "§cOnly by Command")));
                }).withTooltip("Ensures entities which cannot be seen aren't rendered"));

        this.method_37063(new ModernButton(renderX, centerY + 28, bWidth, bHeight,
                class_2561.method_43470("Compass HUD: " + (CompassHudEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    CompassHudEnabled = !CompassHudEnabled;
                    TwelfthConfig.setValue("compass_hud_enabled", String.valueOf(CompassHudEnabled));
                    btn.method_25355(class_2561.method_43470("Compass HUD: " + (CompassHudEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Makes a Compass in the top middle Screen that shows the Directions and Waypoints"));

        this.method_37063(new ModernButton(renderX, centerY + 148, bWidth, bHeight,
                class_2561.method_43470("Fullbright: " + (FullbrightEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    FullbrightEnabled = !FullbrightEnabled;
                    if (class_310.method_1551().field_1769 != null) {
                        class_310.method_1551().field_1769.method_3279();
                    }
                    TwelfthConfig.setValue("fullbright_enabled", String.valueOf(FullbrightEnabled));
                    btn.method_25355(class_2561.method_43470("Fullbright: " + (FullbrightEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Manipulates every Block for the full brightness\n(Requires Block update, gets fixed soon)"));

        ModernButton trailColorButton = new ModernButton(renderX, centerY + 240, btcWidth, btcHeight,
                class_2561.method_43470("Trail Color: " + TRAIL_COLORS[trailColorIndex]),
                btn -> {
                    trailColorIndex = (trailColorIndex + 1) % TRAIL_COLORS.length;
                    TwelfthConfig.setValue("trail_color_index", String.valueOf(trailColorIndex));
                    btn.method_25355(class_2561.method_43470("Trail Color: " + TRAIL_COLORS[trailColorIndex]));
                }).withTooltip("Select a color for the trail");

        if (trailIndex != 3) {
            trailColorButton.field_22763 = false;
        }
        this.method_37063(trailColorButton);

        ModernButton trailButton = new ModernButton(renderX, centerY + 220, bWidth, bHeight,
                class_2561.method_43470("Trail Mode: " + TRAIL_NAMES[trailIndex]),
                btn -> {
                    this.method_37066(trailColorButton);
                    trailIndex = (trailIndex + 1) % TRAIL_NAMES.length;
                    if (trailIndex == 3) {
                        trailColorButton.field_22763 = true;
                    } else {
                        trailColorButton.field_22763 = false;
                    }
                    TwelfthConfig.setValue("trail_index", String.valueOf(trailIndex));
                    this.method_37063(trailColorButton);
                    btn.method_25355(class_2561.method_43470("Trail Mode: " + TRAIL_NAMES[trailIndex]));
                }).withTooltip("Select a trail mode");

        this.method_37063(new ModernButton(renderX, centerY + 172, bWidth, bHeight,
                class_2561.method_43470("Projectile Ding: " + (ProjectileDingEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    ProjectileDingEnabled = !ProjectileDingEnabled;
                    TwelfthConfig.setValue("projectile_ding_enabled", String.valueOf(ProjectileDingEnabled));
                    btn.method_25355(class_2561.method_43470("Projectile Ding: " + (ProjectileDingEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Makes a ding when hitting an entity\n(high when not killed; low when killed)"));

        this.method_37063(new ModernButton(renderX, centerY + 196, bWidth, bHeight,
                class_2561.method_43470("Projectile Trail: " + (ProjectileTrailEnabled ? "§aON" : "§cOFF")),
                btn -> {
                    ProjectileTrailEnabled = !ProjectileTrailEnabled;
                    this.method_37066(trailButton);
                    trailButton.field_22763 = ProjectileTrailEnabled;
                    this.method_37063(trailButton);
                    if (trailIndex == 3) {
                        this.method_37066(trailColorButton);
                        trailColorButton.field_22763 = ProjectileTrailEnabled;
                        this.method_37063(trailColorButton);
                    }
                    TwelfthConfig.setValue("projectile_trail_enabled", String.valueOf(ProjectileTrailEnabled));
                    btn.method_25355(class_2561.method_43470("Projectile Trail: " + (ProjectileTrailEnabled ? "§aON" : "§cOFF")));
                }).withTooltip("Makes a trail behind arrows"));

        if (!ProjectileTrailEnabled) {
            trailButton.field_22763 = false;
        }
        this.method_37063(trailButton);

        this.method_25422();

        // === DEV / DEBUG ===
        this.method_37063(new ModernButton(centerX - 50, centerY + 292, 100, 20,
                class_2561.method_43470("§cCrash Client"),
                btn -> {
                    throw new RuntimeException("12th Client managed Crash - THIS IS NOT A REAL CRASH - ");
                }
        ).withTooltip("Intentionally crashes the client\n(for testing the crash handler)"));


        if (this.field_22787.field_1687 == null) {
            this.method_37063(new ModernButton(centerX - 50, centerY + 268, 100, 20,
                    class_2561.method_43470("Back"),
                    btn -> this.method_25419()));
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        if (this.field_22787.field_1687 != null) {
            BlurHandler.executeBlur(context, this.field_22789, this.field_22790, 2.0f);
            super.method_25394(context, mouseX, mouseY, deltaTicks);
        } else {
            context.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF101010);

            for (Dot dot : dots) {
                dot.update(this.field_22789, this.field_22790, mouseX, mouseY);
                context.method_25294((int)dot.x, (int)dot.y, (int)dot.x + 2, (int)dot.y + 2, 0x55FFFFFF);
            }

            for (int i = 0; i < dots.size(); i++) {
                Dot a = dots.get(i);
                for (int j = i + 1; j < dots.size(); j++) {
                    Dot b = dots.get(j);
                    double dist = Math.sqrt(Math.pow(a.x - b.x, 2) + Math.pow(a.y - b.y, 2));

                    if (dist < 25) {
                        int alpha = (int) ((1.0 - (dist / 50.0)) * 100);
                        int color = (alpha << 24) | 0xFFFFFF;
                        context.method_25294((int)a.x, (int)a.y, (int)b.x, (int)b.y + 1, color);
                    }
                }
            }

            super.method_25394(context, mouseX, mouseY, deltaTicks);
        }

        int centerX = this.field_22789 / 2;
        int centerY = (this.field_22790 / 2) - 62;

        context.method_27534(this.field_22793, this.field_22785, centerX, 15, 0xFFFFFFFF);

        context.method_27535(this.field_22793, class_2561.method_43470("Player").method_10862(font), centerX - 361, centerY - 40, 0xFFFFAA00);
        context.method_51427(new class_1799(class_1802.field_8575), centerX - 379, centerY - 45);

        context.method_27535(this.field_22793, class_2561.method_43470("Misc").method_10862(font), centerX - 183, centerY - 40, 0xFFFFAA00);
        context.method_51427(new class_1799(class_1802.field_8251), centerX - 206, centerY - 45);

        context.method_27534(this.field_22793, class_2561.method_43470("Render").method_10862(font), centerX - 10, centerY - 40, 0xFFFFAA00);
        context.method_51427(new class_1799(class_1802.field_27070), centerX - 6, centerY - 62);

        context.method_27535(this.field_22793, class_2561.method_43470("Combat").method_10862(font), centerX + 165, centerY - 40, 0xFFFFAA00);
        context.method_51427(new class_1799(class_1802.field_22022), centerX + 201, centerY - 45);

        context.method_27535(this.field_22793, class_2561.method_43470("Movement").method_10862(font), centerX + 329, centerY - 40, 0xFFFFAA00);
        context.method_51427(new class_1799(class_1802.field_8833), centerX + 375, centerY - 45);

        int previewX = centerX + 83;
        int previewY = centerY + 78;

        class_1799 previewStack = switch (trailIndex) {
            case 0 -> new class_1799(class_1802.field_8288);
            case 1 -> new class_1799(class_1802.field_8626);
            case 3 -> new class_1799(class_1802.field_8600);
            default -> class_1799.field_8037;
        };

        if (!previewStack.method_7960()) {
            context.method_51427(previewStack, previewX, previewY);
        } else if (trailIndex == 2) {
            context.method_52707(class_10799.field_56883, class_2960.method_60656("hud/heart/full"), previewX, previewY + 2, 11, 11, 0xFFFFFFFF);
        }

        for (class_364 element : this.method_25396()) {
            if (element instanceof ModernButton button && button.shouldRenderTooltip(mouseX, mouseY)) {
                button.renderCustomTooltip(
                        context,
                        mouseX,
                        mouseY,
                        button.getTooltipAlpha()
                );
            }
        }
    }

    @Override
    public void method_25419() {
        assert this.field_22787 != null;
        this.field_22787.method_1507(this.parent);
    }

    @Override
    public boolean method_25422() {
        return true;
    }

    private void refreshUI() {
        this.method_41843();
    }

    @Override
    public boolean method_25402(net.minecraft.class_11909 click, boolean doubleClick) {
        if (click.method_74232()) {
            for (Dot dot : dots) {
                dot.applyShake();
                return true;
            }
        }
        return super.method_25402(click, doubleClick);
    }
}