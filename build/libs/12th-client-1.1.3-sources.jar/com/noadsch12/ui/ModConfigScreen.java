package com.noadsch12.ui;

import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.gui.entries.BooleanListEntry;
import me.shedaniel.clothconfig2.gui.entries.IntegerListEntry;
import me.shedaniel.clothconfig2.gui.entries.IntegerSliderEntry;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import java.util.Optional;

public class ModConfigScreen {

    public static class_437 getConfigScreen(class_437 parent) {
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(class_2561.method_30163("MyMod Config"));

        ConfigCategory general = builder.getOrCreateCategory(class_2561.method_30163("General"));

        MyModConfig config = MyModConfig.get();

        // Boolean Entry
        BooleanListEntry enableFeatureEntry = new BooleanListEntry(
                class_2561.method_30163("Enable Feature"),
                config.enableFeature,
                class_2561.method_30163("Reset"),
                () -> config.enableFeature,
                value -> config.enableFeature = value
        );
        general.addEntry(enableFeatureEntry);

        // Integer Entry (angepasst an neuen Konstruktor)
        IntegerListEntry featureLevelEntry = new IntegerListEntry(
                class_2561.method_30163("Feature Level"),                // Feldname
                config.featureLevel,                    // aktueller Wert
                class_2561.method_30163("Reset"),                        // Reset-Button Text
                () -> 5,                                 // Default-Wert
                value -> config.featureLevel = value,    // Save-Consumer
                () -> Optional.of(new class_2561[]{class_2561.method_30163("Set feature level 0-10")}), // Tooltip
                false                                     // requiresRestart
        );

        IntegerSliderEntry featureLevelSlider = new IntegerSliderEntry(
                class_2561.method_30163("Feature Level but as slider"),
                0,
                10,
                config.featureLevel,
                class_2561.method_30163("Reset"),
                () -> 5,
                value -> config.featureLevel = value,
                () -> Optional.of(new class_2561[]{class_2561.method_30163("Set feature level 0-10")}),
                false
        );

        general.addEntry(featureLevelEntry);

        general.addEntry(featureLevelSlider);

        return builder.build();
    }
}
