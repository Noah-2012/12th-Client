/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.cheats;

import java.util.Comparator;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class PlayerAimbotHandler {
    private static final double RANGE = 8.0;

    public static void updateAimbot(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        // Find the closest PlayerEntity within 8 blocks
        class_1657 target = client.field_1687.method_8390(
                        class_1657.class,
                        client.field_1724.method_5829().method_1014(RANGE),
                        entity -> entity.method_5805()
                                && entity != client.field_1724 // IMPORTANT: Don't aim at yourself!
                                && client.field_1724.method_6057(entity)
                ).stream()
                .min(Comparator.comparingDouble(player -> player.method_5739(client.field_1724)))
                .orElse(null);

        if (target != null) {
            facePlayer(client, target);
        }
    }

    private static void facePlayer(class_310 client, class_1657 target) {
        // Targets the eye position or center of the player
        class_243 targetPos = target.method_33571();
        class_243 playerPos = client.field_1724.method_33571();

        double diffX = targetPos.field_1352 - playerPos.field_1352;
        double diffY = targetPos.field_1351 - playerPos.field_1351;
        double diffZ = targetPos.field_1350 - playerPos.field_1350;

        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);

        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
        float pitch = (float) -Math.toDegrees(Math.atan2(diffY, diffXZ));

        client.field_1724.method_36456(yaw);
        client.field_1724.method_36457(pitch);
    }
}