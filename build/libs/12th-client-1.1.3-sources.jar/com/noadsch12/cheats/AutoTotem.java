/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.cheats;

import com.noadsch12.modules.impl.combat.AutoTotemModule;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class AutoTotem {

    private static long lastSwapTime = 0;

    public static void tick() {
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;

        if (player == null || mc.field_1761 == null) return;

        // --------------------------------------------------
        // DELAY HANDLING
        // --------------------------------------------------
        if (AutoTotemModule.delayEnabled) {
            long now = System.currentTimeMillis();
            if (now - lastSwapTime < AutoTotemModule.delay) return;
        }

        // Slot 45 is offhand
        class_1799 offhandStack = player.method_6079();

        // Already holding totem
        if (offhandStack.method_7909() == class_1802.field_8288) return;

        int totemSlot = findTotemSlot(player.method_31548());
        if (totemSlot == -1) return;

        int syncId = player.field_7498.field_7763;

        // Pick up totem
        mc.field_1761.method_2906(syncId, totemSlot, 0, class_1713.field_7790, player);

        // Place in offhand
        mc.field_1761.method_2906(syncId, 45, 0, class_1713.field_7790, player);

        // Return previous offhand item
        mc.field_1761.method_2906(syncId, totemSlot, 0, class_1713.field_7790, player);

        lastSwapTime = System.currentTimeMillis();
    }

    private static int findTotemSlot(class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            if (inventory.method_5438(i).method_7909() == class_1802.field_8288) {
                if (i < 9) return i + 36; // hotbar → handler slot
                return i;                 // main inventory
            }
        }
        return -1;
    }
}
