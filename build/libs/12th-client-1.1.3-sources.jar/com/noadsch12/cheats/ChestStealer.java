/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.cheats;

import java.util.Random;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_9334;

public class ChestStealer {
    private static boolean enabled = false;
    private static boolean isStealingInProgress = false;
    private static long stealStartTime = 0;
    private static int initialDelay = 0;
    private static final Random random = new Random();

    public static void setEnabled(boolean value) {
        enabled = value;
        if (!enabled) {
            isStealingInProgress = false;
        }
    }

    public static boolean isEnabled() {
        return enabled;
    }

    public static void onScreenOpen(class_1703 screenHandler) {
        if (!enabled) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        // Check if it's actually a container (chest, barrel, shulker box, etc.)
        if (!(screenHandler instanceof class_1707)) {
            return;
        }

        // Reset state for new chest
        isStealingInProgress = true;
        stealStartTime = System.currentTimeMillis();
        initialDelay = 100 + random.nextInt(101); // Random delay between 100-200ms
    }

    public static void tick() {
        if (!enabled || !isStealingInProgress) return;

        class_310 client = class_310.method_1551();
        class_746 player = client.field_1724;

        if (player == null || player.field_7512 == null) {
            isStealingInProgress = false;
            return;
        }

        class_1703 handler = player.field_7512;

        // Double-check it's still a container
        if (!(handler instanceof class_1707)) {
            isStealingInProgress = false;
            return;
        }

        // Wait for initial delay before starting to steal
        long currentTime = System.currentTimeMillis();
        if (currentTime - stealStartTime < initialDelay) {
            return; // Wait for initial delay
        }

        // Steal all items at once
        int chestSlotCount = handler.field_7761.size() - 36; // 36 = player inventory slots

        for (int i = 0; i < chestSlotCount; i++) {
            class_1735 slot = handler.field_7761.get(i);
            class_1799 stack = slot.method_7677();

            if (!stack.method_7960() && shouldTakeItem(stack, player)) {
                // Click the slot to take the item
                assert client.field_1761 != null;
                client.field_1761.method_2906(
                        handler.field_7763,
                        i,
                        0,
                        class_1713.field_7794,
                        player
                );
            }
        }

        // Close the screen immediately after stealing
        client.execute(player::method_7346);
        isStealingInProgress = false;
    }

    private static boolean shouldTakeItem(class_1799 stack, class_746 player) {
        // Check if player already has this item type in inventory
        for (int i = 0; i < player.method_31548().method_5439(); i++) {
            class_1799 invStack = player.method_31548().method_5438(i);
            if (!invStack.method_7960() && class_1799.method_7984(stack, invStack)) {
                return true; // Take items we already have
            }
        }

        // Check if it's a "good" item (you can customize this logic)
        return isGoodItem(stack);
    }

    private static boolean isGoodItem(class_1799 stack) {
        // Customize this method to define what constitutes a "good" item
        // Example criteria:
        String itemName = stack.method_7909().toString().toLowerCase();

        // Skip common junk items
        if (itemName.contains("dirt") ||
                itemName.contains("cobblestone") ||
                itemName.contains("stick")) {
            return false;
        }

        // Take tools, weapons, armor, food, valuable items
        return stack.method_7909().method_7854().method_7963() || // Tools, weapons, armor
                stack.method_57826(class_9334.field_50075) ||        // Food items
                stack.method_7932().ordinal() > 0;   // Uncommon+ rarity items
    }
}