package com.noadsch12.util;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_9334;

public class AutoArmor {

    public static void tick() {
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null || mc.field_1761 == null) return;

        // Slot IDs: 5 (Head), 6 (Chest), 7 (Legs), 8 (Feet)
        checkAndEquip(player, 5, class_1304.field_6169);
        checkAndEquip(player, 6, class_1304.field_6174);
        checkAndEquip(player, 7, class_1304.field_6172);
        checkAndEquip(player, 8, class_1304.field_6166);
    }

    private static void checkAndEquip(class_746 player, int handlerSlot, class_1304 targetSlot) {
        // Check what is currently in the armor slot
        class_1799 currentArmor = player.field_7498.method_7611(handlerSlot).method_7677();

        // Only equip if the slot is empty
        if (!currentArmor.method_7960()) return;

        int bestSlot = findBestArmorInInventory(player, targetSlot);
        if (bestSlot != -1) {
            int syncId = player.field_7498.field_7763;
            class_310.method_1551().field_1761.method_2906(syncId, bestSlot, 0, class_1713.field_7794, player);
        }
    }

    private static int findBestArmorInInventory(class_746 player, class_1304 targetSlot) {
        List<Integer> candidates = new ArrayList<>();

        // Main inventory slots 9 to 44
        for (int i = 9; i < 45; i++) {
            class_1799 stack = player.field_7498.method_7611(i).method_7677();

            // In 1.21.10, we check the Equippable Component
            // This is the new way since ArmorItem is being phased out
            var equippable = stack.method_58694(class_9334.field_54196);
            if (equippable != null && equippable.comp_3174() == targetSlot) {
                candidates.add(i);
            }
        }

        // Return the one with the highest damage (lowest durability)
        return candidates.stream()
                .max(Comparator.comparingInt(slot ->
                        player.field_7498.method_7611(slot).method_7677().method_58695(class_9334.field_49629, 0)))
                .orElse(-1);
    }
}