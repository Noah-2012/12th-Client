/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.util.world;

import com.noadsch12.TwelfthClient;
import com.noadsch12.modules.ModuleManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.lwjgl.glfw.GLFW;

import java.lang.reflect.Field;

@Environment(EnvType.CLIENT)
public class HotbarHelper {
    private static boolean lastRightShiftState = false;
    private static Field selectedField;

    private static void initSelectedField() {
        if (selectedField != null) return; // Search only once

        try {
            // Try different field names (for 1.21.10: Yarn Mappings)
            String[] possibleNames = {"field_7545", "selectedSlot", "m", "selected", "f_19829_", "currentItem", "p_19829_"};
            for (String name : possibleNames) {
                try {
                    Field field = net.minecraft.class_1661.class.getDeclaredField(name);
                    field.setAccessible(true);
                    selectedField = field;
                    TwelfthClient.LOGGER.info("Found selected field: " + name);
                    return;
                } catch (NoSuchFieldException ignored) {}
            }

            TwelfthClient.LOGGER.warn("Could not find selected field in PlayerInventory class!");
            // Log all fields for debugging
            TwelfthClient.LOGGER.info("Available fields in PlayerInventory:");
            for (Field f : net.minecraft.class_1661.class.getDeclaredFields()) {
                TwelfthClient.LOGGER.info("  - " + f.getName() + " (" + f.getType().getSimpleName() + ")");
            }
        } catch (Exception e) {
            TwelfthClient.LOGGER.error("Error initializing selectedField", e);
        }
    }

    public static void register() {
        TwelfthClient.LOGGER.info("HotbarHelper registered!");

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            try {
                class_1657 player = class_310.method_1551().field_1724;
                if (player == null) return;

                // Initialize the selected field on the first tick in the world
                initSelectedField();

                // Check if Right Shift is pressed
                boolean rightShiftDown = GLFW.glfwGetKey(
                        GLFW.glfwGetCurrentContext(),
                        GLFW.GLFW_KEY_RIGHT_SHIFT
                ) == GLFW.GLFW_PRESS;

                // Check if J is pressed
                boolean jDown = GLFW.glfwGetKey(
                        GLFW.glfwGetCurrentContext(),
                        GLFW.GLFW_KEY_J
                ) == GLFW.GLFW_PRESS;

                if (rightShiftDown || jDown) {
                    TwelfthClient.LOGGER.info("RightShift: " + rightShiftDown + ", J: " + jDown);
                }

                // Only when pressing (edge), not when holding
                boolean jWasPressed = false;
                if (jDown && !lastRightShiftState) {
                    jWasPressed = true;
                }

                if (rightShiftDown && jWasPressed) {
                    TwelfthClient.LOGGER.info("Key combination detected! Jumping to food...");
                    jumpToNextFood(player);
                }

                lastRightShiftState = jDown;
            } catch (Exception e) {
                TwelfthClient.LOGGER.error("Error in HotbarHelper tick", e);
            }
        });
    }

    private static void jumpToNextFood(class_1657 player) {
        if (!ModuleManager.getInstance().getModule("Jump to Food").isEnabled()) return;

        for (int i = 0; i < 9; i++) {
            class_1799 stack = player.method_31548().method_5438(i);

            if (isFood(stack)) {
                setSelectedSlot(player, i);
                TwelfthClient.LOGGER.info("Jumped to food at slot " + (i + 1));
                return;
            }
        }
        TwelfthClient.LOGGER.warn("No food found in hotbar!");
    }

    private static void setSelectedSlot(class_1657 player, int slot) {
        try {
            if (selectedField != null) {
                selectedField.setInt(player.method_31548(), slot);
            } else {
                // Fallback: try using different field names
                Field field = null;
                for (String name : new String[]{"selectedSlot", "m", "selected"}) {
                    try {
                        field = net.minecraft.class_1661.class.getDeclaredField(name);
                        field.setAccessible(true);
                        field.setInt(player.method_31548(), slot);
                        selectedField = field;
                        return;
                    } catch (NoSuchFieldException ignored) {}
                }
                TwelfthClient.LOGGER.warn("Could not set selected slot!");
            }
        } catch (IllegalAccessException e) {
            TwelfthClient.LOGGER.error("Failed to set selected slot via reflection", e);
        }
    }

    private static boolean isFood(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return false;
        }

        // Prüfe bekannte Food-Items
        return stack.method_7909() == class_1802.field_8279 ||
                stack.method_7909() == class_1802.field_8512 ||
                stack.method_7909() == class_1802.field_8046 ||
                stack.method_7909() == class_1802.field_8229 ||
                stack.method_7909() == class_1802.field_8179 ||
                stack.method_7909() == class_1802.field_8726 ||
                stack.method_7909() == class_1802.field_8429 ||
                stack.method_7909() == class_1802.field_8423 ||
                stack.method_7909() == class_1802.field_8551 ||
                stack.method_7909() == class_1802.field_8463 ||
                stack.method_7909() == class_1802.field_8071 ||
                stack.method_7909() == class_1802.field_8497 ||
                stack.method_7909() == class_1802.field_8748 ||
                stack.method_7909() == class_1802.field_8389 ||
                stack.method_7909() == class_1802.field_8567 ||
                stack.method_7909() == class_1802.field_8323 ||
                stack.method_7909() == class_1802.field_8741 ||
                stack.method_7909() == class_1802.field_8504 ||
                stack.method_7909() == class_1802.field_8308 ||
                stack.method_7909() == class_1802.field_8209 ||
                stack.method_7909() == class_1802.field_8846 ||
                stack.method_7909() == class_1802.field_16998 ||
                stack.method_7909() == class_1802.field_28659 ||
                stack.method_7909() == class_1802.field_20417;
    }
}