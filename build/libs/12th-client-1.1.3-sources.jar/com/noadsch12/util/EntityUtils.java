package com.noadsch12.util;

import java.util.function.Predicate;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1511;
import net.minecraft.class_1678;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;

public enum EntityUtils
{
    ;
    protected static final class_310 MC = class_310.method_1551();

    /**
     * Returns a stream of all *attackable* entities in the world.
     *
     * Attackable = LivingEntity with health > 0,
     *               EndCrystalEntity,
     *               ShulkerBulletEntity,
     *               excluding the player and friends.
     */
    public static Stream<class_1297> getAttackableEntities()
    {
        return StreamSupport
                .stream(MC.field_1687.method_18112().spliterator(), true)
                .filter(IS_ATTACKABLE);
    }

    public static final Predicate<class_1297> IS_ATTACKABLE =
            e -> e != null && !e.method_31481()
                    && ((e instanceof class_1309 && ((class_1309)e).method_6032() > 0)
                    || e instanceof class_1511
                    || e instanceof class_1678)
                    && e != MC.field_1724;

    /**
     * Returns a stream of *valid animals* (e.g., for animal ESP).
     * Valid = AnimalEntity, not removed, health > 0.
     */
    public static Stream<class_1429> getValidAnimals()
    {
        return StreamSupport
                .stream(MC.field_1687.method_18112().spliterator(), true)
                .filter(class_1429.class::isInstance)
                .map(e -> (class_1429)e)
                .filter(IS_VALID_ANIMAL);
    }

    public static final Predicate<class_1429> IS_VALID_ANIMAL =
            a -> a != null && !a.method_31481() && a.method_6032() > 0;

    /**
     * Interpolates (lerps) between the entity's previous and current position
     * to get smooth rendering coordinates.
     */
    public static class_243 getLerpedPos(class_1297 e, float partialTicks)
    {
        if (e.method_31481())
            return e.method_73189(); // fallback, Entity entfernt

        return e.method_30950(partialTicks); // Vanilla-Lerp
    }

    /**
     * Interpolates between the entity's bounding box in the previous
     * tick and the current tick for smooth bounding boxes.
     */
    public static class_238 getLerpedBox(class_1297 e, float partialTicks)
    {
        if (e.method_31481())
            return e.method_5829();

        class_243 offset = getLerpedPos(e, partialTicks).method_1020(e.method_73189());
        return e.method_5829().method_997(offset);
    }
}
