package com.noadsch12.util;

import java.util.ArrayList;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.class_151;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_7923;

public enum BlockUtils
{
    ;

    private static final class_310 MC = class_310.method_1551();

    public static class_2680 getState(class_2338 pos)
    {
        return MC.field_1687.method_8320(pos);
    }

    public static class_2248 getBlock(class_2338 pos)
    {
        return getState(pos).method_26204();
    }

    public static String getName(class_2338 pos)
    {
        return getName(getBlock(pos));
    }

    public static String getName(class_2248 block)
    {
        return class_7923.field_41175.method_10221(block).toString();
    }

    public static class_2248 getBlockFromName(String name)
    {
        try
        {
            return class_7923.field_41175.method_63535(class_2960.method_12829(name));
        }
        catch (class_151 e)
        {
            return class_2246.field_10124;
        }
    }

    public static class_2248 getBlockFromNameOrID(String nameOrId)
    {
        // Legacy numeric IDs nicht mehr unterstützt
        if (isInteger(nameOrId))
            return null;

        try
        {
            class_2960 id = class_2960.method_12829(nameOrId);
            if(!class_7923.field_41175.method_10250(id))
                return null;

            return class_7923.field_41175.method_63535(id);
        }
        catch (class_151 e)
        {
            return null;
        }
    }

    private static boolean isInteger(String s) {
        if (s == null || s.isEmpty()) return false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (i == 0 && (c == '-' || c == '+')) continue;
            if (!Character.isDigit(c)) return false;
        }
        return true;
    }

    public static float getHardness(class_2338 pos) {
        return getState(pos).method_26214(MC.field_1687, pos);
    }

    public static boolean isUnbreakable(class_2338 pos) {
        return getState(pos).method_26214(MC.field_1687, pos) < 0;
    }

    private static class_265 getOutlineShape(class_2338 pos)
    {
        return getState(pos).method_26218(MC.field_1687, pos);
    }

    public static class_238 getBoundingBox(class_2338 pos)
    {
        return getOutlineShape(pos).method_1107().method_989(pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    public static boolean canBeClicked(class_2338 pos)
    {
        return getOutlineShape(pos) != class_259.method_1073();
    }

    public static boolean isOpaqueFullCube(class_2338 pos) {
        return getState(pos).method_26225();
    }

    public static class_3965 raycast(class_243 from, class_243 to, class_3959.class_242 fluidHandling)
    {
        class_3959 context = new class_3959(from, to,
                class_3959.class_3960.field_17558, fluidHandling, MC.field_1724);

        return MC.field_1687.method_17742(context);
    }

    public static class_3965 raycast(class_243 from, class_243 to)
    {
        return raycast(from, to, class_3959.class_242.field_1348);
    }

    public static boolean hasLineOfSight(class_243 from, class_243 to)
    {
        return raycast(from, to).method_17783() == class_239.class_240.field_1333;
    }

    public static boolean hasLineOfSight(class_243 to) {
        return raycast(MC.field_1724.method_5836(1.0f), to).method_17783() == class_239.class_240.field_1333;
    }

    /**
     * Returns a stream of all blocks that collide with the given box.
     * Only returns bounding boxes that intersect the given box.
     */
    public static Stream<class_238> getBlockCollisions(class_238 box)
    {
        Iterable<class_265> blockCollisions = MC.field_1687.method_20812(MC.field_1724, box);

        return StreamSupport.stream(blockCollisions.spliterator(), false)
                .flatMap(shape -> shape.method_1090().stream())
                .filter(shapeBox -> shapeBox.method_994(box));
    }

    public static ArrayList<class_2338> getAllInBox(class_2338 from, class_2338 to)
    {
        ArrayList<class_2338> blocks = new ArrayList<>();

        class_2338 min = new class_2338(Math.min(from.method_10263(), to.method_10263()),
                Math.min(from.method_10264(), to.method_10264()), Math.min(from.method_10260(), to.method_10260()));
        class_2338 max = new class_2338(Math.max(from.method_10263(), to.method_10263()),
                Math.max(from.method_10264(), to.method_10264()), Math.max(from.method_10260(), to.method_10260()));

        for (int x = min.method_10263(); x <= max.method_10263(); x++)
            for (int y = min.method_10264(); y <= max.method_10264(); y++)
                for (int z = min.method_10260(); z <= max.method_10260(); z++)
                    blocks.add(new class_2338(x, y, z));

        return blocks;
    }

    public static ArrayList<class_2338> getAllInBox(class_2338 center, int range)
    {
        return getAllInBox(center.method_10069(-range, -range, -range),
                center.method_10069(range, range, range));
    }

    public static Stream<class_2338> getAllInBoxStream(class_2338 from, class_2338 to)
    {
        class_2338 min = new class_2338(Math.min(from.method_10263(), to.method_10263()),
                Math.min(from.method_10264(), to.method_10264()), Math.min(from.method_10260(), to.method_10260()));
        class_2338 max = new class_2338(Math.max(from.method_10263(), to.method_10263()),
                Math.max(from.method_10264(), to.method_10264()), Math.max(from.method_10260(), to.method_10260()));

        Stream<class_2338> stream = Stream.<class_2338>iterate(min, pos -> {
            int x = pos.method_10263();
            int y = pos.method_10264();
            int z = pos.method_10260();

            x++;

            if (x > max.method_10263())
            {
                x = min.method_10263();
                y++;
            }

            if (y > max.method_10264())
            {
                y = min.method_10264();
                z++;
            }

            if (z > max.method_10260())
                throw new IllegalStateException("Stream limit exceeded.");

            return new class_2338(x, y, z);
        });

        int limit = (max.method_10263() - min.method_10263() + 1)
                * (max.method_10264() - min.method_10264() + 1)
                * (max.method_10260() - min.method_10260() + 1);

        return stream.limit(limit);
    }

    public static Stream<class_2338> getAllInBoxStream(class_2338 center, int range)
    {
        return getAllInBoxStream(center.method_10069(-range, -range, -range),
                center.method_10069(range, range, range));
    }
}
