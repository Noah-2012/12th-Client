package com.noadsch12.util;

import java.util.List;
import net.minecraft.class_243;

public interface TrailAccessor {
    List<class_243> arrowtrail$getTrailPoints();
}