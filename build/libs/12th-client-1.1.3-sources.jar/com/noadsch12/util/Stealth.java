/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.util;

import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class Stealth {
    private static boolean enabled = false;
    // Flag to tell our Mixin to let this packet through
    public static boolean isSendingStealthPacket = false;

    private static class_243 lastPos = class_243.field_1353;
    private static float lastYaw = 0;
    private static float lastPitch = 0;
    private static boolean lastOnGround = true;
    private static boolean lastHorizontalCollision = false;

    public static boolean isEnabled() {
        return enabled;
    }

    public static void setEnabled(boolean state) {
        class_310 client = class_310.method_1551();
        if (state && !enabled && client.field_1724 != null) {
            captureState(client.field_1724);
        } else if (!state && enabled && client.field_1724 != null) {
            captureState(client.field_1724);
        }
        enabled = state;
    }

    private static void captureState(class_746 player) {
        lastPos = player.method_73189();
        lastYaw = player.method_36454();
        lastPitch = player.method_36455();
        lastOnGround = player.method_24828();
        lastHorizontalCollision = false;
    }

    public static void onTick(class_310 client) {
        if (enabled && client.method_1562() != null && client.field_1724 != null) {
            isSendingStealthPacket = true;

            // Matching the 7-argument constructor found in your source for Full:
            // Full(double x, double y, double z, float yaw, float pitch, boolean onGround, boolean horizontalCollision)
            class_2828 packet = new class_2828.class_2830(
                    lastPos.field_1352,
                    lastPos.field_1351,
                    lastPos.field_1350,
                    lastYaw,
                    lastPitch,
                    lastOnGround,
                    lastHorizontalCollision
            );

            client.method_1562().method_52787(packet);

            isSendingStealthPacket = false;
        }
    }
}