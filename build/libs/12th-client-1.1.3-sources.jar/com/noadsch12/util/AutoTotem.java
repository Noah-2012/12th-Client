package com.noadsch12.util;

import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class AutoTotem {

    public static void tick() {
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;

        if (player == null || mc.field_1761 == null) return;

        // Slot 45 is the Offhand (Shield) slot
        class_1799 offhandStack = player.method_6079();

        // If we already have a totem in the offhand, do nothing
        if (offhandStack.method_7909() == class_1802.field_8288) return;

        // Find a totem in the main inventory
        int totemSlot = findTotemSlot(player.method_31548());

        if (totemSlot != -1) {
            // Inventory slots in ScreenHandler are numbered differently than PlayerInventory
            // For the main player inventory, slot 0-8 are Hotbar, 9-35 are Main.
            // In the PlayerScreenHandler, slot 45 is offhand.

            int syncId = player.field_7498.field_7763;

            // Step 1: Click the totem slot to "pick it up" (put it on the cursor)
            mc.field_1761.method_2906(syncId, totemSlot, 0, class_1713.field_7790, player);

            // Step 2: Click the offhand slot (45) to "place it"
            mc.field_1761.method_2906(syncId, 45, 0, class_1713.field_7790, player);

            // Step 3: If we had something in the offhand before, it's now on the cursor.
            // Put it back into the old totem slot.
            mc.field_1761.method_2906(syncId, totemSlot, 0, class_1713.field_7790, player);
        }
    }

    private static int findTotemSlot(class_1661 inventory) {
        // We check the main inventory (0-35)
        for (int i = 0; i < 36; i++) {
            if (inventory.method_5438(i).method_7909() == class_1802.field_8288) {
                // Map inventory index to ScreenHandler slot index
                // Minecraft's ScreenHandler inventory slots start at 9 (after armor/crafting)
                if (i < 9) {
                    return i + 36; // Hotbar slots are 36-44 in the handler
                }
                return i; // Main inventory slots 9-35 match
            }
        }
        return -1;
    }
}