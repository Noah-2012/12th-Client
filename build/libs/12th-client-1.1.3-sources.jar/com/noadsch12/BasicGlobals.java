package com.noadsch12;

import net.minecraft.class_310;

public class BasicGlobals {
    public static int SPACEBETWEENBUTTONS = 4; // in Pixels
    public static int MENUBUTTONSIZE = 200; // in Pixels
    public static final String CLIENT_VERSION = "1.1.3";

    private static class_310 mc;

    public static int getButtonMiddleX(int ScreenW, int ButtonW) {
        return (ScreenW / 2) - (ButtonW / 2);
    }

    public int getMaxFps(class_310 mc) {
        return mc.field_1690.method_42524().method_41753();
    }
}
