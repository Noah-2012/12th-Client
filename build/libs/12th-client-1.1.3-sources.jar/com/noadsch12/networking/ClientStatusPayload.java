/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.networking;

import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ClientStatusPayload(UUID playerUuid) implements class_8710 {
    public static final class_9154<ClientStatusPayload> ID = new class_9154<>(class_2960.method_60655("12th-client", "client_status"));
    public static final class_9139<class_9129, ClientStatusPayload> CODEC = class_9139.method_56434(
            class_4844.field_48453, ClientStatusPayload::playerUuid, ClientStatusPayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() { return ID; }
}