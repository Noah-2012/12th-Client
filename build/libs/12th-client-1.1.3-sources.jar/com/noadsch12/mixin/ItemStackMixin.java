/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.look.ItemHexManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

@Mixin(class_1799.class)
public class ItemStackMixin {
        @Inject(method = "getTooltip", at = @At("RETURN"), cancellable = true)
        private void addHexToTooltip(class_1792.class_9635 context, class_1657 player, class_1836 type, CallbackInfoReturnable<List<class_2561>> cir) {
            // 2. Create a MUTABLE copy of the original list
            List<class_2561> tooltip = new java.util.ArrayList<>(cir.getReturnValue());

            class_1799 stack = (class_1799) (Object) this;
            String hex = ItemHexManager.getHexForItem(stack.method_7909());

            // 3. Add your text to the copy (using index 1 to put it under the name)
            // Make sure the list isn't empty before using index 1
            if (tooltip.size() >= 1) {
                tooltip.add(1, class_2561.method_43470("§8[#" + hex + "]"));
            } else {
                tooltip.add(class_2561.method_43470("§8[#" + hex + "]"));
            }

            // 4. Override the return value with our modified list
            cir.setReturnValue(tooltip);
        }
}