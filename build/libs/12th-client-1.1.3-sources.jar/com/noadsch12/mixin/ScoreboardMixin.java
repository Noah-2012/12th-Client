/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.modules.ModuleManager;
import com.noadsch12.ui.screens.ClientSettingsScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collection;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9011;

@Mixin(class_329.class)
public class ScoreboardMixin {

    @Inject(
            method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void customScoreboardRender(class_332 context, class_266 objective, CallbackInfo ci) {
        if (!ModuleManager.getInstance().getModule("Better Scoreboard").isEnabled()) return;
        // Cancel vanilla immediately so its "inner squares" never render
        ci.cancel();

        class_310 client = class_310.method_1551();
        class_327 textRenderer = client.field_1772;
        class_269 scoreboard = client.field_1687.method_8428();

        // 1. Get entries using your confirmed method
        //Collection<ScoreboardEntry> collection = scoreboard.getScoreboardEntries(objective);
        Collection<class_9011> collection = scoreboard.method_1184(objective);
        List<class_9011> list = collection.stream()
                .filter(entry -> entry.comp_2127() != null && !entry.comp_2127().startsWith("#"))
                .sorted((e1, e2) -> Integer.compare(e2.comp_2128(), e1.comp_2128())) // Sort by score descending
                .limit(15)
                .toList();

        if (list.isEmpty()) return;

        // 2. Pre-calculate Names and Widths
        class_2561 title = objective.method_1114();
        int titleWidth = textRenderer.method_27525(title);
        int maxWidth = titleWidth;

        for (class_9011 entry : list) {
            class_2561 nameText = resolveName(scoreboard, entry, objective);
            int nameWidth = textRenderer.method_27525(nameText);
            int scoreWidth = textRenderer.method_1727(Integer.toString(entry.comp_2128()));
            // Width = Name + Space + Score
            maxWidth = Math.max(maxWidth, nameWidth + scoreWidth + 15);
        }

        int rowCount = list.size();
        int rowHeight = 9;
        int padding = 3;
        int totalHeight = (rowCount + 1) * (rowHeight + 2) + padding * 2;
        int width = maxWidth + 10;

        int x2 = context.method_51421() - 4;
        int x1 = x2 - width;
        int y1 = (context.method_51443() / 2) - (totalHeight / 2);
        int y2 = y1 + totalHeight;

        // 3. Draw Background (Using your Matrix methods)
        int r = 8;
        int bgColor = 0x50000000;

        context.method_51448().pushMatrix();
        context.translate(0, 0);

        // Alpha-Safe Background (No Overlaps)
        // Center Body
        context.method_25294(x1, y1 + r, x2, y2 - r, bgColor);
        // Top cap
        context.method_25294(x1 + r, y1, x2 - r, y1 + r, bgColor);
        // Bottom cap
        context.method_25294(x1 + r, y2 - r, x2 - r, y2, bgColor);

        // Corners
        drawCorner(context, x1 + r, y1 + r, r, bgColor, 180);
        drawCorner(context, x2 - r, y1 + r, r, bgColor, 270);
        drawCorner(context, x1 + r, y2 - r, r, bgColor, 90);
        drawCorner(context, x2 - r, y2 - r, r, bgColor, 0);

        context.method_51448().popMatrix();

        // 4. Render Text
        int currentY = y1 + padding;

        // Render Title
        context.method_51439(textRenderer, title, x1 + (width / 2) - (titleWidth / 2), currentY, 0xFFFFFFFF, false);

        currentY += rowHeight + 2;

        for (class_9011 entry : list) {
            class_2561 resolvedName = resolveName(scoreboard, entry, objective);
            String scoreValue = Integer.toString(entry.comp_2128());

            // DRAW NAME with shadow for better visibility
            context.method_27535(textRenderer, resolvedName, x1 + 5, currentY, 0xFFFFFFFF);

            // DRAW SCORE (Right Aligned)
            int scoreWidth = textRenderer.method_1727(scoreValue);
            context.method_25303(textRenderer, scoreValue, x2 - scoreWidth - 5, currentY, 0xFFFF5555);

            currentY += rowHeight + 2;
        }
    }

    @Unique
    private class_2561 resolveName(class_269 scoreboard, class_9011 entry, class_266 objective) {
        String owner = entry.comp_2127();

        // First try display text
        class_2561 displayText = entry.comp_2129();
        if (displayText != null && !displayText.getString().isEmpty() && !displayText.getString().equals("§")) {
            return displayText;
        }

        // Find the team that has this owner as a player (not the team with owner as the name)
        class_268 team = scoreboard.method_1164(owner);

        // If there's a team, decorate the owner name with team formatting
        if (team != null) {
            class_2561 ownerText = class_2561.method_43470(owner);
            class_2561 decorated = class_268.method_1142(team, ownerText);
            return decorated;
        }

        // Then try the entry name
        class_2561 nameText = entry.method_55387();
        if (!nameText.getString().equals("§") && !nameText.getString().isEmpty()) {
            return nameText;
        }

        // Fallback: use owner text
        return class_2561.method_43470(owner);
    }

    @Unique
    private void drawCorner(class_332 context, int cx, int cy, int r, int color, int angle) {
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < r; j++) {
                if (Math.sqrt(i * i + j * j) <= r) {
                    int x = (angle == 180 || angle == 90) ? cx - i - 1 : cx + i;
                    int y = (angle == 180 || angle == 270) ? cy - j - 1 : cy + j;
                    context.method_25294(x, y, x + 1, y + 1, color);
                }
            }
        }
    }
}