/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.modules.ModuleManager;
import com.noadsch12.ui.screens.ClientSettingsScreen;
import net.minecraft.class_4002;
import net.minecraft.class_638;
import net.minecraft.class_691;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_691.class)
public class ExplosionLargeParticleMixin {

    @Inject(method = "<init>", at = @At("RETURN"))
    private void onInit(
            class_638 world, double x, double y, double z, double velocityX, class_4002 spriteProvider, CallbackInfo ci
    ) {
        if (ModuleManager.getInstance().getModule("Hide Explosion Particles").isEnabled()) {
            ((class_691) (Object) this).method_3085();
        }
    }
}
