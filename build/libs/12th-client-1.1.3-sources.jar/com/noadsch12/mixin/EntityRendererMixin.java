package com.noadsch12.mixin;

import com.noadsch12.render.EntityCulling;
import net.minecraft.class_1297;
import net.minecraft.class_4604;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_897.class)
public class EntityRendererMixin<T extends class_1297> {

    /**
     * Injected into the `shouldRender` method of `EntityRenderer`
     * This method determines whether an entity should be rendered at all.
     */
    @Inject(
            method = "shouldRender",
            at = @At("HEAD"),
            cancellable = true
    )
    private void applyCulling(T entity, class_4604 frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        if (!EntityCulling.shouldRender(entity, frustum)) {
            cir.setReturnValue(false);
        }
    }
}