/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.function.Supplier;
import net.minecraft.class_128;

@Mixin(net.minecraft.class_310.class)
public interface MinecraftClientAccessor {

    @Accessor("crashReportSupplier")
    Supplier<class_128> getCrashReportSupplier();

    @Accessor("crashReportSupplier")
    void setCrashReportSupplier(Supplier<class_128> supplier);
}
