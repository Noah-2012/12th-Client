/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.BasicGlobals;
import com.noadsch12.networking.ClientUserManager;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11659;
import net.minecraft.class_11719;
import net.minecraft.class_12075;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public abstract class PlayerEntityRendererMixin {

    @Unique
    private final class_2583 font
            = class_2583.field_24360.method_27704(new class_11719.class_11721(BasicGlobals.GOTHIC_FONT));

    @Inject(method = "renderLabelIfPresent", at = @At("HEAD"))
    private void modifyNametagWithArial(class_10055 state, class_4587 matrices, class_11659 queue, class_12075 cameraRenderState, CallbackInfo ci) {

        if (state.field_53337 != null && !state.field_53337.getString().startsWith("12C ") && isClientUser(state)) {

            class_2561 prefix = class_2561.method_43470("12C ")
                    .method_10862(class_2583.field_24360
                            .method_27704(font.method_27708())
                            .method_10977(class_124.field_1068));

            state.field_53337 = class_2561.method_43473()
                    .method_10852(prefix)
                    .method_10852(state.field_53337);
        }
    }

    @Unique
    private boolean isClientUser(class_10055 state) {
        class_310 client = class_310.method_1551();

        if (client.field_1724 != null && state.field_53528 == client.field_1724.method_5628()) {
            return true;
        }

        if (state.field_53337 != null) {
            String name = state.field_53337.getString();
            return ClientUserManager.USERS_NAMES.contains(name);
        }

        return false;
    }
}