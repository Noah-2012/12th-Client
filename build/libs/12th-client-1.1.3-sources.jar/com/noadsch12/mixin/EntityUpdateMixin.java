/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.networking.ClientUserManager;
import net.minecraft.class_10017;
import net.minecraft.class_10055;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_897.class)
public abstract class EntityUpdateMixin<T extends class_1297, S extends class_10017> {

    @Inject(method = "updateRenderState", at = @At("RETURN"))
    private void captureUuid(T entity, S state, float tickProgress, CallbackInfo ci) {
        if (entity instanceof class_1657 player && state instanceof class_10055) {
            // If the player is a client user, we store their NAME in a set
            // so the other Mixin can find it via state.displayName
            if (ClientUserManager.USERS.contains(player.method_5667())) {
                ClientUserManager.USERS_NAMES.add(player.method_5477().getString());
            }
        }
    }
}