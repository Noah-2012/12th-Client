/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import net.minecraft.class_1007;
import net.minecraft.class_11890;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1007.class)
public class PlayerNametagMixin {

    @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true)
    private void showLocalPlayerLabel(class_11890 playerLikeEntity, double d, CallbackInfoReturnable<Boolean> cir) {
        class_310 client = class_310.method_1551();

        // Check if the entity being rendered is the local player
        if (playerLikeEntity == client.field_1724) {
            // Only show if we are in third person (F5)
            if (!client.field_1690.method_31044().method_31034()) {
                cir.setReturnValue(true);
            }
        }
    }
}