/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;


import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_759;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
@Mixin(class_759.class)
public class HeldItemRendererMixin {
    @Shadow @Final
    private class_1799 mainHand;
    @Shadow @Final private class_1799 offHand;

    @Shadow
    protected void renderMapInBothHands(class_4587 matrices, class_11659 orderedRenderCommandQueue, int light, float pitch, float equipProgress, float swingProgress) {

    }

    @Shadow
    protected void renderMapInOneHand(class_4587 matrices, class_11659 orderedRenderCommandQueue, int light, float equipProgress, class_1306 arm, float swingProgress, class_1799 stack) {}

    @Shadow
    protected void renderArmHoldingItem(class_4587 matrices, class_11659 queue, int light, float equipProgress, float swingProgress, class_1306 arm) {

    }

    @Shadow
    protected void applyEatOrDrinkTransformation(class_4587 matrices, float tickProgress, class_1306 arm, class_1799 stack, net.minecraft.class_1657 player) {

    }

    @Shadow
    protected void applyEquipOffset(class_4587 matrices, class_1306 arm, float equipProgress) {

    }

    @Shadow
    public void renderItem(net.minecraft.class_1309 entity, class_1799 stack, net.minecraft.class_811 renderMode, class_4587 matrices, class_11659 orderedRenderCommandQueue, int light) {

    }

    /**
     * @author Noadsch12
     * @reason Overwriting to implement spear-style thrusting and custom positioning.
     */
    @Overwrite
    private void renderFirstPersonItem(
            class_742 player,
            float tickProgress,
            float pitch,
            class_1268 hand,
            float swingProgress,
            class_1799 item,
            float equipProgress,
            class_4587 matrices,
            class_11659 orderedRenderCommandQueue,
            int light
    ) {
        if (player.method_31550()) return;

        boolean isMainHand = hand == class_1268.field_5808;
        class_1306 arm = isMainHand ? player.method_6068() : player.method_6068().method_5928();
        matrices.method_22903();

        if (item.method_7960()) {
            if (isMainHand && !player.method_5767()) {
                this.renderArmHoldingItem(matrices, orderedRenderCommandQueue, light, equipProgress, swingProgress, arm);
            }
        } else if (item.method_57826(class_9334.field_49646)) {
            if (isMainHand && this.offHand.method_7960()) {
                this.renderMapInBothHands(matrices, orderedRenderCommandQueue, light, pitch, equipProgress, swingProgress);
            } else {
                this.renderMapInOneHand(matrices, orderedRenderCommandQueue, light, equipProgress, arm, swingProgress, item);
            }
        } else {
            boolean isRightArm = arm == class_1306.field_6183;

            if (player.method_6115() && player.method_6014() > 0 && player.method_6058() == hand) {
                this.applyEatOrDrinkTransformation(matrices, tickProgress, arm, item, player);
                this.applyEquipOffset(matrices, arm, equipProgress);
            } else {
                // 1. Still apply equip offset so the item slides up/down when switching
                this.applyEquipOffset(matrices, arm, equipProgress);

                // 2. THE ANIMATION ONLY
                // Calculate the thrusting motion (sine wave)
                float thrust = class_3532.method_15374(swingProgress * (float)Math.PI);

                // 3. Apply ONLY the forward movement
                // This will add to the Z-position handled by your other Mixin
                matrices.method_46416(0.0f, 0.0f, -(thrust * 0.7f));

                // Optional: A tiny bit of rotation during the hit to make it feel "impactful"
                // matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(thrust * -5.0f));
            }

            this.renderItem(
                    player,
                    item,
                    isRightArm ? net.minecraft.class_811.field_4322 : net.minecraft.class_811.field_4321,
                    matrices,
                    orderedRenderCommandQueue,
                    light
            );
        }

        matrices.method_22909();
    }
}
