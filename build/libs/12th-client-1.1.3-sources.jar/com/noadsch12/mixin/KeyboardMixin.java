package com.noadsch12.mixin;

import com.noadsch12.render.DebugAnimation;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public class KeyboardMixin {
    @Inject(method = "onKey", at = @At("HEAD"), cancellable = true)
    private void onKey(long window, int action, class_11908 input, CallbackInfo ci) {
        if (input.comp_4795() == 292 && action == 1) { // F3 Pressed
            // If it's the FIRST time ever pressing F3, don't redirect yet
            if (!DebugAnimation.hasBeenActivated) {
                DebugAnimation.hasBeenActivated = true;
                DebugAnimation.isF3Visible = true;
                // Allow vanilla to handle it this one time to spawn the HUD
                return;
            }

            // After the first time, we take full control
            DebugAnimation.isF3Visible = !DebugAnimation.isF3Visible;
            ci.cancel();
        }
    }
}

