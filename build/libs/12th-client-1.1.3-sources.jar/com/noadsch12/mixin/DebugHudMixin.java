/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.render.ui.DebugAnimation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_340;

@Mixin(class_340.class)
public abstract class DebugHudMixin {
    @Inject(method = "shouldShowDebugHud", at = @At("HEAD"), cancellable = true)
    public void forceVisibility(CallbackInfoReturnable<Boolean> cir) {
        if (DebugAnimation.hasBeenActivated && DebugAnimation.shouldActuallyRender()) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "render", at = @At("HEAD"))
    public void onRenderStart(class_332 context, CallbackInfo ci) {
        float p = DebugAnimation.getEasedProgress();
        float offset = -500f * (1.0f - p);

        context.method_51448().pushMatrix();
        context.method_51448().translate(0, offset);
    }

    @Inject(method = "render", at = @At("RETURN"))
    public void onRenderEnd(class_332 context, CallbackInfo ci) {
        context.method_51448().popMatrix();
    }

    @ModifyVariable(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/List;size()I"
            ),
            ordinal = 1
    )
    private List<String> injectRightDebugText(List<String> list) {
        if (list.stream().noneMatch(s -> s.contains("12th Client"))) {
            list.add("§b12th Client v1.1.3 by Noadsch12§r");
            list.add("The 12th Client stands under GNU 3.0 License");
        }
        return list;
    }
}



