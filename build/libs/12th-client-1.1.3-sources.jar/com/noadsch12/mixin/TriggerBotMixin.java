/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.modules.ModuleManager;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// Replace with the actual package where your settings are stored
import com.noadsch12.ui.screens.ClientSettingsScreen;
import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_437;
import net.minecraft.class_746;

@Mixin(class_310.class)
public abstract class TriggerBotMixin {

    @Shadow @Nullable public class_239 crosshairTarget;
    @Shadow @Nullable public class_437 currentScreen;
    @Shadow protected abstract boolean doAttack();

    @Shadow
    @Nullable
    public class_746 player;
    @Unique
    private static class_310 client;

    @Inject(method = "tick", at = @At("TAIL"))
    private void onTick(CallbackInfo ci) {
        // 1. Check if the feature is enabled
        // 2. Ensure no menu is open
        // 3. Ensure the crosshair is actually over an Entity
        if (ModuleManager.getInstance().getModule("Trigger Bot").isEnabled()
                && this.currentScreen == null
                && this.crosshairTarget != null
                && this.crosshairTarget.method_17783() == class_239.class_240.field_1331) {

            class_1297 target = ((class_3966)this.crosshairTarget).method_17782();

            // We can further verify it's an EntityHitResult to be safe
            if (this.crosshairTarget instanceof class_3966 && target != this.player) {
                this.doAttack();
            }
        }
    }
}