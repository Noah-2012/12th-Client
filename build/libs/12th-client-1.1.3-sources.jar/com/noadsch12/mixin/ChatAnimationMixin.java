/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.modules.ModuleManager;
import com.noadsch12.modules.impl.misc.BetterChatModule;
import com.noadsch12.ui.screens.ClientSettingsScreen;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.FileNotFoundException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_1659;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_303;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_338;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.CompletableFuture;

@Mixin(class_338.class)
public abstract class ChatAnimationMixin {

    @Shadow private class_310 client;
    @Shadow @Final private List<class_303.class_7590> visibleMessages;
    @Shadow public abstract int getWidth();
    @Shadow public abstract double getChatScale();

    @Unique
    private boolean popped = false;

    @Unique
    private final Map<String, class_2960> skinCache = new HashMap<>();
    @Unique
    private final Set<String> loadingSkins = new HashSet<>();
    @Unique
    private final Set<String> failedSkins = Collections.synchronizedSet(new HashSet<>());

    @Unique
    private long lastMessageTime = 0;

    @Unique
    private static final Pattern PLAYER_NAME_PATTERN_SERVER1 = Pattern.compile("^\\s*([^:]+):");

    @Unique
    private static final Pattern PLAYER_NAME_PATTERN_VANILLA = Pattern.compile("^\\s*<([^>]+)>\\s");

    @Unique
    private static final int HEAD_SIZE = 8;

    @Inject(method = "addVisibleMessage", at = @At("TAIL"))
    private void onAddMessage(class_303 line, CallbackInfo ci) {
        if (!ModuleManager.getInstance().getModule("Better Chat").isEnabled()) return;
        if (!BetterChatModule.showAnimations) return;

        this.lastMessageTime = System.currentTimeMillis();
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void startAnimation(class_332 context, int currentTick, int mouseX, int mouseY, boolean focused, CallbackInfo ci) {
        if (!ModuleManager.getInstance().getModule("Better Chat").isEnabled()) return;
        if (!BetterChatModule.showAnimations) return;

        context.method_51448().pushMatrix();
        popped = true;

        if (!visibleMessages.isEmpty()) {
            long delta = System.currentTimeMillis() - lastMessageTime;
            long duration = 300;

            if (delta < duration) {
                float progress = (float) delta / duration;
                float ease = 1.0f - (float) Math.pow(1.0 - progress, 4);
                float yOffset = 12.0f * (1.0f - ease);
                context.method_51448().translate(0.0f, yOffset);
            }
        }
    }

    @ModifyVariable(
            method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
            at = @At("HEAD"),
            argsOnly = true
    )
    private class_2561 addSpaceBeforeMessage(class_2561 text) {
        if (!ModuleManager.getInstance().getModule("Better Chat").isEnabled()) return text;
        if (!BetterChatModule.showPlayerHeads) return text;

        return class_2561.method_43470("  ").method_10852(text);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void renderPlayerHeads(class_332 context, int currentTick, int mouseX, int mouseY, boolean focused, CallbackInfo ci) {
        if (!ModuleManager.getInstance().getModule("Better Chat").isEnabled()) return;
        if (!BetterChatModule.showPlayerHeads) return;
        if (visibleMessages.isEmpty() || client.field_1690.method_42539().method_41753() == class_1659.field_7536) return;

        int chatWidth = (int) (this.getWidth());
        int chatHeight = (int) (focused ? client.field_1705.method_1743().method_1810()
                : client.field_1705.method_1743().method_1810() * client.field_1690.method_41801().method_41753());

        int windowHeight = context.method_51443();
        int chatX = 2;
        int chatY = windowHeight - 40;

        if (focused) {
            context.method_44379(0, windowHeight - 40 - chatHeight, chatWidth + 20, windowHeight - 40);
        } else {
            context.method_44379(0, windowHeight - 90 - chatHeight, chatWidth + 20, windowHeight - 40);
        }

        for (int i = 0; i < visibleMessages.size(); i++) {
            class_303.class_7590 line = visibleMessages.get(i);
            if (line == null) continue;

            int opacity = getMessageOpacity(line, currentTick);
            if (opacity <= 5) continue;

            int lineY = chatY - (i * 9) - 9;

            StringBuilder sb = new StringBuilder();
            line.comp_896().accept((index, style, codePoint) -> {
                sb.append(Character.toChars(codePoint));
                return true;
            });

            String playerName = extractPlayerName(sb.toString());

            if (playerName != null) {
                class_2960 skinTexture = getPlayerSkinTexture(playerName);
                if (skinTexture != null) {
                    int color = (opacity << 24) | 0xFFFFFF;

                    context.method_25293(class_10799.field_56883, skinTexture,
                            chatX, lineY,
                            8, 8,
                            8, 8,
                            64, 64,
                            64, 64,
                            color);
                }
            }
        }

        context.method_44380();
    }

    @Unique
    private int getMessageOpacity(class_303.class_7590 line, int currentTick) {
        int age = currentTick - line.comp_895();
        if (age < 200) return 255;
        int opacity = 255 - (age - 200) * 255 / 40;
        return Math.max(0, Math.min(255, opacity));
    }

    @Unique
    private String extractPlayerName(String message) {
        Matcher matcher1 = PLAYER_NAME_PATTERN_SERVER1.matcher(message);
        Matcher matcher2 = PLAYER_NAME_PATTERN_VANILLA.matcher(message);
        if (matcher1.find()) return matcher1.group(1);
        if (matcher2.find()) return matcher2.group(1);
        return null;
    }

    private class_2960 getPlayerSkinTexture(String playerName) {
        if (playerName == null || playerName.isEmpty()) return null;

        if (skinCache.containsKey(playerName)) {
            return skinCache.get(playerName);
        }

        if (failedSkins.contains(playerName)) {
            return null;
        }

        if (loadingSkins.contains(playerName)) {
            return null;
        }

        loadingSkins.add(playerName);

        CompletableFuture.runAsync(() -> {
            try {
                String cleanName = playerName.replaceAll("[^a-zA-Z0-9_]", "");

                if (cleanName.isEmpty()) {
                    throw new FileNotFoundException("Ungültiger Name nach Bereinigung");
                }

                URL url = new URL("https://minotar.net/avatar/" + cleanName + "/64.png");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestProperty("User-Agent", "Minecraft-Client-Mod");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.connect();

                int responseCode = connection.getResponseCode();
                if (responseCode != 200) {
                    throw new FileNotFoundException("Server antwortete mit Code: " + responseCode);
                }

                try (InputStream is = connection.getInputStream()) {
                    class_1011 image = class_1011.method_4309(is);

                    client.execute(() -> {
                        try {
                            class_1043 texture = new class_1043(
                                    () -> "skin_texture_" + playerName.toLowerCase(Locale.ROOT),
                                    image
                            );

                            class_2960 id = class_2960.method_60655("twelfth-chat", "skins/" + playerName.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_]", ""));
                            client.method_1531().method_4616(id, texture);

                            skinCache.put(playerName, id);
                        } catch (Exception e) {
                            failedSkins.add(playerName);
                        } finally {
                            loadingSkins.remove(playerName);
                        }
                    });
                }
            } catch (Exception e) {
                failedSkins.add(playerName);
                loadingSkins.remove(playerName);
                if (!(e instanceof FileNotFoundException)) {

                }
            }
        });

        return null;
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void endAnimation(class_332 context, int currentTick, int mouseX, int mouseY, boolean focused, CallbackInfo ci) {
        if (!BetterChatModule.showAnimations) return;

        if (popped) {
            context.method_51448().popMatrix();
            popped = false;
        }
    }
}