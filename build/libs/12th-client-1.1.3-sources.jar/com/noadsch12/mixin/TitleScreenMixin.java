/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.ui.screens.ClientSettingsScreen;
import com.noadsch12.ui.screens.ClientInfoScreen;
import com.noadsch12.ui.widgets.AnimatedButtonWidget;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import static com.noadsch12.BasicGlobals.getButtonMiddleX;

@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {

    @Unique
    private static final class_2960 CLIENT_LOGO = class_2960.method_60655("12th-client", "logo2.png");

    @Unique
    private int logoX1, logoY1, logoX2, logoY2;
    @Unique
    private int textX1, textY1, textWidth1, textHeight1;

    protected TitleScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void addButton(CallbackInfo ci) {
        class_442 titleScreen = (class_442) (Object) this;

        int screenWidth = titleScreen.field_22789;
        int screenHeight = titleScreen.field_22790;

        int buttonX = getButtonMiddleX(screenWidth, 200);
        int buttonY = screenHeight / 4 + 48 - 24;

        AnimatedButtonWidget clientButton = new AnimatedButtonWidget(
                buttonX,
                buttonY,
                200,
                20,
                class_2561.method_43470("12th Client"),
                btn -> onButtonPress(titleScreen),
                "12th Client"
        );

        titleScreen.method_37063(clientButton);
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void renderClientBrand(class_332 drawContext, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        class_327 textRenderer = client.field_1772;

        String msg1 = "12th Client";
        String msg2 = "by Noadsch12";

        String crd_msg1 = "Credits to";
        String crd_msg2 = "SniperShot";
        String crd_msg3 = "for promoting";

        int screenWidth = drawContext.method_51421();

        // Logo-Dimensionen
        int logoWidth = 128;
        int logoHeight = 128;
        int logoPadding = 5;

        logoX1 = screenWidth - logoWidth - logoPadding;
        logoY1 = 27;
        logoX2 = logoX1 + logoWidth;
        logoY2 = logoY1 + logoHeight;

        // Check if mouse is hovering over logo
        boolean isHoveringLogo = mouseX >= logoX1 && mouseX <= logoX2 && mouseY >= logoY1 && mouseY <= logoY2;

        // Draw glow effect when hovering
        if (isHoveringLogo) {
            //drawContext.fillGradient(logoX1 - 2, logoY1 - 2, logoX2 + 2, logoY2 + 2, 0xFF000000, 0xFF808080);
            drawContext.method_25294(logoX1 + 5, logoY1 + 5, logoX2 - 5, logoY2 - 5, 0x43808080);
        }

        drawContext.method_70845(
                CLIENT_LOGO,
                logoX1,
                logoY1,
                logoX2,
                logoY2,
                0.0f,
                1.0f,
                0.0f,
                1.0f
        );

        int x1 = screenWidth - textRenderer.method_1727(msg1) - 80;
        int y1 = 5;

        // Store text bounds for click detection
        textX1 = x1;
        textY1 = y1;
        textWidth1 = textRenderer.method_1727(msg1);
        textHeight1 = textRenderer.field_2000;

        // Check if mouse is hovering over text
        boolean isHoveringText = mouseX >= textX1 && mouseX <= textX1 + textWidth1 &&
                mouseY >= textY1 && mouseY <= textY1 + textHeight1;

        int x2 = screenWidth - textRenderer.method_1727(msg2) - 6;
        int y2 = 5;

        int x3 = screenWidth - textRenderer.method_1727(crd_msg1) - 135;
        int y3 = 15;

        int x4 = screenWidth - textRenderer.method_1727(crd_msg2) - 78;
        int y4 = 15;

        int x5 = screenWidth - textRenderer.method_1727(crd_msg3) - 6;
        int y5 = 15;

        // Change color when hovering
        int textColor = isHoveringText ? 0xFF00FFAA : 0xFF00FFFF;

        drawContext.method_25303(
                textRenderer,
                msg1,
                x1,
                y1,
                textColor
        );

        // Underline when hovering
        if (isHoveringText) {
            drawContext.method_25294(x1, y1 + textHeight1, x1 + textWidth1, y1 + textHeight1 + 1, 0xFF00FFFF);
        }

        drawContext.method_25303(
                textRenderer,
                msg2,
                x2,
                y2,
                0xFFFFFFFF
        );

        drawContext.method_25303(
                textRenderer,
                crd_msg1,
                x3,
                y3,
                0xFFFFFFFF
        );

        drawContext.method_51433(
                textRenderer,
                crd_msg2,
                x4,
                y4,
                0xFF00008B,
                false
        );

        drawContext.method_25303(
                textRenderer,
                crd_msg3,
                x5,
                y5,
                0xFFFFFFFF
        );
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void onMouseClicked(class_11909 click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int button = click.method_74245();

        if (button == 0) { // Left click
            // Check if clicked on logo
            if (mouseX >= logoX1 && mouseX <= logoX2 && mouseY >= logoY1 && mouseY <= logoY2) {
                class_442 titleScreen = (class_442) (Object) this;
                class_310.method_1551().method_1507(new ClientInfoScreen(titleScreen));
                cir.setReturnValue(true);
                return;
            }

            // Check if clicked on text
            if (mouseX >= textX1 && mouseX <= textX1 + textWidth1 &&
                    mouseY >= textY1 && mouseY <= textY1 + textHeight1) {
                class_442 titleScreen = (class_442) (Object) this;
                class_310.method_1551().method_1507(new ClientInfoScreen(titleScreen));
                cir.setReturnValue(true);
            }
        }
    }

    private void onButtonPress(class_442 titleScreen) {
        class_310.method_1551().method_1507(new ClientSettingsScreen(titleScreen));
    }
}