package com.noadsch12.mixin;

import com.noadsch12.ui.ClientSettingsScreen;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_442;
import com.noadsch12.ui.AnimatedButtonWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static com.noadsch12.BasicGlobals.getButtonMiddleX;

@Mixin(class_442.class)
public abstract class TitleScreenMixin {
    @Inject(method = "init", at = @At("TAIL"))
    private void addButton(CallbackInfo ci) {
        class_442 titleScreen = (class_442) (Object) this;

        int screenWidth = titleScreen.field_22789;
        int screenHeight = titleScreen.field_22790;

        int buttonX = getButtonMiddleX(screenWidth, 200); // screenWidth / 2 - 100
        int buttonY = screenHeight / 4 + 48 - 24;

        //MenuButton clientButton = new MenuButton(
        //        "12th Client",
        //        buttonX,
        //        buttonY,
        //        200,
        //        20,
        //        btn -> onButtonPress(titleScreen)
        //);

        //clientButton.addToScreen(titleScreen);

        AnimatedButtonWidget clientButton = new AnimatedButtonWidget(
                buttonX,
                buttonY,
                200,
                20,
                class_2561.method_43470("12th Client"),
                btn -> onButtonPress(titleScreen),
                "12th Client"
        );

        titleScreen.method_37063(clientButton);
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void renderClientBrand(class_332 drawContext, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        //MinecraftClient client = MinecraftClient.getInstance();
        //TextRenderer textRenderer = client.textRenderer;
        class_310 client = class_310.method_1551();
        class_327 textRenderer = client.field_1772;

        String msg1 = "12th Client";
        String msg2 = "by Noadsch12";

        int screenWidth = drawContext.method_51421();
        int x1 = screenWidth - textRenderer.method_1727(msg1) - 80;
        int y1 = 5;

        int x2 = screenWidth - textRenderer.method_1727(msg2) - 6;
        int y2 = 5;

        drawContext.method_25303(
                textRenderer,
                msg1,
                x1,
                y1,
                0xFF00FFFF
        );

        drawContext.method_25303(
                textRenderer,
                msg2,
                x2,
                y2,
                0xFFFFFFFF
        );
    }

    private void onButtonPress(class_442 titleScreen) {
        class_310.method_1551().method_1507(new ClientSettingsScreen(titleScreen));
    }
}