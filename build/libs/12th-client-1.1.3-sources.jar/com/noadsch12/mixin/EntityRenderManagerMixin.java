/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.noadsch12.modules.ModuleManager;
import com.noadsch12.render.entity.EntityESP;
import com.noadsch12.ui.screens.ClientSettingsScreen;
import net.minecraft.class_4184;
import net.minecraft.class_4599;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class EntityRenderManagerMixin {

    @Shadow @Final
    private class_4599 bufferBuilders;

    @Inject(method = "render", at = @At("RETURN"))
    private void onRenderEnd(class_9922 allocator, class_9779 tickCounter,
                             boolean renderBlockOutline, class_4184 camera,
                             Matrix4f positionMatrix, Matrix4f viewMatrix,
                             Matrix4f projectionMatrix, GpuBufferSlice fogBuffer,
                             Vector4f fogColor, boolean renderSky, CallbackInfo ci) {
        if (ModuleManager.getInstance().getModule("Entity ESP").isEnabled()) {
            EntityESP.render(camera, bufferBuilders.method_23000(), positionMatrix);
        }
    }
}