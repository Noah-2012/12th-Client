/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import net.minecraft.class_315;
import net.minecraft.class_7172;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_315.class)
public abstract class MixinGameOptions {

    @Shadow @Final
    private class_7172<Integer> menuBackgroundBlurriness;

    @Shadow @Final
    private class_7172<Double> chatLineSpacing;

    @Redirect(
        method = "<init>",
        at = @At(
            value = "NEW",
            target = "net/minecraft/client/option/SimpleOption$ValidatingIntSliderCallbacks",
            ordinal = 3
        )
    )
    private class_7172.class_7174 blur$increaseMaxBlurriness(int minInclusive, int maxInclusive) {

        if (this.menuBackgroundBlurriness == null && this.chatLineSpacing != null) {
            return new class_7172.class_7174(minInclusive, 20);
        }

        return new class_7172.class_7174(minInclusive, maxInclusive);
    }
}