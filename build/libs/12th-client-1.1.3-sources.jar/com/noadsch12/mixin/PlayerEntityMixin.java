/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

/*
 * Aoba Hacked Client
 * Copyright (C) 2019-2024 coltonk9043
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.noadsch12.mixin;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin extends LivingEntityMixin {

    @Shadow
    private class_1661 inventory;

    @Inject(method = "isSpectator()Z", at = @At("HEAD"), cancellable = true)
    public void onIsSpectator(CallbackInfoReturnable<Boolean> cir) {

    }

    @Inject(method = "getBlockBreakingSpeed", at = @At("HEAD"), cancellable = true)
    public void onGetBlockBreakingSpeed(class_2680 blockState, CallbackInfoReturnable<Float> ci) {
        // If fast break is enabled
        /*
        if (ModuleManager.getInstance().getModule("Fastbreak").isEnabled()) {
            // Multiply the break speed and override the return value.
            // float speed = inventory.getBlockBreakingSpeed(blockState);
            float speed = 5;

            ci.setReturnValue(speed);
        }

         */
    }

    @Inject(at = { @At("HEAD") }, method = "getOffGroundSpeed()F", cancellable = true)
    protected void onGetOffGroundSpeed(CallbackInfoReturnable<Float> cir) {
    }

    @Inject(at = { @At("HEAD") }, method = "getBlockInteractionRange()D", cancellable = true)
    private void onBlockInteractionRange(CallbackInfoReturnable<Double> cir) {
        /*
        if (Aoba.getInstance().moduleManager.reach.state.getValue()) {
            Reach reach = Aoba.getInstance().moduleManager.reach;
            cir.setReturnValue((double) reach.getReach());
        }

         */
    }

    @Inject(at = { @At("HEAD") }, method = "getEntityInteractionRange()D", cancellable = true)
    private void onEntityInteractionRange(CallbackInfoReturnable<Double> cir) {
        /*
        if (Aoba.getInstance().moduleManager.reach.state.getValue()) {
            Reach reach = Aoba.getInstance().moduleManager.reach;
            cir.setReturnValue((double) reach.getReach());
        }

         */
    }
}