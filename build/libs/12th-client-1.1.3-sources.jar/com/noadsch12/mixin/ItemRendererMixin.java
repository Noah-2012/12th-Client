/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.modules.impl.render.ItemRotationModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_10444;
import net.minecraft.class_1921;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_777;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_918;

@Mixin(class_918.class)
public class ItemRendererMixin {
    @Inject(method = "renderItem", at = @At("HEAD"))
    private static void onRenderItem(class_811 displayContext, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay, int[] tints, List<class_777> quads, class_1921 layer, class_10444.class_10445 glint, CallbackInfo ci) {
        if (displayContext == class_811.field_4322 ||
                displayContext == class_811.field_4321) {

            applyCustomTransformations(matrices, displayContext);
        }
    }

    @Unique
    private static void applyCustomTransformations(class_4587 matrices, class_811 displayContext) {
        matrices.method_46416(ItemRotationModule.xOffset, ItemRotationModule.yOffset, ItemRotationModule.zOffset);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(ItemRotationModule.rotation_axis_y));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(ItemRotationModule.rotation_axis_x));
    }
}
