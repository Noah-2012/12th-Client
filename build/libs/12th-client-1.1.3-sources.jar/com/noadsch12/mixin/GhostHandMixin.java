/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.cheats.GhostHand;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public abstract class GhostHandMixin {

    @Shadow @Final
    private class_310 client;

    @Inject(method = "updateCrosshairTarget", at = @At("TAIL"))
    private void onUpdateCrosshairTarget(float tickDelta, CallbackInfo ci) {
        if (!GhostHand.isEnabled()) return;
        if (client.field_1687 == null || client.field_1724 == null) return;

        class_1297 camera = client.method_1560();
        if (camera == null) return;

        double reachDistance = client.field_1724.method_68878() ? 6.0 : 5.0;
        class_243 cameraPos = camera.method_5836(tickDelta);
        class_243 rotation = camera.method_5828(tickDelta);

        // Search through all blocks in line of sight for interactable ones
        class_2338.class_2339 mutablePos = new class_2338.class_2339();
        class_243 step = rotation.method_1021(0.1);
        class_243 currentPos = cameraPos.method_1019(step);

        for (int i = 0; i < (int)(reachDistance / 0.1); i++) {
            mutablePos.method_10102(currentPos.field_1352, currentPos.field_1351, currentPos.field_1350);
            class_2680 state = client.field_1687.method_8320(mutablePos);

            // If we find a block with a block entity (chest, furnace, etc.)
            if (!state.method_26215() && state.method_31709()) {
                // Override the crosshair target to this block
                client.field_1765 = new class_3965(
                        currentPos,
                        class_2350.method_10147((float)rotation.field_1352, (float)rotation.field_1351, (float)rotation.field_1350),
                        mutablePos.method_10062(),
                        false
                );
                System.out.println("GhostHand: Targeting " + state.method_26204().method_9518().getString() + " at " + mutablePos.method_10062());
                return;
            }

            currentPos = currentPos.method_1019(step);
        }
    }
}