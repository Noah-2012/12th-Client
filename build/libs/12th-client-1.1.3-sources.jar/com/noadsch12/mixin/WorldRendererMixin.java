/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.noadsch12.render.TrailRenderer;
import net.minecraft.class_12074;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4599;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import net.minecraft.client.render.*;
import com.noadsch12.ui.BlockOutlineSettings;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.awt.*;

import static com.noadsch12.util.world.BlockUtils.getOutlineShape;

@Mixin(class_761.class)
public class WorldRendererMixin {

    // This shadow gives us access to the game's main vertex consumers
    @Shadow private class_4599 bufferBuilders;

    @Inject(
            method = "render",
            at = @At("TAIL")
    )
    private void onRender(class_9922 allocator, class_9779 tickCounter, boolean renderBlockOutline, class_4184 camera, Matrix4f positionMatrix, Matrix4f matrix4f, Matrix4f projectionMatrix, GpuBufferSlice fogBuffer, Vector4f fogColor, boolean renderSky, CallbackInfo ci) {
        class_4597 entityConsumers = this.bufferBuilders.method_23000();

        TrailRenderer.render(camera, entityConsumers, positionMatrix);
    }

    @Inject(method = "drawBlockOutline", at = @At("HEAD"), cancellable = true)
    private void onDrawBlockOutline(class_4587 matrices, class_4588 vertexConsumer, double x, double y, double z, class_12074 state, int i, CallbackInfo ci) {
        if (BlockOutlineSettings.enabled) {
            ci.cancel(); // Prevent vanilla outline

            class_2338 pos = state.comp_4932();
            class_265 shape = getOutlineShape(pos); // Basic context-less shape

            Color color = BlockOutlineSettings.getOutlineColor();
            float red = color.getRed() / 255f;
            float green = color.getGreen() / 255f;
            float blue = color.getBlue() / 255f;
            float alpha = BlockOutlineSettings.a;

            // Using your preferred matrix naming
            matrices.method_22903();

            // Translate to the block's world position relative to camera
            matrices.method_22904(pos.method_10263() - x, pos.method_10264() - y, pos.method_10260() - z);

            Matrix4f posMatrix = matrices.method_23760().method_23761();

            // Draw the lines for the shape
            shape.method_1104((x1, y1, z1, x2, y2, z2) -> {
                vertexConsumer.method_22918(posMatrix, (float)x1, (float)y1, (float)z1)
                        .method_22915(red, green, blue, alpha)
                        .method_60831(matrices.method_23760(), (float)(x2 - x1), (float)(y2 - y1), (float)(z2 - z1));

                vertexConsumer.method_22918(posMatrix, (float)x2, (float)y2, (float)z2)
                        .method_22915(red, green, blue, alpha)
                        .method_60831(matrices.method_23760(), (float)(x2 - x1), (float)(y2 - y1), (float)(z2 - z1));
            });

            matrices.method_22909();
        }
    }
}