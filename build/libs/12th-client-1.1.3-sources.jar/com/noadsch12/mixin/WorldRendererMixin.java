package com.noadsch12.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.noadsch12.render.TrailRenderer;
import net.minecraft.class_4184;
import net.minecraft.class_4597;
import net.minecraft.class_4599;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class WorldRendererMixin {

    // This shadow gives us access to the game's main vertex consumers
    @Shadow @Final private class_4599 bufferBuilders;

    @Inject(
            method = "render",
            at = @At("TAIL")
    )
    private void onRender(class_9922 allocator, class_9779 tickCounter, boolean renderBlockOutline, class_4184 camera, Matrix4f positionMatrix, Matrix4f matrix4f, Matrix4f projectionMatrix, GpuBufferSlice fogBuffer, Vector4f fogColor, boolean renderSky, CallbackInfo ci) {
        // Use the bufferBuilders shadow to get the entity consumers
        class_4597 consumers = this.bufferBuilders.method_23000();

        // Pass the arguments to your working TrailRenderer logic
        TrailRenderer.render(camera, consumers, positionMatrix);
    }
}