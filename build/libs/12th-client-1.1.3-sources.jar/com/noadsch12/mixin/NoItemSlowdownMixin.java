/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.modules.ModuleManager;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class NoItemSlowdownMixin {

    @Inject(method = "getMovementSpeed", at = @At("RETURN"), cancellable = true)
    private void removeUseItemSlowdown(CallbackInfoReturnable<Float> cir) {
        class_1309 entity = (class_1309) (Object) this;

        // Only apply to players
        if (entity instanceof class_1657 player && ModuleManager.getInstance().getModule("No Slow").isEnabled()) {
            // isUsingItem() is true when eating, drinking, or using a bow/shield
            if (player.method_6115()) {
                // By default, Minecraft returns 0.2f here.
                // We reset it to the player's normal base movement speed.
                cir.setReturnValue(player.method_6029());
            }
        }
    }
}