/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.modules.ModuleManager;
import com.noadsch12.render.ui.DebugAnimation;
import com.noadsch12.render.ui.keystrokes.KeystrokesRenderer;
import com.noadsch12.ui.screens.ClientSettingsScreen;
import net.minecraft.class_2561;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {
    @Inject(method = "render", at = @At("HEAD"))
    private void onUpdate(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        DebugAnimation.update();
    }

    @Inject(method = "setOverlayMessage", at = @At("HEAD"), cancellable = true)
    private void cancelTotemOverlay(class_2561 message, boolean tinted, CallbackInfo ci) {
        if (ModuleManager.getInstance().getModule("Hide Totem Animation").isEnabled()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderOverlay", at = @At("HEAD"), cancellable = true)
    private void cancelTotemRender(CallbackInfo ci) {
        if (ModuleManager.getInstance().getModule("Hide Totem Animation").isEnabled()) {
            ci.cancel();
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (ModuleManager.getInstance().getModule("Show Keystrokes").isEnabled()) {
            KeystrokesRenderer.render(context);
        }
    }
}