/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.modules.ModuleManager;
import com.noadsch12.ui.screens.ClientSettingsScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_636;

@Mixin(class_636.class)
public class CriticalsMixin {

    @Inject(
            method = "attackEntity",
            at = @At("HEAD")
    )
    private void sendFakeCriticalPackets(class_1657 player, class_1297 target, CallbackInfo ci) {
        if (player == null || target == null) return;
        if (!ModuleManager.getInstance().getModule("Criticals").isEnabled()) return;

        double x = player.method_23317();
        double y = player.method_23318();
        double z = player.method_23321();

        // Classic critical spoof sequence
        send(x, y + 0.0625D, z);
        send(x, y, z);
        send(x, y + 0.0125D, z);
        send(x, y, z);
    }

    @Unique
    private void send(double x, double y, double z) {
        Objects.requireNonNull(class_310.method_1551().method_1562())
                .method_52787(new class_2828.class_2829(
                        x, y, z, false, false
                ));
    }
}
