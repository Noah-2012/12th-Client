package com.noadsch12.mixin;

import net.minecraft.class_1665;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3966;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1665.class)
public class ProjectileDing {

    @Inject(method = "onEntityHit", at = @At("TAIL"))
    private void onArrowHitEntity(class_3966 entityHitResult, CallbackInfo ci) {
        class_1665 arrow = (class_1665) (Object) this;

        if (entityHitResult.method_17782() instanceof net.minecraft.class_1309 target) {

            boolean killed = !target.method_5805();

            if (arrow.method_24921() instanceof class_3222 player) {
                player.method_17356(
                        class_3417.field_14793.comp_349(),
                        class_3419.field_15250,
                        10.0f,
                        killed ? 0.6f : 6.0f
                );
            }
        }
    }
}
