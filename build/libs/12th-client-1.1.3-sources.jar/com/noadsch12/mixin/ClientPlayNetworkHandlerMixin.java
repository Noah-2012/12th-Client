/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.event.EventBus;
import com.noadsch12.event.events.PlayerHealthEvent;
import net.minecraft.class_2749;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientPlayNetworkHandlerMixin {

    @Inject(method = "onHealthUpdate", at = @At("HEAD"))
    private void onHealthUpdate(class_2749 packet, CallbackInfo ci) {
        float newHealth = packet.method_11833();
        class_310.method_1551().execute(() -> EventBus.post(new PlayerHealthEvent(null, newHealth)));
    }
}