package com.noadsch12.mixin;

import com.noadsch12.render.TrailRenderer;
import com.noadsch12.ui.ClientSettingsScreen;
import net.minecraft.class_1665;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1665.class)
public abstract class ProjectileTrailMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void spawnArrowTrail(CallbackInfo ci) {
        class_1665 projectile = (class_1665) (Object) this;
        class_1937 world = projectile.method_73183();

        // Check if we are on the client side and the projectile is moving
        // 'inGround' is a Yarn field that turns true when the arrow hits a block
        if (!projectile.method_24828() && ClientSettingsScreen.ProjectileTrailEnabled) {

            // Spawn the particle. You can change ParticleTypes.END_ROD to
            // something else like ParticleTypes.FLAME or ParticleTypes.SOUL_FIRE_FLAME
            if (ClientSettingsScreen.trailIndex == 0) {
                double x = projectile.method_23317();
                double y = projectile.method_23318();
                double z = projectile.method_23321();

                // The center (0,0,0) and the 6 directions (+/- 0.5)
                double[][] offsets = {
                        {0, 0, 0},
                        {0.5, 0, 0}, {-0.5, 0, 0},
                        {0, 0.5, 0}, {0, -0.5, 0},
                        {0, 0, 0.5}, {0, 0, -0.5}
                };

                for (double[] off : offsets) {
                    world.method_8406(
                            class_2398.field_11220,
                            x + off[0], y + off[1], z + off[2],
                            0.0D, 0.0D, 0.0D
                    );
                }
            } else if (ClientSettingsScreen.trailIndex == 1) {
                world.method_8406(
                        class_2398.field_11236,
                        projectile.method_23317(),
                        projectile.method_23318(),
                        projectile.method_23321(),
                        0.0D, 0.0D, 0.0D
                );
            } else if (ClientSettingsScreen.trailIndex == 2) {
                world.method_8406(
                        class_2398.field_11209,
                        projectile.method_23317(),
                        projectile.method_23318(),
                        projectile.method_23321(),
                        0.0D, 0.0D, 0.0D
                );
            } else if (ClientSettingsScreen.trailIndex == 3) {
                TrailRenderer.addPoint(projectile.method_5667(), projectile.method_73189());
            }
        }
    }
}