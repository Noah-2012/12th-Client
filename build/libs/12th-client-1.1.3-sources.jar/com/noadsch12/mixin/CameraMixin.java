/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.modules.ModuleManager;
import com.noadsch12.modules.impl.player.FreecamModule;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4184.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setRotation(float yaw, float pitch);
    @Shadow protected abstract void setPos(class_243 pos);
    @Shadow private boolean ready;
    @Shadow private class_1922 area;
    @Shadow private class_1297 focusedEntity;
    @Shadow private float lastTickProgress;

    @Inject(method = "update", at = @At("HEAD"), cancellable = true)
    private void onUpdate(class_1922 area, class_1297 focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta, CallbackInfo ci) {
        FreecamModule freecam = ModuleManager.getInstance().getModule(FreecamModule.class);

        if (freecam != null && freecam.isEnabled()) {
            this.ready = true;
            this.area = area;
            this.lastTickProgress = tickDelta;
            // Focus on the fake player so the game knows which chunks to render
            this.focusedEntity = freecam.getFakePlayer() != null ? freecam.getFakePlayer() : focusedEntity;

            // Use the methods, not just the fields!
            setRotation(freecam.getYaw(), freecam.getPitch());
            setPos(freecam.getInterpolatedPos(tickDelta));

            ci.cancel();
        }
    }
}
