/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.modules.ModuleManager;
import com.noadsch12.ui.screens.ClientSettingsScreen;
import net.minecraft.class_10774;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2560;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2560.class)
public class CobwebCollisionMixin {

    /**
     * Prevents the cobweb from applying the "slowdown" effect to the player.
     */
    @Inject(method = "onEntityCollision", at = @At("HEAD"), cancellable = true)
    private void stopWebSlowdown(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity, class_10774 handler, boolean bl, CallbackInfo ci) {
        // Use your utility logic or check for player
        if (entity instanceof class_1657 && ModuleManager.getInstance().getModule("Anti Web").isEnabled()) {
            // Cancel the method to skip the code that sets velocity to (0.25, 0.05, 0.25)
            ci.cancel();
        }
    }
}