/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixin;

import com.noadsch12.modules.ModuleManager;
import com.noadsch12.ui.screens.ClientSettingsScreen;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_746.class)
public class AutoCobwebMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        class_746 player = (class_746) (Object) this;

        // Check your custom setting toggle
        if (!ModuleManager.getInstance().getModule("Anti Web").isEnabled()) return;

        // Ensure player is holding cobwebs (optional, remove if you want it to auto-switch)
        if (player.method_5998(class_1268.field_5808).method_7909() != class_1802.field_8786) return;

        // Logic: Check position at feet or 1 block in front
        class_2338 pos = player.method_24515();

        if (shouldPlaceCobweb(player, pos)) {
            placeCobweb(player, pos);
        } else {
            class_2338 forwardPos = pos.method_10093(player.method_5735());
            if (shouldPlaceCobweb(player, forwardPos)) {
                placeCobweb(player, forwardPos);
            }
        }
    }

    private boolean shouldPlaceCobweb(class_746 player, class_2338 pos) {
        // Only place if the block is air/replaceable and there is a target nearby
        return player.method_73183().method_8320(pos).method_45474();
    }

    private void placeCobweb(class_746 player, class_2338 pos) {
        var client = net.minecraft.class_310.method_1551();

        // Create a fake hit result to simulate the click
        class_3965 hitResult = new class_3965(
                new class_243(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5),
                class_2350.field_11036,
                pos,
                false
        );

        // Interact with the world
        client.field_1761.method_2896(player, class_1268.field_5808, hitResult);
    }
}