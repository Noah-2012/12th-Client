/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.modules.impl.combat;
import com.noadsch12.event.EventBus;
import com.noadsch12.event.events.PlayerHealthEvent;
import com.noadsch12.event.listeners.PlayerHealthListener;
import com.noadsch12.modules.Category;
import com.noadsch12.modules.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_465;

public class AutoTotemModule extends Module implements PlayerHealthListener {
    public AutoTotemModule() {
        super("Auto Totem", "Auto Totem", Category.COMBAT,
            "Automatically places the totem in the slot", class_1802.field_8288);
    }

    @Override
    public void onEnable() {
        EventBus.register(this);
    }

    @Override
    public void onDisable() {
        EventBus.unregister(this);
    }

    @Override
    public void onHealthChanged(PlayerHealthEvent readPacketEvent) {
        class_310 mc = class_310.method_1551();

        if (mc.field_1724 == null || mc.field_1687 == null) return; // <-- add this
        if (mc.field_1755 instanceof class_465) return;

        class_1661 inventory = mc.field_1724.method_31548();
        class_1799 handItemStack = inventory.method_7391();

        // If offhand already has a totem, skip
        if (mc.field_1724.method_6079().method_7909() == class_1802.field_8288) return;

        if (handItemStack.method_7909() == class_1802.field_8288) return;

        if (readPacketEvent.getHealth() <= 5) {
            SwitchToTotem();
        }
    }

    private void SwitchToTotem() {
        class_310 mc = class_310.method_1551();

        class_1661 inventory = mc.field_1724.method_31548();

        int slot = -1;
        for (int i = 0; i <= 36; i++) {
            class_1799 itemStackToCheck = inventory.method_5438(i);
            class_1792 itemToCheck = itemStackToCheck.method_7909();

            if (itemToCheck == class_1802.field_8288) {
                slot = i;
                break;
            }
        }

        if (slot != -1) {
            /*
            mc.interactionManager.clickSlot(
                    mc.player.playerScreenHandler.syncId,
                    slot,
                    0,
                    SlotActionType.PICKUP,
                    mc.player
            );

             */
            mc.field_1724.method_6122(class_1268.field_5810, inventory.method_5438(slot));
        }
    }
}
