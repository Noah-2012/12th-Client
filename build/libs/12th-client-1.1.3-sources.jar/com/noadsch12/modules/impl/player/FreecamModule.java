/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.modules.impl.player;
import com.noadsch12.event.events.TickEvent;
import com.noadsch12.event.listeners.TickListener;
import com.noadsch12.modules.Category;
import com.noadsch12.modules.Module;
import com.noadsch12.render.*;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class FreecamModule extends Module implements TickListener {
    private class_243 pos;
    private class_243 prevPos;
    private float yaw, pitch;
    private FakePlayerEntity fakePlayer;
    private final class_310 client = class_310.method_1551();

    public FreecamModule() {
        super("Freecam", "Freecam", Category.PLAYER, "Let you move the Camera free around", class_1802.field_8449);
    }

    @Override
    public void onEnable() {
        if (client.field_1724 == null) return;

        // Initialize everything
        pos = client.field_1724.method_33571();
        prevPos = pos;
        yaw = client.field_1724.method_36454();
        pitch = client.field_1724.method_36455();

        fakePlayer = new FakePlayerEntity();
        fakePlayer.method_5878(client.field_1724);
        fakePlayer.method_31549().field_7479 = true; // Prevents some physics jitter
        client.field_1687.method_53875(fakePlayer);
    }

    @Override
    public void onTick(TickEvent.Pre event) {

    }

    @Override
    public void onTick(TickEvent.Post event) {
        float speed = 0.5f;
        class_243 velocity = class_243.field_1353;

        // Use 'this.yaw' so we don't depend on the Camera's state
        class_243 forward = class_243.method_1030(0, this.yaw);
        class_243 right = class_243.method_1030(0, this.yaw + 90);

        if (client.field_1690.field_1894.method_1434()) velocity = velocity.method_1019(forward);
        if (client.field_1690.field_1881.method_1434()) velocity = velocity.method_1020(forward);
        if (client.field_1690.field_1849.method_1434()) velocity = velocity.method_1019(right);
        if (client.field_1690.field_1913.method_1434()) velocity = velocity.method_1020(right);
        if (client.field_1690.field_1903.method_1434()) velocity = velocity.method_1031(0, 1, 0);
        if (client.field_1690.field_1832.method_1434()) velocity = velocity.method_1031(0, -1, 0);

        prevPos = pos;
        if (velocity.method_1027() > 0) {
            pos = pos.method_1019(velocity.method_1029().method_1021(speed));
        }

        // Sync the fake player so the world renders around it
        if (fakePlayer != null) {
            fakePlayer.method_5814(pos.field_1352, pos.field_1351, pos.field_1350);
        }
    }

    public float getYaw() { return yaw; }
    public float getPitch() { return pitch; }
    public void setRotation(float y, float p) { this.yaw = y; this.pitch = p; }
    public class_243 getInterpolatedPos(float delta) {
        return prevPos.method_35590(pos, delta);
    }
    public FakePlayerEntity getFakePlayer() {
        return fakePlayer;
    }
}
