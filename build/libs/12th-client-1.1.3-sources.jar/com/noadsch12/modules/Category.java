/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.modules;

import net.minecraft.class_1792;
import net.minecraft.class_1802;

/**
 * Categories for organizing modules in the UI
 */
public enum Category {
    PLAYER("Player", class_1802.field_8575, 0xFFFFAA00),
    MISC("Misc", class_1802.field_8251, 0xFFFFAA00),
    RENDER("Render", class_1802.field_27070, 0xFFFFAA00),
    COMBAT("Combat", class_1802.field_22022, 0xFFFFAA00),
    MOVEMENT("Movement", class_1802.field_8833, 0xFFFFAA00);

    private final String displayName;
    private final class_1792 iconItem;
    private final int color;

    Category(String displayName, class_1792 iconItem, int color) {
        this.displayName = displayName;
        this.iconItem = iconItem;
        this.color = color;
    }

    public String getDisplayName() {
        return displayName;
    }

    public class_1792 getIconItem() {
        return iconItem;
    }

    public int getColor() {
        return color;
    }

    /**
     * Get the X position for this category's column in the UI
     */
    public int getColumnX(int centerX, int columnWidth) {
        return switch (this) {
            case PLAYER -> centerX - 424;
            case MISC -> centerX - 250;
            case RENDER -> centerX - (columnWidth / 2);
            case COMBAT -> centerX + 100;
            case MOVEMENT -> centerX + 274;
        };
    }
}