/*
 * 12th Client
 * Copyright (C) 2026 Noadsch12
 *
 * This file is part of the 12th Client project.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, version 3 of the License only.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU Lesser General Public License for more details.
 */

package com.noadsch12.mixininterfaces;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4184.class)
public interface ICamera {
    @Accessor("focusedEntity")
    void setFocusedEntity(class_1297 focusedEntity);

    @Invoker("moveBy")
    void moveCameraBy(float f, float g, float h);

    @Invoker("setPos")
    void setCameraPos(class_243 vec);

    @Invoker("setRotation")
    void setCameraRotation(float yaw, float pitch);
}