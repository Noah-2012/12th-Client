#version 120

uniform sampler2D texture;
varying vec2 texcoord;

#define SATURATION 1.0  // Saturation  [1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

void main() {
    vec4 color = texture2D(texture, texcoord);
    
    // Calculate luminance
    float luminance = dot(color.rgb, vec3(0.299, 0.587, 0.114));
    
    // Increase saturation
    vec3 gray = vec3(luminance);
    vec3 saturated = mix(gray, color.rgb, SATURATION);
    
    gl_FragColor = vec4(saturated, color.a);
}
