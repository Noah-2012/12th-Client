#version 120

#define UNDERWATER_FOG_DENSITY 0.05
#define LAVA_FOG_DENSITY 0.95

uniform sampler2D colortex0;
uniform sampler2D depthtex0;

uniform int isEyeInWater;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;

varying vec2 texCoord;

float getDepth(vec2 coord) {
    return texture2D(depthtex0, coord).r;
}

vec3 getViewPosition(float depth) {
    vec4 pos = vec4(texCoord.x * 2.0 - 1.0, texCoord.y * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    pos = gbufferProjectionInverse * pos;
    return pos.xyz / pos.w;
}

vec3 applyFog(vec3 color, float dist, vec3 fogColor, float density) {
    float fogFactor = 1.0 - exp(-dist * density);
    return mix(color, fogColor, fogFactor);
}

void main() {
    vec3 color = texture2D(colortex0, texCoord).rgb;
    float depth = getDepth(texCoord);
    
    vec3 viewPos = getViewPosition(depth);
    float viewDist = length(viewPos);

    if (isEyeInWater == 1) {
        vec3 underwaterColor = vec3(0.0, 0.2, 0.8); // Adjust for desired underwater tint
        color = applyFog(color, viewDist, underwaterColor, UNDERWATER_FOG_DENSITY);
    } else if (isEyeInWater == 2) {
        vec3 lavaColor = vec3(1.0, 0.3, 0.0); // Adjust for desired lava tint
        color = applyFog(color, viewDist, lavaColor, LAVA_FOG_DENSITY);
    }

    gl_FragColor = vec4(color, 1.0);
}