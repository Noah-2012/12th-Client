
#define DOF 1
#define DOF_STRENGTH 2.0                //[1.0 2.0 4.0 8.0 16.0 32.0]
