#version 130

#include "/settings.glsl"

varying vec2 texCoord;

uniform sampler2D colortex0;
uniform sampler2D depthtex1;
uniform float viewWidth;
uniform float viewHeight;
uniform float aspectRatio;
uniform float centerDepthSmooth;
uniform mat4 gbufferProjection;

const int NUM_SAMPLES = 60;
const vec2 dofOffsets[NUM_SAMPLES] = vec2[NUM_SAMPLES](
    vec2( 0.0    ,  0.25  ), vec2(-0.2165 ,  0.125 ), vec2(-0.2165 , -0.125 ),
    vec2( 0      , -0.25  ), vec2( 0.2165 , -0.125 ), vec2( 0.2165 ,  0.125 ),
    vec2( 0      ,  0.5   ), vec2(-0.25   ,  0.433 ), vec2(-0.433  ,  0.25  ),
    vec2(-0.5    ,  0     ), vec2(-0.433  , -0.25  ), vec2(-0.25   , -0.433 ),
    vec2( 0      , -0.5   ), vec2( 0.25   , -0.433 ), vec2( 0.433  , -0.2   ),
    vec2( 0.5    ,  0     ), vec2( 0.433  ,  0.25  ), vec2( 0.25   ,  0.433 ),
    vec2( 0      ,  0.75  ), vec2(-0.2565 ,  0.7048), vec2(-0.4821 ,  0.5745),
    vec2(-0.51295,  0.375 ), vec2(-0.7386 ,  0.1302), vec2(-0.7386 , -0.1302),
    vec2(-0.51295, -0.375 ), vec2(-0.4821 , -0.5745), vec2(-0.2565 , -0.7048),
    vec2(-0      , -0.75  ), vec2( 0.2565 , -0.7048), vec2( 0.4821 , -0.5745),
    vec2( 0.51295, -0.375 ), vec2( 0.7386 , -0.1302), vec2( 0.7386 ,  0.1302),
    vec2( 0.51295,  0.375 ), vec2( 0.4821 ,  0.5745), vec2( 0.2565 ,  0.7048),
    vec2( 0      ,  1     ), vec2(-0.2588 ,  0.9659), vec2(-0.5    ,  0.866 ),
    vec2(-0.7071 ,  0.7071), vec2(-0.866  ,  0.5   ), vec2(-0.9659 ,  0.2588),
    vec2(-1      ,  0     ), vec2(-0.9659 , -0.2588), vec2(-0.866  , -0.5   ),
    vec2(-0.7071 , -0.7071), vec2(-0.5    , -0.866 ), vec2(-0.2588 , -0.9659),
    vec2(-0      , -1     ), vec2( 0.2588 , -0.9659), vec2( 0.5    , -0.866 ),
    vec2( 0.7071 , -0.7071), vec2( 0.866  , -0.5   ), vec2( 0.9659 , -0.2588),
    vec2( 1      ,  0     ), vec2( 0.9659 ,  0.2588), vec2( 0.866  ,  0.5   ),
    vec2( 0.7071 ,  0.7071), vec2( 0.5    ,  0.866 ), vec2( 0.2588 ,  0.9659)
);

vec3 depthOfField(vec3 color, float depth) {
    vec3 dof = color;
    float handMask = float(depth < 0.56);
    
    float fovScale = gbufferProjection[1][1] / 1.37;
    float cocSize = max(abs(depth - centerDepthSmooth) * DOF_STRENGTH - 0.01, 0.0);
    cocSize = cocSize / sqrt(cocSize * cocSize + 0.1);
    
    if (cocSize > 0.0 && handMask < 0.5) {
        vec3 totalColor = vec3(0.0);
        float totalWeight = 0.0;
        
        for (int i = 0; i < NUM_SAMPLES; i++) {
            vec2 offset = dofOffsets[i] * cocSize * 0.015 * fovScale * vec2(1.0 / aspectRatio, 1.0);
            float lod = log2(viewHeight * aspectRatio * cocSize * fovScale / 320.0);
            
            vec3 sampleColor = texture2DLod(colortex0, texCoord + offset, lod).rgb;
            float weight = 1.0 / float(NUM_SAMPLES);
            
            totalColor += sampleColor * weight;
            totalWeight += weight;
        }
        
        dof = totalColor / totalWeight;
    }
    
    return dof;
}

void main() {
    vec3 color = texture2D(colortex0, texCoord).rgb;
    
    #if DOF == 1
    float depth = texture2D(depthtex1, texCoord).r;
    color = depthOfField(color, depth);
    #endif
    
    /* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(color, 1.0);
}

