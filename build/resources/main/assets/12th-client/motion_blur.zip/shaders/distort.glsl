// Shadow toggle: set SHADOW_ENABLED to 1 to enable shadows, or 0 to disable shadows
#define SHADOW_ENABLED 1  // 1 = Shadows ON, 0 = Shadows OFF

#if SHADOW_ENABLED == 1
    #define SHADOW_DISTORT_ENABLED //Toggles shadow map distortion
    #define SHADOW_DISTORT_FACTOR 0.15  // Or use another value to disable shadow distortion [0.00 0.15]
    #define SHADOW_BIAS 0.80 //Increase this if you get shadow acne. Decrease this if you get peter panning. [0.00 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.60 0.70 0.80 0.90 1.00 1.50 2.00 2.50 3.00 3.50 4.00 4.50 5.00 6.00 7.00 8.00 9.00 10.00]
    #define NORMAL_BIAS //Offsets the shadow sample position by the surface normal instead of towards the sun
    #define EXCLUDE_FOLIAGE //If true, foliage will not cast shadows.
    #define SHADOW_BRIGHTNESS 0.75 //Light levels are multiplied by this number when the surface is in shadows [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
    const int shadowMapResolution = 2048; //Resolution of the shadow map. Higher numbers mean more accurate shadows. [128 256 512 1024 2048 4096 8192]
    
	#define SHADOW_OPACITY 0.5 // Shadow opacity (0.0 = fully transparent, 1.0 = fully opaque)

    #ifdef SHADOW_DISTORT_ENABLED
    vec3 distort(vec3 pos) {
        float factor = length(pos.xy) + SHADOW_DISTORT_FACTOR;
        return vec3(pos.xy / factor, pos.z * 0.5);
    }
    float computeBias(vec3 pos) {
        float numerator = length(pos.xy) + SHADOW_DISTORT_FACTOR;
        numerator *= numerator;
        return SHADOW_BIAS / float(shadowMapResolution) * numerator / SHADOW_DISTORT_FACTOR;
    }
    #else
    vec3 distort(vec3 pos) {
        return vec3(pos.xy, pos.z * 0.5);
    }
    float computeBias(vec3 pos) {
        return SHADOW_BIAS / float(shadowMapResolution);
    }
    #endif

    // Function to compute shadow
    float computeShadow(vec3 position, vec3 normal) {
        // Shadow computation logic goes here
        return 1.0; // Placeholder for actual shadow calculation
    }
#else
    // When shadows are disabled, provide dummy functions and defaults
    #define SHADOW_BRIGHTNESS 1.0 // Default brightness when shadows are off
    #define SHADOW_OPACITY 0.0 // No opacity when shadows are disabled

    vec3 distort(vec3 pos) {
        return pos;
    }
    float computeBias(vec3 pos) {
        return 0.0;
    }
    float computeShadow(vec3 position, vec3 normal) {
        return 1.0; // Always fully lit when shadows are disabled
    }
#endif

// Main shading function
vec3 calculateLighting(vec3 position, vec3 normal, vec3 albedo) {
    #if SHADOW_ENABLED == 1
        float shadowFactor = computeShadow(position, normal);
        // Apply shadow opacity: blend between full lighting and shadowed lighting
        float finalShadow = mix(1.0, shadowFactor, SHADOW_OPACITY);
        return albedo * finalShadow * SHADOW_BRIGHTNESS;
    #else
        return albedo * SHADOW_BRIGHTNESS; // Full lighting when shadows are disabled
    #endif
}
