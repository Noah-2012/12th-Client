#version 130

#include "/lib/util/dither.glsl"

varying vec2 TexCoords;

uniform float viewWidth, viewHeight, frameTimeCounter;
uniform vec3 cameraPosition, previousCameraPosition;
uniform mat4 gbufferPreviousProjection, gbufferProjectionInverse;
uniform mat4 gbufferPreviousModelView, gbufferModelViewInverse;
uniform sampler2D colortex0;
uniform sampler2D depthtex1;

const float DEPTH_THRESHOLD = 0.66;

#define MOTION_BLUR_STRENGTH 1.50   // Motion Blur Strength  [0.00 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00 2.25 2.50 3.00 3.50 4.00 4.50 5.00]
#define MOTION_BLUR_SAMPLES 32  // Motion Blur Samples  [8 16 32 64 128]
#define SATURATION 1.0  // Saturation  [1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

float random(vec2 st) {
    return fract(sin(dot(st.xy, vec2(12.9898, 78.233))) * 43758.5453123);
}

vec3 MotionBlur(vec3 color, float z, float dither) {
    if (z <= DEPTH_THRESHOLD) return color;

    vec4 currentPosition = vec4(TexCoords, z, 1.0) * 2.0 - 1.0;
    vec4 viewPos = gbufferProjectionInverse * currentPosition;
    viewPos = gbufferModelViewInverse * viewPos;
    viewPos /= viewPos.w;

    vec3 cameraOffset = cameraPosition - previousCameraPosition;
    vec4 previousPosition = gbufferPreviousProjection * gbufferPreviousModelView * (viewPos + vec4(cameraOffset, 0.0));
    previousPosition /= previousPosition.w;

    vec2 velocity = (currentPosition - previousPosition).xy;
    velocity = velocity / (1.0 + length(velocity)) * MOTION_BLUR_STRENGTH;

    vec3 mblur = vec3(0.0);
    float totalWeight = 0.0;

    for (int i = 0; i < MOTION_BLUR_SAMPLES; i++) {
        float t = (float(i) + dither) / float(MOTION_BLUR_SAMPLES - 1);
        vec2 offset = velocity * (t - 0.5);
        vec2 sampleCoord = TexCoords + offset;
        
        vec3 sampleColor = texture2D(colortex0, sampleCoord).rgb;
        float noiseValue = random(sampleCoord * frameTimeCounter);
        float weight = mix(0.5, 1.0, noiseValue);
        
        mblur += sampleColor * weight;
        totalWeight += weight;
    }

    return mblur / totalWeight;
}

void main() {
    vec3 color = texture2D(colortex0, TexCoords).rgb;
    #if MOTION_BLUR == On
    float z = texture2D(depthtex1, TexCoords).x;
    float dither = Bayer64(gl_FragCoord.xy) + random(TexCoords * frameTimeCounter);
    color = MotionBlur(color, z, dither);
    #endif

    // Increase saturation
    float luminance = dot(color.rgb, vec3(0.299, 0.587, 0.114));
    vec3 gray = vec3(luminance);
    vec3 saturated = mix(gray, color.rgb, SATURATION);

    gl_FragData[0] = vec4(saturated, 1.0);
}
